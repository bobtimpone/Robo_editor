# Robo-Editor — Code Review Fixes

## Rounds 1–3 (Oct 28, 2026) — build 2026-10-28-r123

Applied from the Oct 28, 2026 deep code review
(~/workspace/robo-editor-code-review-2026-10-28.md). Base is the
Oct 27 afternoon Graphics Studio build WITH `graphics_art.py`
(66 tests) — the `graphics_with_manuscript_support` upload was a
fork predating the artwork fix and is abandoned (review R1).
Suite after these rounds: 118 tests.

### Round 1 — stop the bleeding (R1, R2, R4, R16c)

- **Atomic saves everywhere.** New helpers in `engine.py`:
  `atomic_write_text()` (temp file in the same directory + fsync +
  `os.replace`) and `atomic_save_docx()`. `EditorEngine.save_document`
  now saves atomically, so final, partial, and checkpoint .docx
  writes can no longer corrupt the file already at the destination.
  The app's checkpoint JSON (`app.py` `_write_edit_checkpoint`) and
  the post-save audit report use `atomic_write_text` too, and the
  audit no longer claims a report it failed to write.
- **Shared config safety.** `engine.update_config_file()` is now the
  one config writer: it re-reads `robo_config.json`, merges the
  caller's section, and atomically replaces the file. Both
  `app.py save_config()` and `graphics_page.py save_graphics_config()`
  use it. A config that exists but cannot be read/parsed is NEVER
  overwritten — the save aborts and is logged/surfaced. (The old
  Studio code rewrote the file containing only the "graphics" key
  in exactly that case, wiping every editor setting.)
- **Close guard (R2).** `app.py on_closing()`: with a run in flight,
  closing asks first (yes/no). Confirming sets the cancel flag and
  polls with `after()` until the worker goes idle — letting its
  interrupt/checkpoint path finish — then saves config and destroys.
  Declining keeps the window open. The Graphics Studio `on_close()`
  asks the same way when a cover/Text-to-Graphic build is busy (R33).

### Round 2 — do-no-harm, finished (R3, R29, R7, R6)

- **Save-time sanitizer restore (R3).** In `save_document`, when
  `_sanitize_output` would drop a real share of a chunk, the chunk is
  now saved UNSANITIZED and the restore is logged loudly. Threshold
  (the tripwire): ≥50 words with >1% lost (the original S1 rule), a
  total wipe of any non-empty chunk under 50 words, or >50% lost
  from a 20–49-word chunk. The `---EXCEPTIONS---` cut and the other
  shape-based deletions can therefore never silently amputate
  gated or do-no-harm-fallback text at save again.
- **Reasoning-strip bound (R29).** `strip_reasoning_blocks` now
  refuses to strip manuscript-sized inputs (≥500 chars) when the
  reasoning blocks would remove more than 30% of the text
  (`REASONING_STRIP_MAX_SHARE = 0.30`,
  `REASONING_STRIP_MIN_LENGTH = 500`) — such tags are treated as the
  content they are in a book that discusses reasoning tags. Short
  model replies strip exactly as before.
- **Per-chunk exception fallback (R7).** `orchestrator.process_chunk`
  wraps the edit / inspect / correct chain: an ordinary exception
  (e.g. Ollama failing mid-book) logs and returns the ORIGINAL chunk,
  and the run continues. `CancelRequested` still propagates, so the
  app's stop/checkpoint flow is unchanged.
- **Co-author ledger (R6).** `Orchestrator.__init__` initialises
  `self._ledger = ""`, so a resumed session whose first call has
  `sequence_id != 1` no longer raises `AttributeError`.

### Round 3 — gates that miss (R12, R13, R22, R23, R5)

- **Banned words, count-based (R12).** The WatchTower check counts
  each term with word-boundary regexes and rejects only when the
  edit's count exceeds the original's. Same-count reuse passes;
  "highlighter" no longer fires "highlight".
- **Count-aware preservation (R13).** Heading and short-line checks
  compare Counters (multisets): dropping one of two identical
  headings or one of two identical caption/label lines now fails.
  Name invariance also tracks single-mention sentence-initial names
  (excluding stopwords/transition words): "Mira stood." → "Joss
  stood." is caught, while a known name gaining a plain extra use
  still passes.
- **Stage binding fail-safe (R22).** `REWRITE_BOUND_STAGES` now
  includes Combined Edit and Developmental Edit, and the gates go
  through `_is_rewrite_bound()`: a stage is unbound only if it is a
  recognised unbound stage (Co-Author Generation); an unrecognised
  stage string is treated as BOUND instead of silently disabling
  the invariance/quote/short-line gates. Note: because Combined and
  Developmental are now bound stages, checkpoint revalidation in
  `app.py` treats those chains as bound too (consistent with the
  gates). `""`/None stages are treated as bound (fail-safe).
- **Cosmetic-skip tightened (R23).** `_is_cosmetic_only` now also
  requires unchanged emphasis-marker counts (`**`/`*`) and unchanged
  component-word counts, so stripping all bold/italic or joining
  words ("well known" → "wellknown") is NOT cosmetic and goes
  through the LLM audit. Pure punctuation edits still skip it.
- **Text-to-Graphic hallucination fence (R5).**
  `graphics_text.parse_ai_graphic_json` now fences AI output against
  the passage: the quote must be a verbatim passage sentence
  (whitespace-normalised) or it is replaced with one; each bullet
  must share at least half (and at least 2) of its content words
  with the passage or it is dropped; the body must pass the same
  grounding check. If nothing trustworthy survives, the built-in
  deterministic extractor's result is used instead. The old test
  that accepted a non-verbatim quote was updated to a verbatim
  fixture, and a new regression test uses the review's verified
  fabricated-quote example, which no longer survives.

### Tests added

- `tests/test_rounds12.py` (20) — atomic writes/saves, config merge
  + corrupt-config abort, close guard, checkpoint JSON, sanitizer
  restore, reasoning-strip bound, orchestrator fallback/cancel,
  co-author ledger.
- `tests/test_round3_watchtower.py` (26) — R12/R13/R22/R23.
- `tests/test_round3_graphics_fence.py` (6) — R5 fence incl. the
  verified hallucination example.
- Verified: 118/118 with customtkinter present (113 + 5 skipped
  without it — the app-level tests, same skip pattern as before),
  plus a real-window Xvfb smoke of both close guards.

## Graphics Studio build (Oct 27, 2026)

A dedicated graphics page for novel production, defaulting to KDP.

- **New button** in the main window: "🎨 Graphics Studio (KDP)" opens
  the page (single window; clicking again just raises it).
- **`graphics_kdp.py`** — KDP spec math + Pillow builders:
  spine = pages × per-paper factor (white 0.002252″, cream 0.0025″,
  color 0.002347″), 0.125″ bleed, full-wrap and front-only pixel sizes
  at 300 DPI, ebook cover 1600×2560, barcode box placement, the 79-page
  spine-text rule with 0.0625″ clearances, and interior image widths
  from the editor's own KDP margin profile (inside 0.75″ / outside
  0.5″ → 4.75″ text width at 6×9). Builders: full print wrap PNG
  (art or solid background, series/title/tagline/author, rotated spine
  text when allowed, back blurb, blank ISBN barcode box), ebook cover
  JPG, interior-image prep to exact pixel width at 300 DPI (optional
  grayscale), image inspection, spec brief, and a cover-art prompt
  composer for external image generators.
- **`graphics_page.py`** — the page itself: book spec with live
  readouts and warnings, cover builder, interior graphics prep, and
  the art-prompt builder. Settings persist in `robo_config.json`
  under a `"graphics"` key.
- **`app.py`** — `save_config()` now merges with the config already on
  disk, so the editor and the Graphics Studio can never wipe each
  other's settings.
- **requirements.txt** — adds `Pillow==10.2.0`.
- **Tests** — `tests/test_graphics_kdp.py` (spec math incl. THE
  BROKEN's shipped 264-page cream numbers, builder smoke tests).

### Text to Graphic (same day, Bob's follow-up ask)

Manuscript text in, helpful graphic out — a new section on the
Graphics page:

- **Easy text intake:** paste from the clipboard, load a passage file
  (.docx/.txt/.md), or link the editor's own manuscript input and
  *pull a passage by search* (type a name/place/phrase; you get the
  paragraph it lives in plus one either side). With a manuscript
  linked and no passage chosen, Generate works from the opening.
- **Five graphic kinds:** Key Points Panel, Pull-Quote Card, Chapter
  Callout, Scene Card, Timeline.
- **Two brains:** with "Use Ollama" on, the main window's selected
  model structures the passage (title / bullets / exact quote /
  summary — JSON-sanitized, invented content fenced out by prompt and
  by the parser's fallbacks). If Ollama is off or unreachable, a
  deterministic built-in extractor does the same job offline, and the
  status line tells you which brain ran.
- **KDP output:** exact pixel widths from the spec panel (full text
  width 1425 px / half page at 6×9, or front-cover width), 300 DPI,
  light grayscale-safe panel by default, dark panel option for
  screen/promo use.
- **`graphics_text.py`** holds the logic (loading, context pull,
  analysis, rendering) with its own tests in
  `tests/test_graphics_text.py`.
- Threading follows the editor's S13 rule: the Generate worker makes
  no Tk calls; results return through a queue the main thread polls.
  (An early draft called `after()` from the worker and a headless GUI
  smoke caught it dying on exactly that; fixed before shipping.)

### Artwork generation (same day, Bob's bug report)

Bob: "doesn't generate a graphic, just puts the title over a
background." Correct — the cover builder was a compositor, not a
generator. Fixed with **`graphics_art.py`** and an **Artwork** source
selector on the Cover Builder:

- **Auto (default):** use your art file if one is set; else a local
  Stable Diffusion server if one is running (AUTOMATIC1111 at
  127.0.0.1:7860, prompted from the Art Prompt fields, sized to the
  canvas aspect and capped for a 12 GB card); else the built-in
  engine. The status line names which engine actually painted.
- **Built-in generated art:** a procedural illustration engine
  (gradient sky, celestial body, layered terrain, a hero silhouette
  picked from your words — drop pod, starship, tower, skyline,
  forest, lone figure — grain and vignette). Deterministic per seed
  text, so series covers can share a look. It is illustration, not
  diffusion; the SD path is the photographic one.
- **Art file / Solid background:** the original behaviors, kept.
- Cover builds now run on the same worker+queue pattern as
  Text-to-Graphic (SD generation can take a minute; the UI no longer
  freezes), and both cover builders accept a ready `art_image`.
- Tests: `tests/test_graphics_art.py` (art is provably non-flat,
  seed determinism, SD client against a stub server).
- **Deadlock caught by the end-to-end GUI smoke (fixed before this
  shipped):** the first version of the cover worker read the page's
  Tk variables and the blurb textbox from inside the worker thread
  while resolving artwork. Tk is main-thread-only; the build hung
  forever with no output and no error. The worker now receives plain
  values captured on the main thread by `_capture_cover_art` (the
  S13 rule the Text-to-Graphic path already followed), and two
  regression tests in `test_graphics_art.py` pin that in place.
  Verified after the fix: the full studio flow (open app → studio →
  Built-in art → ebook cover) saves a 1600×2560 cover in about a
  second, status line naming the built-in engine.

Applied from the Oct 19, 2026 code review. Files keep their original names;
drop them over your existing copies (keep your `agents/` directory layout).
`keeper_agent.py` is unchanged. `keeper_agent.pypy` was a stale duplicate —
delete it.

## Hygiene + shipping round (Oct 21 — build 2026-10-21c) — S13, S14

The last two suggestions from the code review. **The zip layout
changed:** it now unpacks into the real folder structure — app.py,
engine.py, orchestrator.py at the root, the agent modules and
vocab.py inside `agents/`, tests inside `tests/`. Extract it over
your project root and everything lands where it belongs; no more
hand-sorting files into `agents/` (the flat zip vs. `agents.`
imports was a standing first-run trap).

- **S13 hygiene bundle:**
  - *Thread snapshot:* both pipelines now snapshot every setting on
    the main thread and hand the worker plain values — worker
    threads never read Tk variables (Tkinter isn't thread-safe;
    it worked until it wouldn't have).
  - *Interruptible cancel:* the Ollama retry backoff polls the
    cancel flag through the wait, so Stop during a retry storm
    stops the run instead of waiting out the sleeps.
  - *One gate chain:* `WatchTowerAgent.validate_chunk()` is the
    single deterministic chain; `inspect_chunk` and the app's
    checkpoint revalidation both call it. (Rounds 13–15 each had
    to hand-edit two copies.)
  - *Stage constants:* stage names live once in vocab.py and are
    imported everywhere — the 27 scattered literals are gone.
  - *Human score demoted:* the cadence metric no longer rejects;
    it logs an advisory the orchestrator surfaces in the run log.
  - *Small items:* KDP heading sizes are monotone again (H3 12pt
    over H4 11pt — H4 was larger than H3); the app's duplicate
    ollama_url is gone (the engine owns the URL).
- **S14 tests + pins + structure:** `tests/test_robo_editor.py`
  ships with the project — 28 self-contained unittest cases (no
  Ollama, no manuscripts needed) encoding the real failures from
  rounds 13–16: mutated numbers, name swaps, possessive-name false
  positives, the 'Note:' amputation, fused two-line headings,
  delta banned-vocabulary, audited co-author corrections, the
  checkpoint fingerprint, ledger rules. Run them with
  `python -m unittest discover -s tests` from the project root.
  requirements.txt is pinned to the verified versions
  (customtkinter 6.0.0, python-docx 1.1.0, tiktoken 0.14.0) so a
  future dependency release can't change behavior under a run.
- Verified: shipped suite 28/28 from the packaged tree; the full
  round-15 regression battery (48 checks) still passes; both book
  round trips still exact (77,814 / 55,930 words, +0) — now also
  with the real tiktoken counter active.

## Code-review round (Oct 21 — build 2026-10-21b) — S1 through S12

Implements the twelve accepted suggestions from the full code
review (robo-editor-code-review-2026-10-21.md). **New file:
`vocab.py` — put it in your `agents/` folder with the other agent
modules.** Headline: the save path can no longer delete manuscript
text, resume and the co-author path no longer ship unreviewed text,
and the app now grades the finished book itself.

- **S1 — sanitizer trailer-cut removed (engine).** The rule that
  deleted everything after a back-half "Note:"/"Summary:" line is
  gone. Measured before the fix: a no-edit round trip of Hey Y'All
  lost 1,568 words (−2.8%), all of it this rule amputating the Ch 5
  Chimera example and the Ch 7 "Note 1:" passage at save time —
  after every gate had passed, fallback chunks included. After:
  the same round trip is +0 words. Added a save-time tripwire:
  if sanitizing any chunk drops >1% of its words, the log says so,
  with the chunk number.
- **S2 — image warning (engine + app).** Loading counts embedded
  images; if the input has any, the log warns prominently that
  they will not reach the output (the text pipeline can't carry
  them), instead of losing them silently.
- **S3 — overwrite guard (app).** Output path equal to the input
  path is refused in both pipelines before anything runs.
- **S4 — checkpoint fingerprint + universal revalidation (app).**
  Checkpoints now record the model and a hash of the style
  directives; changing either starts fresh instead of silently
  mixing outputs. Revalidation now runs for multi-stage
  checkpoints too (previously single-stage only — and multi-stage
  is the default): stored chunks are judged as the final stage's
  output with the loosest drift cap in the chain; the artifact,
  heading, and duplication gates always apply; the invariance
  family applies when every stage in the chain is bound by it.
- **S5 — co-author corrections audited (orchestrator).** A
  corrective pass that fails its own audit now discards the block
  (logged) instead of shipping unreviewed text — the blind-
  correction pattern the edit pipeline lost in round 12.
- **S6 — post-save whole-book audit (app).** After the final save,
  the app re-opens the output and grades it against the input:
  total and per-section drift vs. the run's cap, missing/invented
  sections, straight-quote census, names present in the output but
  nowhere in the input, hyphenated-term census. Verdict goes to
  the log; the full report is written to `<output>.report.txt`.
  Headings that lost their style are still found (markdown lines
  and known-heading matching, whitespace-free keys).
- **S7 — one vocabulary (vocab.py).** The WatchTower list, the
  Scribe's three prompt lists, and the Co-Author directives all
  render from one module now. The deterministic banned check is a
  delta check: it rejects only words the edit INTRODUCES — the
  author's own 'beacon' is his to keep.
- **S8 — noun audit retired (WatchTower).** `differential_audit`
  is drift-only; the round-14 invariance gate does the noun job
  exactly (and catches one foreign name, not four).
- **S9 — prompt contradiction fixed (Scribe).** The mechanical
  prompt no longer bans semicolons while mandating comma-splice
  fixes; structural changes are banned, punctuation-level splice
  repair is explicitly allowed.
- **S10 — honest auditor (WatchTower).** Neutral fidelity prompt
  (no more "ruthless literary fiction" for nonfiction), the
  author's directives ride along as the standard, audit calls run
  at temperature 0, and unchanged or punctuation-only chunks skip
  the LLM audit entirely — deterministic gates already cover them.
- **S11 — think-off + one stripper (engine + app).** New "No-
  think" checkbox (default off, saved in config): when on, every
  Ollama request carries `think: false`, so reasoning models skip
  the trace instead of generating text the pipeline deletes. The
  three think-strippers collapsed into one canonical function in
  the engine.
- **S12 — co-author/keeper loose ends.** CoAuthor's dead
  `bible_path`/`previous_chunk` parameters deleted (the
  orchestrator already folds both into the prompt); word-limited
  streams now end at a sentence boundary instead of mid-sentence;
  the Keeper ledger is capped (2,000 words, then folded down by a
  compression pass) and no longer passes through the save
  sanitizer.
- Also fixed, found by the new audit's first test run: the
  invariance gate's foreign-name set normalized possessives
  differently from its candidate keys, so a name the original used
  only possessively ('Danth's') could false-fire when used plainly
  later. Both sides now use the same normalization.
- Verified: Broken no-edit round trip still exact (77,814 words,
  28/28 headings); Hey Y'All round trip +0 words (was −1,568);
  48 automated tests across the gate suite, feature tests,
  orchestrator/keeper e2e, and app-level checkpoint/audit tests —
  including the post-save audit run against the actual failed OE
  file, whose report names the term swap, the 638 straight
  quotes/apostrophes, and 'unscheduled' as the one genuinely new
  name, with all 28 sections matched.

## Content invariance + heading round-trip (Oct 21 — build 2026-10-21a)

Triggered by a full-novel run of THE BROKEN (77,814 words) that came
back structurally intact (−0.05%, every chapter in order) but
rewritten wherever the model touched it: numbers mutated
(thirty-three minutes → fifty-three; six hours → eleven; the
forty-first rifle mark → the forty-second), the bow kid Corb renamed
Joss in all five mentions, Ch 1's anonymous scope tech named "Voss"
(the medic), fragment-pods → fragment-vessels in 8 places, invented
slang "corrected" (varn → varnish / vart), whole passages swapped
for treatment-summary paraphrase, two editor artifacts embedded in
Ch 21 (a literal "[paragraphs deleted]" paragraph and an HTML
comment tallying words cut), 549 straight apostrophes + 90 straight
double quotes across 11 chapters, and every chapter heading demoted
to a plain "# CHAPTER 1The Arithmetic" line. None of the existing
gates could see same-length swaps inside the book's own vocabulary.

- **Heading round-trip fixed (engine).** Root cause: `_para_to_
  markdown` read run text via `run.text`, which drops `<w:br/>`, and
  its whitespace handling stripped the break at run boundaries — so
  a two-line heading ("CHAPTER 1" / "The Arithmetic") reached the
  chunk text fused, and the save-side matcher could never match it
  against the known-headings set. Runs are now read break-aware,
  leading/trailing whitespace (breaks included) is preserved,
  headings are serialized as one line per heading, and the loader
  records each heading's original display text; save promotes a
  matching `#` line back to the heading style and restores the
  original line breaks. A whitespace-free fallback match rescues
  headings the model itself fused. Body soft breaks now survive as
  line breaks instead of fusing words ("Chihuahua.If" → two words
  again). Verified on the novel: load → save with no edits returns
  77,814 words and all 28 headings byte-identical.
- **Content invariance gate (WatchTower).** New deterministic
  check, `_check_content_invariance`, in `inspect_chunk` for Line
  Edit / Copy Edit / Proofread (inert for Developmental): the
  multisets of numbers (digits, number words, ordinals, hyphenated
  compounds), tracked proper names, and hyphenated terms must match
  the source chunk exactly, and no capitalized name may appear
  mid-sentence that has no fused form anywhere in the source (one
  is enough — the old differential audit needed 3+ distinct). The
  rejection itemizes lost/gained items so the correction pass can
  restore them verbatim; unfixable chunks fall back to the original
  as always.
- **Quote-style gate (WatchTower).** `_check_quote_style`: in a
  curly-quoted manuscript, an edit may not introduce straight
  double quotes or straight apostrophes beyond the source's own
  count, and if the source's curly double quotes balance, the
  edit's must too (catches the dropped opening quote).
- **Editor-artifact gate + sanitizer backstop.** `_check_no_editor_
  artifacts` rejects chunks containing HTML comments or bracketed
  deletion markers ("[paragraphs deleted]") at every stage; the
  engine sanitizer also strips both at save time. Narrow patterns:
  the author's own bracketed placeholders ("[DEDICATION: …]",
  "[SOURCE DOCUMENT]") carry no deletion verb and are untouched.
- **App:** all three checks join the resume-revalidation set, so
  stored checkpoint chunks are re-audited under the new gates.
- **Build tag (orchestrator).** `BUILD_TAG = "2026-10-21a"` is
  stamped into the first log line of every chunk pass, so a pasted
  log excerpt identifies the build that produced it.
- Verified: the 11 damaged chapters of the actual failed run now
  reject (invariance fires on all 11; quote gate on 5; artifact
  gate on Ch 21); 22 gate unit tests built from the run's real
  failures pass, including the controls (unchanged prose, a
  comma-splice fix, and the round-11 AgentQuery capitalization case
  all still pass); mock-Ollama end-to-end: a number-mutating edit
  gets two audited corrections and falls back to the original when
  neither restores it; Hey Y'All round trip shows no regression
  vs. the previous build (−1,568 words vs. its −1,572 on a pure
  no-edit round trip — that gap predates this round — and the old
  build's cross-break word fusions are fixed).

## Short-line preservation check (Oct 20 — the label/caption leak)

Every run so far lost the same species of text: short standalone
lines — the "5- Rung Climb" caption and "RUNG 2" label in Ch 8,
list subheads 3 and 4 in Ch 18, both "No-code summary" lines in
Ch 20, the "Final Export" line up front. ~85 words a run, invisible
to the word-count drift gate (an 8-word label inside a 1,500-word
chunk is rounding error). The FPR run was otherwise the first
fully clean end-to-end run: no section beyond ±2%, zero leaks,
KDP formatting perfect.

- **WatchTower:** new deterministic check,
  `_check_short_lines_preserved`, running in `inspect_chunk` for
  the Line Edit / Copy Edit / Proofread stages. Every source line
  of 2–30 words must survive recognizably in the edited text —
  verbatim, lightly edited (≥75% word overlap with its best-matching
  edited line), split across two consecutive lines, or merged with
  a neighbor all count; dropped is dropped. Table rows are exempt
  (they travel as blocks). The rejection **quotes the missing
  lines**, so the correction pass — which now receives real
  feedback — can restore them verbatim instead of guessing.
- **App:** the same check joins the resume-revalidation set, so a
  stored checkpoint chunk missing labels is reprocessed rather
  than shipped. No schema bump needed: revalidation catches the
  old sidecars' gaps.
- Verified against the actual lost lines: dropped caption/RUNG 2
  and the truncated summary line reject by name; typo-fixed,
  split, and merged variants pass; the check is inert for
  Developmental edits; end-to-end, a model that drops the lines
  gets them quoted back in the correction feedback, restores them,
  and the chunk is approved. Prior suites (noun audit, think-model,
  fit guard) still pass.

## Full-proofread run audit + checkpoint trust fix (Oct 20)

Bob ran the full book (55,930 words) and asked "how did we do."
Measured verdict on the output: KDP formatting perfect (6×9,
mirrored margins, Garamond 11 justified); 28 of 30 sections within
±2%; but real damage in three places — Chapter 7 lost its entire
second half (−471 words: the two-Sticky-Notes payoff, the Context
Checklist, the Weak Prompt example), Chapter 5's worked-example
tail went missing again (−89 words), 7 "Here is the edited text…"
narration paragraphs leaked into the book, and the two '#'-line
heading traps were promoted again. A repaired copy was delivered
alongside this zip (all three sections back to exact baseline word
counts; total −0.16%).

Root-cause notes, measured rather than guessed: the shipped gates
make a −38% single-chunk loss arithmetically impossible through
the audited path at any chunk size, and the heading guard was
re-verified against the actual input file (both trap lines demote
correctly). The one door the shipped design left open: **resume
trusted stored checkpoint chunks without re-auditing them.** A
sidecar written under any earlier gate regime could carry damaged
chunks straight into the final save. Closed here:

- **App:** checkpoints now carry a schema marker (v2); sidecars
  from older builds are discarded with a fresh start instead of
  resumed. On resume of a single-stage run, every stored chunk is
  revalidated against its source chunk with the structural checks
  (drift at the run's cap, duplication, heading preservation); the
  first failing chunk and everything after it are reprocessed.
  (Multi-stage sidecars hold post-final-stage text the per-stage
  caps don't describe, so they rely on the schema marker.)
- **Engine:** the save-path sanitizer now also drops standalone
  preamble lines **anywhere** in a chunk, not just at the top —
  the "...preserving the original formatting and adhering to the
  mandate:" variants that leaked. A line qualifies only if it
  starts with the preamble formula, has no sentence punctuation,
  and ends with a colon; verified against all 7 leaked variants
  plus legitimate look-alike lines, which are kept.

## Correction attempts fix (Oct 20 — blind correction, single attempt)

Symptom: "We seem to be failing the first try then not retrying
before we keep the original — we used to make 2 attempts." The
comparison, honestly stated: the original loop shipped its
correction **unaudited** (edit → audit → correct → use it), so the
second attempt always landed in the book. The do-no-harm restructure
audited the correction and fell back when it failed — safer, but it
exposed a defect that had been there all along:

- **`ScribeAgent.correct()` accepted the WatchTower's feedback and
  never put it in the prompt.** The model was told to "fix the
  specific violation flagged in the feedback" and never shown any
  feedback. Every correction was a blind re-polish; against a
  deterministic rejection (drift, banned word, invented noun) it
  failed the same gate again, and the chunk fell back to the
  original. Present in the original code too — the unaudited ship
  just hid it.

Fixes:

- **Scribe:** the correction prompt now carries a WATCHTOWER
  FEEDBACK block with the audit's actual message (capped at 2,000
  characters; the violation text leads, so a story bible appended
  after it can't push it out).
- **Orchestrator:** up to **two** correction attempts per chunk.
  Each starts from the latest candidate, is fed the latest audit
  feedback, and is audited before acceptance; the log numbers them
  ("Refining correction (attempt 1 of 2)..."). If neither passes,
  the original is still kept — do-no-harm unchanged. This also
  fixes the Co-Author corrective pass, which calls the same
  `correct()`.
- Verified with a scripted Ollama: feedback present in the
  correction prompt; a chunk fixed on the first correction is
  returned; a chunk fixed on the second is returned after exactly
  two attempts; an unfixable chunk makes exactly two attempts and
  keeps the original. Cost note: a stubborn chunk now costs up to
  3 edit passes + 3 audits instead of 2 + 2 — only on chunks that
  fail the first audit.

## Proper-noun audit fix (Oct 20 — "hallucinated proper nouns" rejections)

Symptom: every Proofread chunk rejected with "Differential Audit
Violation: Detected potential hallucinated proper nouns not present
in original text", correction attempt, original kept. Two defects in
the WatchTower's proper-noun scan, both reproduced before fixing:

- **Reasoning residue was being audited as manuscript.** Nothing
  stripped `<think>` blocks between the model and the audit. A
  reasoning model's preamble ("I will review the Grammar, the
  Punctuation, the Consistency of names, and the Markdown
  Formatting…") is full of capitalized words that appear nowhere in
  the book — instant "hallucinated names" on every chunk, and its
  word count also ate into the drift allowance.
- **The matcher itself was rigged against a proofread.** It checked
  each capitalized word's fused lowercase form ("don't" → "dont")
  as a *substring of the raw original text* — where the apostrophe
  in "don't" guarantees "dont" never matches. So the proofread's
  own legitimate capitalization work (don't → Don't mid-sentence,
  agent_query → AgentQuery) counted as foreign names. Four or more
  in a chunk = rejection.

Fixes:

- **Scribe:** all edit/correction returns now pass through a
  reasoning-strip (`<think>`, `<thought>`, ```thought fences), so
  audits, corrections, checkpoints, and saves only ever see the
  edited text itself.
- **WatchTower:** `inspect_chunk` strips reasoning from the
  candidate before every check, and the noun scan now compares
  against a token set normalized identically on both sides — a
  capitalized word is foreign only if its fused lowercase form
  appears nowhere in the original, in any case.
- **Engine:** the save-path sanitizer's strip pattern now includes
  `<think>...</think>` (it previously covered only `<thought>`).
- Verified: think-wrapped edits pass end-to-end through the full
  audit path; capitalization/contraction fixes pass; genuinely
  invented names (4+ new proper nouns) are still rejected; drift
  and banned-vocabulary guards unchanged.

## Proofread fallback fix (Oct 20 — the 3072 context clamp)

Symptom: "I always seem to hit the fallback." Proofread chunks rejected
for word-count drift (one log: 1604 → 1027 words, −36%), a correction
attempt, then the original kept. Root cause: `ScribeAgent.edit` clamped
the context window per stage — **Proofread to 3072 tokens**, Line/Copy
Edit to 4096 — no matter what the UI's Context Limit said. A book-size
chunk plus its instructions runs ~2,500 tokens of prompt, so inside a
3072 window the model had only a few hundred tokens of reply room
before generation stopped at the window edge. The "edited" chunk came
back truncated; the WatchTower rightly rejected it; the correction
pass — which only ever sees the truncated text — could never restore
the missing third. The fallback did its job (nothing was lost), but
the proofread silently wasn't editing anything.

- **Scribe:** every stage now uses the caller's Context Limit,
  unclamped. Want a smaller window for speed? Set it in the UI.
- **Engine:** `call_ollama` gained a fit guard. It measures the
  prompt, estimates the reply (edit passes: input × 1.25 + 256;
  other calls: +512, or the target-word budget for generation), and
  if prompt + reply exceeds the requested window it raises `num_ctx`
  to fit, capped at 16384. The Context Limit is now a floor, not a
  ceiling.
- Verified against a mocked Ollama: a 1,604-word proofread chunk at
  Context Limit 8192 now requests num_ctx 8192 (was 3072); at 4096
  the guard raises it to fit (~5,600); small chunks unchanged; an
  end-to-end orchestrated proofread comes back approved instead of
  falling back.

## KDP output formatting (Oct 20 — output is now print-ready)

The save path used to rebuild every output in a blank template with
hardcoded formatting (0.3in first-line indents, zero paragraph spacing)
regardless of the source document — that's what mangled the Hey Y'All
proofread's layout. It also promoted any line starting with '#' to a
heading, so code comments inside examples became fake chapter headings.
Both are fixed (engine.py + app.py):

- **New "KDP Format (6x9 print layout)" checkbox** in Engine & Watch
  Tower Settings, on by default, with **Indented / Spaced** paragraph
  radios beside it (Indented = fiction style; Spaced = flush-left with
  10pt after, the Hey Y'All look). Both settings persist in the config.
  With KDP on, output gets: 6x9in trim, mirrored margins (0.75in
  inside, 0.5in outside/top/bottom), Garamond 11pt body, justified
  text, 1.15 line spacing, black Garamond headings with every
  Heading 1 starting a new page, and scene breaks printed centered.
  The first paragraph after a heading, blank line, or scene break
  carries no indent (typesetting convention); the rest carry the 0.3in
  indent in Indented mode.
- **Heading guard (always on for edit-pipeline saves):** the loader
  records the source document's real heading texts, and the saver only
  promotes '#' lines that match one. A '#' line that was body text in
  the source — a code comment, a prompt marker — stays body text, '#'
  and all. Co-author saves are exempt (their headings are new).
- With KDP off, saving behaves exactly as before, apart from the
  heading guard on edit-pipeline saves.

Verified headlessly: a synthetic manuscript through load + save in all
four modes (KDP indented, KDP spaced, legacy, legacy + guard) — trim,
margins, mirror margins, fonts, justification, indents, page breaks,
table round-trip, and the '#' comment case all check out, and the
rendered first page was inspected. The GUI itself still needs a run on
your machine (no display or Ollama here).

## Window fit (Oct 20)

The window opened at a fixed 850x1050, which barely fits — or doesn't
— on shorter screens; the KDP row made it worse. Now the window sizes
itself to the screen (at most 850x950, smaller on small displays,
minimum 700x520, centered), and the five settings panels live in a
scrollable area: if they don't all fit, they scroll, while the
Run/Stop buttons, progress bar, status line, and log stay pinned and
always visible. Verified by launching the real window at 1366x768 and
1920x1080 under customtkinter 5.2.2 and 6.0 and screenshotting it.

## Do-no-harm update (Oct 19 — the editor halved a 56K manuscript)

Root cause: the WatchTower gate was advisory. A chunk the model gutted would
be rejected, get one correction pass, and then be **accepted anyway** — the
code returned the unapproved correction. The model also dropped `#` chapter
heading lines, merging neighboring chapters under surviving headings.

- **Orchestrator: unapproved chunks now fall back to the original text.**
  If the WatchTower never approves a chunk, the pipeline keeps the original
  instead of the mangled correction. Worst case is now unedited text, never
  deleted text — output can no longer come back shorter than the input.
- **WatchTower: deterministic heading check.** Dropping an original `#`
  heading, or inventing a new one during Line/Copy/Proofread, is now a
  hard rejection (which triggers the do-no-harm fallback above).
- **Engine: the edit prompt now says** "Preserve blank lines exactly as they
  appear — they mark scene breaks. Never drop, merge, or invent '#'-style
  headings."
- **Co-author: degenerate blocks (<20 words) are discarded** instead of
  being silently saved into the manuscript.

## Proofread levels (Oct 19 — selectable in the UI)

New "Proofread level" radio buttons in the Editing Stages panel:
- **Light (grammar, spelling, dedup, ±2% cap)** — the default. Single
  mechanical pass only (spelling, punctuation, comma splices, typos), with
  an explicit "do not delete, condense, or reorder anything" order in the
  prompt; de-duplication is still enforced by the WatchTower's deterministic
  check. The ±2% word-count leash means a spelling pass can't cut content —
  anything over it keeps the original chunk. Faster, too: one LLM call per
  chunk instead of two.
- **Full (style polish, ±5% word cap)** — the previous two-pass proofread
  (mechanical + stylistic), but the WatchTower now enforces a ±5% word-count
  drift limit instead of 15%. Anything over the cap falls back to the
  original chunk via the do-no-harm rule, so the cap is actually a cap.
- The selected level is saved in the config and is part of the checkpoint
  fingerprint, so changing it starts a fresh run instead of resuming one
  edited under the other level.
- The correction pass is now audited before acceptance (the old retry loop
  ran it but never checked the result, discarding it).

## Post-delivery fix (Oct 19, afternoon)
- **app.py — checkpoint fingerprint now covers the input file itself.**
  Resume was keyed on input *path* only, so editing the source .docx and
  re-running with the same settings would silently resume from the OLD run's
  chunks, mixing two different edits in one output. The checkpoint now stores
  the input file's mtime+size; a changed source file (or an older checkpoint
  without a signature) starts fresh with a log line instead of resuming.

## Critical fixes

1. **engine.py — `call_ollama` stream handling**
   - Blank keepalive lines are now skipped instead of crashing `json.loads`.
   - A stream that ends without `done:true` returns what was generated
     instead of re-sending the request forever (`attempt` never incremented).
   - `json.JSONDecodeError` is now a retried error, not an instant kill.
   - New `CancelRequested` exception so a user cancel is distinguishable
     from a real failure.
2. **engine.py — document structure round-trip**
   - Headings are converted to markdown (`#`, `##`…) on load and restored
     to Word heading styles on save. Chapter titles no longer come back
     as indented body text.
   - Blank paragraphs / scene breaks are preserved instead of dropped.
   - Tables are converted to markdown on load and rebuilt as Word tables
     on save (previously silently discarded).
   - `num_thread` now defaults to your CPU count instead of hardcoded 8.
   - Edit passes get a `num_predict` cap (~1.6x input tokens) so the model
     can't return 5x what it was given.
3. **watchtower_agent.py — recalibrated gates**
   - Human-score threshold 0.80 → 0.65. The old value rejected ordinary
     well-written prose (measured 0.754 on a clean sample), forcing a
     wasted correction pass on nearly every chunk.
   - Word-count drift limits are now per-stage: 35% for Developmental Edit,
     25% for Combined Edit, 15% otherwise. The flat 15% was rejecting
     legitimate developmental rebuilds.
   - The audit's `STATUS: APPROVED` check now strips `<think>` blocks first,
     so reasoning models don't fail every audit.
   - The LLM audit call now honors the `context_limit` you pass in
     (was hardcoded 4096).
4. **orchestrator.py / coauthor_agent.py — the bible actually works now**
   - `generate_new_content` was accepting `bible_path` and `previous_chunk`
     and dropping both; they're now injected into the prompt (bible as a
     canon lock, previous block tail for continuity).
   - `write_section` now passes `target_word_limit`, so `num_predict` is
     set and blocks respect your word-count targets.
5. **app.py — cancel is graceful**
   - Pressing Stop no longer pops a "CRITICAL ERROR" dialog; cancels log
     and report as cancelled.
6. **app.py — co-author robustness**
   - Checkpoint save every 5 blocks to `<output>.partial.docx`.
   - Iteration cap at 3x the expected block count (a stingy model can't
     loop forever).
   - No file is written when nothing was generated (previously saved an
     empty .docx over your output path).

## 60K-manuscript hardening (same day — "will it hold together")

- **Edit pipeline: checkpoint + resume.** Every 5 chunks it now writes
  `<output>.progress.json` (exact edited chunks + input/settings fingerprint)
  and `<output>.partial.docx` (human-readable). A crash or cancel no longer
  loses hours of work — re-running the pipeline resumes where it stopped.
  The fingerprint covers input file, chunk size, chunk count, and stages, so
  changed settings start fresh instead of resuming garbage. Sidecars are
  deleted on a clean finish.
- **Continuity across chunk boundaries (all agents).** The edit pipeline used
  to treat every chunk as an island. Now the tail of the previous edited
  chunk is passed through the whole chain: the Scribe sees it as
  CONTINUITY CONTEXT in both `edit()` and `correct()`, and the WatchTower's
  audit prompt flags contradictions with it.
- **Keeper: rolling continuity ledger.** The old `summarize_state` re-read
  the last 3 blocks every generation block — a sliding window that forgot
  everything older, at O(n²) cost. Now each block folds only the newest text
  into a running ledger, so a 60K-word generation keeps its early chapters
  in memory and each block costs one small summarization. (This also removes
  one LLM call per block — the app no longer summarizes separately.)
- **Keeper: story bible is cached** (path + mtime) instead of re-read from
  disk on every chunk.
- **Co-author cleanup:** removed the dead `bible_content` block in app.py
  (it loaded the bible and never used it — the orchestrator loads it via
  the Keeper).

## Follow-up fixes (same day — slow runs + edit notes in output)

- **Edit notes in output:** the model prompt now says "Return ONLY the edited
  text — no preamble, no explanation, no summary of changes, no code fences"
  (edit passes) and "Return only the section text" (co-author). The sanitizer
  additionally strips: fenced code blocks (closed or unclosed), leading
  preamble lines ("Here is the edited text:", "Sure, here..."), and trailing
  meta-commentary ("Changes made:", "Summary:", "Note:...") — the trailer cut
  only fires in the back half of the text so real content is safe.
- **Speed — the UI's Context Limit was ignored:** `ScribeAgent.edit()` used
  hardcoded context sizes and never read the setting. It now honors it
  (smaller = faster).
- **Speed — new "Fast QA" checkbox** (Engine & Watch Tower Settings): skips
  the per-chunk LLM audit call and runs deterministic checks only. Roughly
  halves the LLM calls per chunk; pairs with Fast Mode.
- If it's still slow after those, the remaining lever is the model itself —
  a smaller/faster Ollama model is the single biggest speedup available.

## Smaller fixes

- `ScribeAgent.correct()` honors the `context_limit` parameter (was 4096 hardcoded).
- `CONFIG_FILE` is anchored to the script's directory, not the launch CWD.
- `tiktoken` is now a soft dependency — if it's missing, the engine uses the
  word-based token fallback instead of refusing to import.
- `requirements.txt` added (customtkinter, python-docx, tiktoken).

## Known limitations (not fixed)

- Images and headers/footers are still dropped on load — there's no
  text-safe way to round-trip them through an LLM.
- `agents/` package layout assumed (`agents/__init__.py` + agent modules
  inside); keep your existing directory.
