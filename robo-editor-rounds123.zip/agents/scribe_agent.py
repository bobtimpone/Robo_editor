import re

from engine import strip_reasoning_blocks

try:
    from agents.vocab import (banned_clause, STAGE_PROOFREAD,
                              STAGE_DEVELOPMENTAL, STAGE_LINE,
                              STAGE_COPY, STAGE_COMBINED)
except ImportError:  # flat layout (tests, direct runs)
    from vocab import (banned_clause, STAGE_PROOFREAD,
                       STAGE_DEVELOPMENTAL, STAGE_LINE,
                       STAGE_COPY, STAGE_COMBINED)

# Rendered from the one shared list (vocab.py) so the words the Scribe
# is told to avoid are exactly the words the WatchTower rejects (S7).
_BANNED_CLAUSE = f"BANNED WORDS/PHRASES: {banned_clause()}."


class ScribeAgent:
    def __init__(self, engine, model):
        self.engine = engine
        self.model = model

    @staticmethod
    def _strip_reasoning(text):
        """Delegates to the engine's canonical stripper (round 15, S11:
        one implementation, three former copies)."""
        if not text:
            return text
        return strip_reasoning_blocks(text).strip()

    def _get_mechanical_prompt(self):
        return (
            "SYSTEM: Strict Orthographic Guardrail & Negative Constraints.\n"
            f"{_BANNED_CLAUSE}\n"
            "MANDATE: Fix ONLY spelling errors, punctuation, comma splices, and glaring typos. "
            "ABSOLUTE PROHIBITIONS:\n"
            "- DO NOT alter, rewrite, or expand any sentences, paragraphs, or dialogue.\n"
            "- DO NOT delete, condense, summarize, or reorder any content. Every sentence in the input must appear in the output, in the same order.\n"
            "- If there is nothing to fix, return the text unchanged.\n"
            "- DO NOT change established character names, locations, or proper nouns from the source text.\n"
            "- DO NOT swap POVs or alter existing character actions.\n"
            # The old wording banned "add clauses/semicolons" outright —
            # while mandating comma-splice fixes, whose standard repair
            # IS a semicolon. The model was told to do and not-do the
            # same thing (review S9).
            "- DO NOT merge or split sentences or paragraphs. Punctuation-level repairs are allowed where they fix an error — including a semicolon in place of a comma to repair a comma splice.\n"
            "Return the exact text with only mechanical typos corrected."
        )

    def _get_stylistic_prompt(self):
        return (
            "SYSTEM: Sub-surface Prose Polish Guardrail & Negative Constraints.\n"
            f"{_BANNED_CLAUSE}\n"
            "MANDATE: Fix rhythmic clunkiness or mechanical phrasing *only* within the exact sentence boundaries provided. "
            "ABSOLUTE PROHIBITIONS:\n"
            "- DO NOT add external exposition, zoom-outs, or background text not present in the source.\n"
            "- DO NOT delete launch sequences, narrative momentum, or defensive silences.\n"
            "- PRESERVE original stylistic tics, motifs, and rhythmic patterns."
        )

    def edit(self, text, stage, style_prompt="", context_limit=4096, stream_callback=None, continuity_context="", proofread_level="full"):
        # Every stage gets the caller's Context Limit, unclamped. (Proofread
        # used to be capped at 3072 and Line/Copy at 4096 regardless of the
        # UI setting. With book-size chunks the prompt alone nearly fills a
        # 3072 window, so generation stopped at the window edge and the
        # "edited" chunk came back truncated — the WatchTower then rejected
        # it for word-count drift on every chunk, and the pipeline fell
        # back to the original text. If a smaller window is wanted for
        # speed, it can be set in the UI; the engine's fit guard raises it
        # again when a chunk genuinely doesn't fit.)
        context_size = context_limit

        # Tail of the previous chunk, so edits stay consistent across chunk
        # boundaries (names, pronouns, tense). Never part of the output.
        continuity_block = (
            f"\n\nCONTINUITY CONTEXT — the end of the previous chunk (already edited). "
            f"Keep names, pronouns, and tense consistent with it. Do NOT repeat it, "
            f"do not summarize it:\n{continuity_context[-1500:]}\n"
            if continuity_context else ""
        )

        if stage == STAGE_PROOFREAD:
            mech_prompt = self._get_mechanical_prompt() + style_prompt + continuity_block
            intermediate_text = self.engine.call_ollama(
                model=self.model, system_prompt=mech_prompt, text=text,
                context_size=context_size, stream_callback=None, is_edit_pass=True
            )

            # Light proofread = grammar/spelling/dedup only. De-duplication is
            # enforced by the WatchTower's deterministic check, so one pass suffices.
            if proofread_level == "light":
                return self._strip_reasoning(intermediate_text)

            style_prompt_full = self._get_stylistic_prompt() + style_prompt + continuity_block
            return self._strip_reasoning(self.engine.call_ollama(
                model=self.model, system_prompt=style_prompt_full, text=intermediate_text,
                context_size=context_size, stream_callback=stream_callback, is_edit_pass=True
            ))

        prompts = {
            STAGE_DEVELOPMENTAL: "You are a pragmatic developmental editor. Rebuild text section by section with organic structures while preserving core character decisions.",
            STAGE_LINE: "You are a line editor. Strip out robotic formatting while keeping canon names, character POVs, and dialogue beats intact.",
            STAGE_COPY: "You are a copy editor. Correct syntax while preserving grit, dialogue interruptions, and defensive silences.",
            STAGE_COMBINED: "Apply structural, line, and copy-editing standards simultaneously while maintaining absolute canon and character fidelity."
        }

        sys_prompt = prompts.get(stage, prompts[STAGE_LINE]) + style_prompt + continuity_block + "\n" + self._get_stylistic_prompt()
        return self._strip_reasoning(self.engine.call_ollama(
            model=self.model, system_prompt=sys_prompt, text=text,
            context_size=context_size, stream_callback=stream_callback, is_edit_pass=True
        ))

    def correct(self, text, feedback, context_limit=4096, stream_callback=None, continuity_context=""):
        continuity_block = (
            f"\n\nCONTINUITY CONTEXT — the end of the previous chunk (already edited). "
            f"Keep names, pronouns, and tense consistent with it. Do NOT repeat it:\n{continuity_context[-1500:]}\n"
            if continuity_context else ""
        )
        # The feedback MUST reach the prompt. (It never did — in this
        # version or the original: correct() accepted the argument and
        # dropped it, so every correction was a blind re-polish that
        # usually failed the same audit again.) The violation text leads
        # the string the orchestrator passes, so the cap keeps it intact
        # even when a story bible rides along at the end.
        feedback_block = (
            f"\n\nWATCHTOWER FEEDBACK — the specific violation to fix:\n{feedback[:2000]}\n"
            if feedback else ""
        )
        sys_prompt = (
            "SYSTEM: Scribe Correction Pass & Negative Constraints.\n"
            f"{_BANNED_CLAUSE}\n"
            "CRITICAL: Fix ONLY the specific violation flagged in the feedback. Do not rewrite surrounding paragraphs, "
            "do not introduce new characters or exposition, and do not alter canon names or pacing blocks."
        ) + "\n" + self._get_stylistic_prompt() + feedback_block + continuity_block
        # Was hardcoded to 4096, ignoring the caller's context_limit.
        return self._strip_reasoning(self.engine.call_ollama(
            model=self.model, system_prompt=sys_prompt, text=text,
            context_size=context_limit, stream_callback=stream_callback, is_edit_pass=True
        ))
