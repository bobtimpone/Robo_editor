"""Shared canon vocabulary for the robo-editor agents.

One home for the banned-word lists. Before this module existed there
were three divergent copies — the WatchTower's deterministic list,
the Scribe's prompt lists, and the Co-Author's directive list — and
they disagreed: the Scribe was told to avoid 'robust' but the tower
never checked it; the tower rejected 'beacon' but the Scribe was
never told. Prompts and gates are now both rendered from the lists
below, so what the model is told and what it is graded on can't
drift apart again.

Ships with the agent modules (agents/ folder on the user's machine).

BANNED_TERMS semantics: a term only rejects when an edit INTRODUCES
it — the author's own text may contain any of these words; they are
his to keep. (The deterministic check is a delta check.)
"""

# Words/phrases no agent may introduce into a manuscript.
BANNED_TERMS = [
    "delve", "tapestry", "beacon", "crucible", "cornerstone",
    "symphony", "labyrinth", "testament", "underscore", "highlight",
    "realm", "robust", "multifaceted", "nuanced", "leverage",
    "utilize", "crucial",
    "palpable tension", "palpable void", "electric candle",
    "a reminder that",
    "moreover", "furthermore", "consequently",
]

# Specific canon rules with their own rewrite instructions, checked by
# the WatchTower's vocabulary guardrails.
GUARDRAIL_RULES = [
    ("palpable tension",
     "Watchtower Rule: Used 'palpable tension' (must be close enough to touch or shown via hands)."),
    ("palpable void",
     "Watchtower Rule: Used 'palpable void' (must be outright cut)."),
    ("electric candle",
     "Watchtower Rule: Used 'electric candle' (must be 'battery candle')."),
    ("a reminder that",
     "Watchtower Rule: Used transition 'a reminder that' (must be deleted)."),
]

# Extra filler phrases banned only in co-author generation.
COAUTHOR_EXTRA_PHRASES = [
    "In today’s fast-paced world...",
    "It’s worth noting that...",
    "At its core...",
    "In the realm of...",
    "Seamless integration",
    "A testament to...",
]

# Cliché-metaphor note for co-author generation.
COAUTHOR_CLICHE_NOTE = (
    "NO CLICHÉ METAPHORS: Never compare software or abstract concepts "
    "to a 'Swiss Army knife', 'GPS', or 'personal trainer'."
)


def banned_clause():
    """The BANNED list rendered for embedding in a prompt."""
    return ", ".join(f"'{t}'" for t in BANNED_TERMS)


# --- Pipeline stage names (round 16, S13) ---
# Stage names were string literals in 27 places across four files; a
# typo in any one of them silently changed behavior (an unknown stage
# fell through to the Line Edit prompt, gates keyed off exact strings
# quietly no-oped). One definition, imported everywhere.
STAGE_DEVELOPMENTAL = "Developmental Edit"
STAGE_LINE = "Line Edit"
STAGE_COPY = "Copy Edit"
STAGE_PROOFREAD = "Proofread"
STAGE_COMBINED = "Combined Edit"
STAGE_COAUTHOR = "Co-Author Generation"

# Stages in the app's Editing Stages panel, in pipeline order.
EDIT_STAGES = (STAGE_DEVELOPMENTAL, STAGE_LINE, STAGE_COPY, STAGE_PROOFREAD)

# Stages whose output must preserve the source's facts verbatim — the
# invariance family of gates binds exactly these. Round 3 (R22):
# Combined and Developmental edits are bound too — they are still
# edits of a source text, not licences to renumber, rename, or
# requote it. The one recognised stage that is NOT bound is
# Co-Author Generation (STAGE_COAUTHOR): it has no source text to
# preserve (its original is empty), so the invariance family cannot
# judge its output. Any other, unrecognised stage string is treated
# as bound by the WatchTower (fail-safe) rather than silently
# disabling the gates — see WatchTowerAgent._is_rewrite_bound.
REWRITE_BOUND_STAGES = frozenset({
    STAGE_LINE, STAGE_COPY, STAGE_PROOFREAD,
    STAGE_COMBINED, STAGE_DEVELOPMENTAL,
})

# Recognised stages the invariance family deliberately does not bind.
REWRITE_UNBOUND_STAGES = frozenset({STAGE_COAUTHOR})
