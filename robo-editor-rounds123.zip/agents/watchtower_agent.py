import statistics
import re

from engine import strip_reasoning_blocks

try:
    from agents.vocab import (BANNED_TERMS, GUARDRAIL_RULES,
                              STAGE_DEVELOPMENTAL, STAGE_COMBINED,
                              STAGE_COAUTHOR,
                              REWRITE_BOUND_STAGES, REWRITE_UNBOUND_STAGES)
except ImportError:  # flat layout (tests, direct runs)
    from vocab import (BANNED_TERMS, GUARDRAIL_RULES,
                       STAGE_DEVELOPMENTAL, STAGE_COMBINED,
                       STAGE_COAUTHOR,
                       REWRITE_BOUND_STAGES, REWRITE_UNBOUND_STAGES)

class WatchTowerAgent:
    # Drift limits are per-stage: a developmental rebuild legitimately moves
    # more words than a proofread. One flat 15% limit fought the Scribe.
    DRIFT_LIMITS = {
        STAGE_DEVELOPMENTAL: 0.35,
        STAGE_COMBINED: 0.25,
    }
    DEFAULT_DRIFT_LIMIT = 0.15

    # The old 0.80 threshold rejected ordinary well-written prose in testing
    # (measured 0.754 on a clean sample). 0.65 keeps the gate meaningful —
    # with no banned openings the floor is 0.70, so this now fires only on
    # real penalties instead of on normal cadence.
    HUMAN_SCORE_THRESHOLD = 0.65

    def __init__(self, engine, model):
        self.engine = engine
        self.model = model
        # Advisory notes from the most recent inspection (round 16,
        # S13): the human score reports here instead of rejecting —
        # callers drain and log them via pop_warnings().
        self._warnings = []

    def pop_warnings(self):
        warnings, self._warnings = self._warnings, []
        return warnings

    @staticmethod
    def _is_rewrite_bound(stage):
        """Round 3 (R22), fail-safe stage binding: every recognised
        edit stage in REWRITE_BOUND_STAGES is bound, and so is any
        UNRECOGNISED stage string (including ''/None) — a typo'd stage
        must never silently disable the invariance family. The only
        stages that are not bound are the recognised generation
        stages in REWRITE_UNBOUND_STAGES (Co-Author Generation, whose
        'original' is empty, so there is nothing to preserve). No
        existing test defines ''/None as 'no stage, gates off', so
        the fail-safe reading is the one preserved here."""
        if stage in REWRITE_BOUND_STAGES:
            return True
        if stage in REWRITE_UNBOUND_STAGES:
            return False
        return True

    @staticmethod
    def _banned_term_count(term, low_text):
        """Whole-term occurrences (R12): word boundaries on both
        ends, so 'highlighter' never counts as 'highlight', and a
        multi-word phrase counts as a phrase."""
        return len(re.findall(r"\b" + re.escape(term.lower()) + r"\b", low_text))

    def check_banned_vocabulary_deterministic(self, original_text, edited_text):
        """Delta check against the shared canon list (vocab.py): a term
        rejects only when the edit INTRODUCES it. The author's own text
        may contain any of these words — they are his to keep, and the
        old edited-only scan would have rejected his own prose forever
        on any chunk that happened to contain one.

        Round 3 (R12): count-based, not presence-based. Using a
        banned term the same number of times as the original passes
        (the author used it; the edit merely kept it); only an
        INCREASE in its whole-word count rejects."""
        orig_low = (original_text or "").lower()
        edit_low = (edited_text or "").lower()
        found = [w for w in BANNED_TERMS
                 if self._banned_term_count(w, edit_low)
                 > self._banned_term_count(w, orig_low)]
        if found:
            return False, f"Deterministic Banned Word Violation: Edit introduced forbidden terms {found}"
        return True, "Deterministic vocabulary check passed."

    def differential_audit(self, original_text, edited_text, stage="", drift_limit=None):
        """Word-count drift only. (Round 15, review S8: the proper-noun
        half of this audit was retired — the content-invariance gate
        does that job exactly, multisets and all, and rejects on ONE
        foreign name where this scan needed more than three distinct.
        Two overlapping noun systems reporting the same violation in
        different words only made correction feedback noisier.)"""
        if not original_text:
            return True, "No original text to compare against (generation pass)."

        orig_count = len(original_text.split())
        edit_count = len(edited_text.split())

        if orig_count > 0:
            drift = abs(edit_count - orig_count) / orig_count
            limit = drift_limit if drift_limit is not None else self.DRIFT_LIMITS.get(stage, self.DEFAULT_DRIFT_LIMIT)
            if drift > limit:
                return False, f"Word count drift violation: Original had {orig_count} words, edited has {edit_count} words ({drift*100:.1f}% drift, limit {limit*100:.0f}% for stage '{stage or 'default'}')."

        return True, "Differential audit passed."

    def _check_vocabulary_guardrails(self, text):
        lower_text = text.lower()
        violations = [msg for phrase, msg in GUARDRAIL_RULES if phrase in lower_text]

        if violations:
            return False, "\n".join(violations)
        return True, "Vocabulary and canon guardrails intact."

    def _check_duplication(self, edited_text):
        paragraphs = [p.strip() for p in edited_text.split('\n\n') if p.strip()]
        seen_blocks = set()

        for p in paragraphs:
            p_clean = re.sub(r'\s+', ' ', p.lower()).strip()
            if len(p_clean) < 40:
                continue
            if p_clean in seen_blocks:
                return False, f"Catastrophic loop detected: exact duplicate paragraph found ('{p[:30]}...')"
            seen_blocks.add(p_clean)

        return True, "No duplication found."

    def _evaluate_human_score(self, text):
        paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
        if not paragraphs:
            return 1.0, "Empty text."

        para_lengths = []
        for p in paragraphs:
            sentences = [s for s in re.split(r'(?<=[.!?])\s+(?=[A-Z"\u201c])', p) if s.strip()]
            if sentences:
                avg_len = sum(len(s.split()) for s in sentences) / len(sentences)
                para_lengths.append(avg_len)

        if len(para_lengths) > 2:
            try:
                variance = statistics.variance(para_lengths)
                cadence_score = min(variance / 50.0, 1.0)
            except statistics.StatisticsError:
                cadence_score = 0.8
        else:
            cadence_score = 0.8

        lower_text = text.lower()
        banned_openings = ["last october", "it broke on", "as an ai", "in today's world"]
        penalty = sum(0.2 for phrase in banned_openings if phrase in lower_text)

        human_score = max(0.0, min(1.0, 0.7 + (cadence_score * 0.3) - penalty))
        return human_score, f"Cadence variance score: {cadence_score:.2f}, Penalty: {penalty}"

    def _strip_reasoning_blocks(self, text):
        """Delegates to the engine's canonical stripper (round 15, S11:
        one implementation, three former copies)."""
        return strip_reasoning_blocks(text)

    def _check_headings_preserved(self, original_text, edited_text, stage):
        """Headings are structural: the model must not drop or invent them.

        Dropped headings merge chapters together; invented ones corrupt the
        table of contents. Round 3 (R22) binds the rewrite-bound stages
        (now including Combined/Developmental, plus unrecognised stages
        fail-safe) against invented headings as well.

        Round 3 (R13a): the comparison is a Counter multiset, not a
        set — dropping ONE of two identical headings must fail, and
        set membership alone cannot see that.
        """
        from collections import Counter

        def heading_lines(t):
            return [l.strip() for l in t.split('\n')
                    if re.match(r'^#{1,6}\s+\S', l.strip())]

        def key(h):
            # Whitespace-free comparison: a model that fuses a two-line
            # heading ("CHAPTER 1The Arithmetic") has still preserved
            # the heading — save_document rescues the fused form — so
            # spacing alone must not read as a dropped/invented heading.
            return re.sub(r'\s+', '', re.sub(r'^#+\s*', '', h)).lower()

        orig = heading_lines(original_text)
        edit = heading_lines(edited_text)
        orig_keys = Counter(key(h) for h in orig)
        edit_keys = Counter(key(e) for e in edit)

        for h in orig:
            if edit_keys[key(h)] < orig_keys[key(h)]:
                return False, f"STATUS: REJECTED\nDropped chapter heading: '{h[:60]}'. Headings must be preserved verbatim."
        if self._is_rewrite_bound(stage):
            for e in edit:
                if edit_keys[key(e)] > orig_keys[key(e)]:
                    return False, f"STATUS: REJECTED\nInvented new heading: '{e[:60]}'. Do not add headings during {stage}."
        return True, "STATUS: APPROVED"

    def _check_short_lines_preserved(self, original_text, edited_text, stage):
        """Short standalone lines — captions, rung labels, list subheads,
        summary lines — are what models silently drop at chunk seams.
        The drift gate can't see an 8-word label vanishing inside a
        1,500-word chunk, so check line by line: every short source line
        must survive recognizably in the edited text — verbatim, lightly
        edited, split across two lines, or merged with a neighbor all
        count; gone is gone. The rejection quotes the missing lines so
        the correction pass can restore them."""
        if not self._is_rewrite_bound(stage):
            return True, "STATUS: APPROVED"

        from collections import Counter

        def norm_words(line):
            return re.sub(r'[^a-z0-9 ]', ' ', line.lower()).split()

        def lines_of(text):
            out = []
            for raw in re.split(r'\n+', text):
                s = raw.strip().lstrip('#').strip()
                if s:
                    out.append(s)
            return out

        edit_sets = [set(norm_words(l)) for l in lines_of(edited_text)]
        # Candidates are (word set, edit-line indices it consumes).
        # Consecutive-line unions cover a source line the model split in two.
        candidates = [(s, (i,)) for i, s in enumerate(edit_sets)]
        candidates += [(edit_sets[i] | edit_sets[i + 1], (i, i + 1))
                       for i in range(len(edit_sets) - 1)]

        # Round 3 (R13a): count-aware matching. The old existence
        # check let ONE surviving copy satisfy any number of identical
        # source lines, so dropping one of two identical labels passed.
        # Now a repeated source line (Counter-tracked by its normalised
        # words) must find a FRESH, not-yet-consumed edit line (or pair)
        # to match against; distinct lines may still share an edit line,
        # which preserves the merged-with-a-neighbour allowance.
        seen_norm = Counter()
        used_edit = set()
        missing = []
        for raw in lines_of(original_text):
            if raw.lstrip().startswith('|'):
                continue  # table rows travel as blocks, checked elsewhere
            words = norm_words(raw)
            if not (2 <= len(words) <= 30):
                continue
            wset = set(words)
            if not wset:
                continue
            norm_key = tuple(words)
            is_repeat = seen_norm[norm_key] > 0
            seen_norm[norm_key] += 1
            best = 0.0
            best_idx = ()
            for s, idx in candidates:
                if is_repeat and used_edit.intersection(idx):
                    continue  # a repeat needs a copy of its own
                score = len(wset & s) / len(wset)
                if score > best:
                    best, best_idx = score, idx
                if best >= 0.75:
                    break
            if best >= 0.75:
                used_edit.update(best_idx)
            else:
                missing.append(raw.strip()[:80])

        if missing:
            shown = "; ".join(f"'{m}'" for m in missing[:5])
            return False, (f"STATUS: REJECTED\nDropped short line(s) from the original: {shown}. "
                           f"Restore them verbatim at their original positions — captions, labels, "
                           f"and summary lines must not be dropped or merged away.")
        return True, "STATUS: APPROVED"

    # Function words that legitimately start sentences; never tracked
    # as proper names by the invariance check below.
    _NAME_STOPWORDS = {
        "the", "a", "an", "and", "but", "or", "nor", "when", "while",
        "after", "before", "then", "than", "that", "this", "these",
        "those", "there", "here", "what", "who", "whom", "how", "why",
        "if", "in", "on", "at", "by", "for", "with", "from", "into",
        "over", "under", "not", "no", "yes", "he", "she", "it", "they",
        "we", "you", "his", "her", "its", "their", "my", "your", "our",
        "as", "so", "now", "just", "only", "even", "still", "already",
        "every", "each", "all", "any", "some", "one", "two", "first",
    }

    _NUMBER_WORDS = (
        "zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|"
        "twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|"
        "nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|"
        "ninety|hundred|thousand|million|billion|dozen")
    _ORDINAL_WORDS = (
        "first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|"
        "tenth|eleventh|twelfth|thirteenth|fourteenth|fifteenth|"
        "sixteenth|seventeenth|eighteenth|nineteenth|twentieth|"
        "thirtieth|fortieth|fiftieth|sixtieth|seventieth|eightieth|"
        "ninetieth|hundredth|thousandth")

    @classmethod
    def _number_multiset(cls, text):
        from collections import Counter
        num = cls._NUMBER_WORDS
        ordi = cls._ORDINAL_WORDS
        pat = re.compile(
            r"\d[\d,]*(?:\.\d+)?(?:st|nd|rd|th)?\b"
            rf"|\b(?:{num}|{ordi})(?:-(?:{num}|{ordi}))+\b"
            rf"|\b(?:{num}|{ordi})\b",
            re.IGNORECASE)
        out = Counter()
        for tok in pat.findall(text):
            out[tok.lower().replace(",", "")] += 1
        return out

    @staticmethod
    def _name_key(token):
        low = token.strip("'\u2019-").lower()
        if low.endswith("'s") or low.endswith("\u2019s"):
            low = low[:-2]
        return re.sub(r"[^a-z]", "", low)

    @classmethod
    def _capitalized_tokens(cls, text):
        """(key, is_sentence_initial) for every capitalized token."""
        out = []
        prev_end = 0
        for m in re.finditer(r"[A-Za-z][A-Za-z'\u2019-]*", text):
            gap = text[prev_end:m.start()]
            initial = m.start() == 0 or any(c in gap for c in ".!?\n")
            raw = m.group(0)
            if raw[0].isupper():
                key = cls._name_key(raw)
                if len(key) >= 2 and key not in cls._NAME_STOPWORDS:
                    out.append((key, initial))
            prev_end = m.end()
        return out

    @classmethod
    def _term_multiset(cls, text):
        """Hyphenated-term census (locked vocabulary: fragment-pods),
        excluding pure number compounds (counted as numbers instead).
        Shared by the invariance gate and the app's post-save audit."""
        from collections import Counter
        text = text.replace("\u2013", "-")
        out = Counter()
        numset = set(cls._NUMBER_WORDS.split("|")) | set(cls._ORDINAL_WORDS.split("|"))
        for tok in re.findall(r"[A-Za-z]+(?:-[A-Za-z]+)+", text):
            low = tok.lower()
            if all(part in numset for part in low.split("-")):
                continue
            out[low] += 1
        return out

    def _check_content_invariance(self, original_text, edited_text, stage):
        """Numbers, proper names, and hyphenated terms are facts, not
        style: an edit pass must carry them across unchanged. The drift
        gate can't see a same-length swap — thirty-three minutes became
        fifty-three, the bow kid Corb became Joss (a name swap *within*
        the book's own cast, invisible to the foreign-noun scan because
        Joss exists elsewhere), fragment-pods became fragment-vessels,
        an anonymous scope tech acquired the medic's name. All of those
        are same-word-count changes, so compare the multisets directly.
        The rejection lists the exact differences so the correction pass
        can restore them verbatim."""
        if not self._is_rewrite_bound(stage):
            return True, "STATUS: APPROVED"
        from collections import Counter
        problems = []

        # --- numbers (digits, number words, ordinals, compounds) ---
        o_num = self._number_multiset(original_text)
        e_num = self._number_multiset(edited_text)
        if o_num != e_num:
            lost = o_num - e_num
            gained = e_num - o_num
            bits = []
            if lost:
                bits.append("lost: " + ", ".join(f"'{k}' x{v}" for k, v in list(lost.items())[:6]))
            if gained:
                bits.append("gained: " + ", ".join(f"'{k}' x{v}" for k, v in list(gained.items())[:6]))
            problems.append("numbers changed (" + "; ".join(bits) + ")")

        # --- proper names ---
        o_caps = self._capitalized_tokens(original_text)
        e_caps = self._capitalized_tokens(edited_text)
        # A name is tracked if the original uses it mid-sentence at
        # least once, or more than once anywhere (sentence-initial
        # common words stay untracked and can't false-fire).
        o_counts = Counter(k for k, _ in o_caps)
        tracked = {k for k, _ in o_caps if not _} | \
                  {k for k, v in o_counts.items() if v >= 2}
        o_tracked = Counter({k: o_counts[k] for k in tracked})
        e_counts = Counter(k for k, _ in e_caps)
        e_tracked = Counter({k: e_counts[k] for k in tracked if k in e_counts})
        if o_tracked != e_tracked:
            lost = o_tracked - e_tracked
            gained = e_tracked - o_tracked
            bits = []
            if lost:
                bits.append("lost: " + ", ".join(f"{k} x{v}" for k, v in list(lost.items())[:6]))
            if gained:
                bits.append("gained: " + ", ".join(f"{k} x{v}" for k, v in list(gained.items())[:6]))
            problems.append("proper names changed (" + "; ".join(bits) + ")")
        # Foreign names: capitalized mid-sentence in the edit, with no
        # fused form anywhere in the original (the differential audit
        # only fires past 3 distinct names; a single swapped-in name is
        # exactly the failure that matters, so here one is enough).
        # The fused set uses _name_key, the same normalization that
        # produced the candidate keys — a name the original uses only
        # possessively ("Danth's sky") must still count as present, or
        # a legitimate later use ("Danth held the ridge") false-fires.
        orig_fused = {self._name_key(w) for w in original_text.split()}
        orig_fused.discard("")
        foreign = sorted({k for k, initial in e_caps
                          if not initial and k not in orig_fused and k not in tracked})
        if foreign:
            problems.append("names appeared that are not in the original: "
                            + ", ".join(foreign[:6]))

        # --- sentence-initial single-mention names (R13b) ---
        # The tracked/foreign logic above is blind at a sentence
        # start: a name mentioned ONLY there, once ("Mira stood."),
        # was untracked, and its replacement ("Joss stood.") was
        # sentence-initial too, so not foreign either — the swap
        # passed. Close that conservatively:
        #   * candidates are single-mention sentence-initial tokens
        #     only; common sentence starters are already excluded by
        #     _NAME_STOPWORDS in _capitalized_tokens, number words
        #     and common transition adverbs are excluded below;
        #   * a candidate is NOT held to an exact count (an edit may
        #     legitimately use an existing name once more — the
        #     possessive-name case in the existing suite), only to
        #     still being present at all: losing it entirely fails;
        #   * and a different, foreign capital in the SAME
        #     sentence-initial position fails as a replacement.
        _weak_extra_stops = {
            "however", "meanwhile", "finally", "suddenly", "quietly",
            "slowly", "later", "soon", "today", "yesterday", "tomorrow",
            "indeed", "instead", "otherwise", "overall", "often",
            "once", "twice", "again",
        }
        _number_keys = (set(self._NUMBER_WORDS.split("|"))
                        | set(self._ORDINAL_WORDS.split("|")))
        weak_names = {k for k, initial in o_caps
                      if initial and o_counts[k] == 1
                      and k not in _number_keys
                      and k not in _weak_extra_stops}
        weak_lost = sorted(k for k in weak_names if e_counts.get(k, 0) == 0)
        if weak_lost:
            problems.append("sentence-initial name(s) lost: "
                            + ", ".join(weak_lost[:6]))
        o_initial = [k for k, initial in o_caps if initial]
        e_initial = [k for k, initial in e_caps if initial]
        positional_foreign = []
        for o_key, e_key in zip(o_initial, e_initial):
            if (o_key in weak_names and e_key != o_key
                    and e_key not in orig_fused
                    and e_key not in positional_foreign):
                positional_foreign.append(e_key)
        if positional_foreign:
            problems.append("names appeared sentence-initially that are not "
                            "in the original: "
                            + ", ".join(positional_foreign[:6]))

        # --- hyphenated terms (locked vocabulary: fragment-pods) ---
        o_term = self._term_multiset(original_text)
        e_term = self._term_multiset(edited_text)
        if o_term != e_term:
            lost = o_term - e_term
            gained = e_term - o_term
            bits = []
            if lost:
                bits.append("lost: " + ", ".join(f"'{k}' x{v}" for k, v in list(lost.items())[:6]))
            if gained:
                bits.append("gained: " + ", ".join(f"'{k}' x{v}" for k, v in list(gained.items())[:6]))
            problems.append("hyphenated terms changed (" + "; ".join(bits) + ")")

        if problems:
            return False, ("STATUS: REJECTED\nContent invariance violation: "
                           + "; ".join(problems) + ". Numbers, character names, and "
                           "hyphenated terms are facts, not style — restore every one "
                           "of them verbatim from the original.")
        return True, "STATUS: APPROVED"

    def _check_quote_style(self, original_text, edited_text, stage):
        """A manuscript set in curly quotes must stay in curly quotes.
        Models quietly normalize punctuation in the chunks they touch —
        hundreds of straight apostrophes and straight double quotes in
        an otherwise curly book — and occasionally drop an opening
        quote mark outright. Both are mechanical to detect."""
        if not self._is_rewrite_bound(stage):
            return True, "STATUS: APPROVED"
        if not any(q in original_text for q in "\u201c\u201d\u2018\u2019"):
            return True, "STATUS: APPROVED"
        problems = []
        o_dq = original_text.count('"')
        e_dq = edited_text.count('"')
        if e_dq > o_dq:
            problems.append(f"introduced {e_dq - o_dq} straight double quote(s) "
                            f"into curly-quoted text")
        o_ap = len(re.findall(r"[A-Za-z]'[A-Za-z]", original_text))
        e_ap = len(re.findall(r"[A-Za-z]'[A-Za-z]", edited_text))
        if e_ap > o_ap:
            problems.append(f"introduced {e_ap - o_ap} straight apostrophe(s) "
                            f"into curly-quoted text")
        if original_text.count("\u201c") == original_text.count("\u201d") and \
                edited_text.count("\u201c") != edited_text.count("\u201d"):
            problems.append("curly double quotes no longer balance — a quote "
                            "mark was dropped or added")
        if problems:
            return False, ("STATUS: REJECTED\nQuote style violation: "
                           + "; ".join(problems) + ". Match the original's "
                           "punctuation exactly: curly quotes stay curly, and "
                           "every opening quote keeps its closing quote.")
        return True, "STATUS: APPROVED"

    _ARTIFACT_LINE_RE = re.compile(
        r"^\[[^\]\n]{0,60}\b(deleted|removed|omitted|redacted)\b[^\]\n]{0,30}\]\.?$",
        re.IGNORECASE)

    def _check_no_editor_artifacts(self, original_text, edited_text, stage):
        """Editor working notes embedded in the manuscript text itself:
        HTML comments carrying word-count tallies, or a bracketed
        '[paragraphs deleted]' standing where prose used to be. Never
        legitimate output at any stage — and the bracketed form is an
        admission of a deletion the drift gate may be too coarse to
        see, so it rejects rather than being quietly stripped."""
        if "<!--" in edited_text:
            return False, ("STATUS: REJECTED\nEditor artifact in the text: an HTML "
                           "comment ('<!-- ... -->') is a working note, not "
                           "manuscript text. Remove it and return the full edited "
                           "text only.")
        for line in edited_text.split('\n'):
            if self._ARTIFACT_LINE_RE.match(line.strip()):
                return False, (f"STATUS: REJECTED\nEditor artifact in the text: "
                               f"'{line.strip()[:70]}' marks text the edit dropped. "
                               f"Restore the original passage in full — deletions are "
                               f"not permitted at this stage.")
        return True, "STATUS: APPROVED"

    @staticmethod
    def _is_cosmetic_only(original_text, edited_text):
        """True when the edit changed nothing but punctuation, spacing,
        or case — the deterministic gates fully describe such an edit,
        so the LLM audit has nothing to add (S10).

        Round 3 (R23): the old [a-z0-9]-only comparison could not see
        two real changes, so both wrongly skipped the LLM audit:
          * stripping markdown emphasis — '**bold**' and 'bold' have
            the same alphanumeric skeleton, but emphasis is meaning;
          * joining words — 'well known' and 'wellknown' (and
            'well-known' / 'wellknown') share a skeleton too.
        So cosmetic now also requires identical emphasis-marker
        counts ('**' and total '*') and an identical component-word
        count: alphanumeric runs, with apostrophes removed first (a
        contraction is one word) and hyphens treated as boundaries
        (a hyphenated compound is two components, so deleting its
        hyphen — or a space — to join words drops the count)."""
        def norm(t):
            return re.sub(r"[^a-z0-9]", "", (t or "").lower())

        if norm(original_text) != norm(edited_text):
            return False

        def emphasis_counts(t):
            t = t or ""
            return (t.count("**"), t.count("*"))

        if emphasis_counts(original_text) != emphasis_counts(edited_text):
            return False

        def word_count(t):
            no_apos = (t or "").lower().replace("'", "").replace("\u2019", "")
            return len(re.findall(r"[a-z0-9]+", no_apos))

        if word_count(original_text) != word_count(edited_text):
            return False
        return True

    def validate_chunk(self, original_text, edited_text, stage, drift_limit=None, rewrite_bound=True):
        """The deterministic gate chain — the ONE canonical version
        (round 16, S13). inspect_chunk runs it before the LLM audit;
        the app's checkpoint revalidation runs the same method, so a
        gate added or reordered in one place can never drift out of
        sync with the other (rounds 13–15 each had to hand-edit two
        copies of this chain). Returns (approved, feedback) with the
        same message shapes inspect_chunk has always produced.

        rewrite_bound=False judges stored text the CALLER has marked
        as not rewrite-bound (e.g. a chain containing a recognised
        unbound/generation stage): the invariance family (short
        lines, content invariance, quote style) can't judge that
        output against the original, so it is skipped; drift, banned
        vocabulary, headings, artifacts, guardrails, and duplication
        always apply. (Round 3, R22: Developmental/Combined are
        rewrite-bound stages now, so they no longer produce a
        rewrite_bound=False chain on their own.)"""
        edited_text = self._strip_reasoning_blocks(edited_text)

        det_passed, det_feedback = self.check_banned_vocabulary_deterministic(original_text, edited_text)
        if not det_passed:
            return False, f"STATUS: REJECTED\n{det_feedback}"

        diff_passed, diff_feedback = self.differential_audit(original_text, edited_text, stage=stage, drift_limit=drift_limit)
        if not diff_passed:
            return False, f"STATUS: REJECTED\n{diff_feedback}"

        head_passed, head_feedback = self._check_headings_preserved(original_text, edited_text, stage)
        if not head_passed:
            return False, head_feedback

        if rewrite_bound:
            short_passed, short_feedback = self._check_short_lines_preserved(original_text, edited_text, stage)
            if not short_passed:
                return False, short_feedback

        art_passed, art_feedback = self._check_no_editor_artifacts(original_text, edited_text, stage)
        if not art_passed:
            return False, art_feedback

        if rewrite_bound:
            inv_passed, inv_feedback = self._check_content_invariance(original_text, edited_text, stage)
            if not inv_passed:
                return False, inv_feedback

            quote_passed, quote_feedback = self._check_quote_style(original_text, edited_text, stage)
            if not quote_passed:
                return False, quote_feedback

        vocab_passed, vocab_feedback = self._check_vocabulary_guardrails(edited_text)
        if not vocab_passed:
            return False, f"STATUS: REJECTED\n{vocab_feedback}"

        is_unique, dup_feedback = self._check_duplication(edited_text)
        if not is_unique:
            return False, f"STATUS: REJECTED\nDuplication Watch Violation: {dup_feedback}"

        return True, "STATUS: APPROVED (deterministic validation passed)."

    def inspect_chunk(self, original_text, edited_text, stage, context_limit=4096, skip_llm_audit=False, previous_chunk="", drift_limit=None, audit_context=""):
        # Audit the manuscript text, not the model's reasoning residue:
        # a <think> block's vocabulary (Grammar, Markdown, Consistency…)
        # otherwise trips the drift and proper-noun checks below.
        edited_text = self._strip_reasoning_blocks(edited_text)

        val_passed, val_feedback = self.validate_chunk(
            original_text, edited_text, stage, drift_limit=drift_limit)
        if not val_passed:
            return False, val_feedback

        # The human score is advisory now (round 16, S13): an
        # uncalibrated cadence metric must not veto chunks the
        # deterministic gates passed. It reports as a warning the
        # caller can log; genuine slop is the LLM audit's call.
        score, score_details = self._evaluate_human_score(edited_text)
        if score < self.HUMAN_SCORE_THRESHOLD:
            self._warnings.append(
                f"Human score low ({score * 100:.1f}% < {self.HUMAN_SCORE_THRESHOLD * 100:.0f}%) — advisory only, not a rejection. {score_details}")

        if skip_llm_audit:
            # Fast QA mode: deterministic checks passed, skip the expensive LLM call.
            return True, "STATUS: APPROVED (deterministic checks only — AI audit skipped)."

        if self._is_cosmetic_only(original_text, edited_text):
            # Unchanged or punctuation-only: deterministic gates already
            # verified everything there is to verify. Skipping the audit
            # call here returns hours on book-length runs (S10).
            return True, "STATUS: APPROVED (unchanged or punctuation-only edit — AI audit skipped)."

        continuity_note = (
            f"\nPREVIOUS CHUNK TAIL (already approved — flag it if this chunk contradicts "
            f"its names, pronouns, tense, or facts):\n{previous_chunk[-1200:]}\n"
            if previous_chunk else ""
        )
        # Neutral auditor (round 15, S10): the old prompt cast a
        # "ruthless literary fiction auditor demanding novelistic
        # depth" — for the Teacher's Guide and the prompt-engineering
        # book too. The audit's job is fidelity, whatever the genre;
        # the author's own directives ride along as the standard.
        directives = (
            f"\nAUTHOR'S DIRECTIVES for this manuscript (judge fidelity against these):\n{audit_context}\n"
            if audit_context else ""
        )
        audit_prompt = (
            "SYSTEM: You are the WatchTower auditor. Judge ONLY whether the edited text is a faithful "
            "edit of the original: same facts, names, numbers, and events; no invented content; no "
            "dropped passages; the author's voice preserved; mechanics clean. Do not judge literary "
            "merit, depth, or taste.\n"
            f"{directives}"
            f"ORIGINAL:\n{original_text}\n\nTEXT:\n{edited_text}\n{continuity_note}\n"
            "Start your response with exactly 'STATUS: APPROVED' if the edit is faithful, otherwise 'STATUS: REJECTED' followed by the specific violation."
        )
        # Temperature 0: an audit is a measurement, not a creative act —
        # the same chunk must get the same verdict on every run.
        response = self.engine.call_ollama(model=self.model, system_prompt=audit_prompt, text="", context_size=context_limit, is_edit_pass=False, temperature=0.0)

        cleaned_resp = self._strip_reasoning_blocks(response).strip().upper()
        is_approved = cleaned_resp.startswith("STATUS: APPROVED")
        return is_approved, response
