try:
    from agents.vocab import BANNED_TERMS, COAUTHOR_EXTRA_PHRASES, COAUTHOR_CLICHE_NOTE
except ImportError:  # flat layout (tests, direct runs)
    from vocab import BANNED_TERMS, COAUTHOR_EXTRA_PHRASES, COAUTHOR_CLICHE_NOTE


class CoAuthorAgent:
    def __init__(self, engine, model):
        self.engine = engine
        self.model = model

    def write_section(self, prompt_topic, role, target_word_count, context_limit=4096, stream_callback=None, target_word_limit=None):
        # (Round 15, S12: the bible_path and previous_chunk parameters
        # were deleted — they were accepted and silently ignored, which
        # made the wiring look connected when it wasn't. The
        # orchestrator folds the bible and the previous block's tail
        # into prompt_topic itself; that is the one real path.)
        role_prompts = {
            "AI Expert": "You are an expert in artificial intelligence, machine learning systems, and prompt architectures. Write clear, technically precise, and authoritative content.",
            "Engineer": "You are a software and systems engineer. Focus on practical implementation details, system architecture, code structures, and technical workflows.",
            "Novelist": "You are a creative fiction author. Focus on vivid prose, narrative momentum, and engaging dialogue.",
            "Researcher": "You are a meticulous researcher. Focus on structured analysis, factual precision, and clear explanations."
        }

        sys_prompt = role_prompts.get(role, "You are a collaborative co-author assisting with manuscript drafting.")

        # One shared vocabulary (vocab.py, S7): the buzzword list is the
        # same BANNED_TERMS the editing agents and the WatchTower use.
        buzzwords = ", ".join(f"'{t}'" for t in BANNED_TERMS)
        extra = ", ".join(f"'{p}'" for p in COAUTHOR_EXTRA_PHRASES)
        anti_pattern_directives = (
            "\n\nSTRICT NEGATIVE CONSTRAINTS & BANNED CRUTCHES:\n"
            f"1. BANNED AI BUZZWORDS: Never use these words/phrases: {buzzwords}.\n"
            f"2. BANNED PHRASES: Never use open-ended filler phrases like {extra}.\n"
            "3. NO FORMULARIC OPENINGS: Avoid repetitive thematic topic sentences or rigid structural formulas.\n"
            f"4. {COAUTHOR_CLICHE_NOTE}"
        )

        block_target = min(target_word_count, 1500)

        final_prompt = (
            f"{sys_prompt}{anti_pattern_directives}\n\n"
            f"Target length for this section: Approximately {block_target} words. "
            f"Expand the topic thoroughly without padding.\n"
            f"Return only the section text — no preamble, no notes about what you wrote.\n"
            f"Outline / Topic Prompt:\n{prompt_topic}"
        )

        # target_word_limit was never passed through, so num_predict was never
        # set and blocks came back at whatever length the model felt like.
        return self.engine.call_ollama(
            model=self.model,
            system_prompt=final_prompt,
            text="",
            context_size=context_limit,
            stream_callback=stream_callback,
            is_edit_pass=False,
            target_word_limit=target_word_limit if target_word_limit else target_word_count,
        )
