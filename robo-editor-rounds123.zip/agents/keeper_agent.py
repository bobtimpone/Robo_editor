import os

from engine import strip_reasoning_blocks


class KeeperAgent:
    # The ledger rides inside every generation prompt; left unbounded
    # it eventually crowds the new text out of the context window
    # (round 15, S12). Past this size it is folded down first.
    LEDGER_WORD_CAP = 2000

    def __init__(self, engine, model):
        self.engine = engine
        self.model = model
        self._bible_cache = {}

    def _compress_ledger(self, summary, context_limit=4096):
        """Fold an over-long ledger down, keeping every named fact."""
        prompt = (
            "You are the Keeper agent. Compress the continuity ledger below to "
            "under 800 words. Keep EVERY named character, place, event, and "
            "established fact — drop only redundancy and connective prose. "
            "Return the compressed ledger, bulleted, no preamble.\n\n"
            f"LEDGER:\n{summary}"
        )
        response = self.engine.call_ollama(
            model=self.model,
            system_prompt=prompt,
            text="",
            context_size=context_limit,
            is_edit_pass=False
        )
        compressed = strip_reasoning_blocks(response).strip()
        return compressed if compressed else summary

    def summarize_state(self, new_text, previous_summary="", context_limit=4096):
        """Rolling continuity ledger: fold the newest text into the running summary.

        The old version re-read the last 3 chunks every block (a sliding window
        that forgot everything older). This keeps a running ledger instead, so
        long manuscripts keep their early chapters in memory, and each block
        costs one small summarization instead of re-reading thousands of words.
        `new_text` may be a string or a list of strings.
        """
        if isinstance(new_text, list):
            new_text = "\n\n".join(new_text)
        if not new_text or not new_text.strip():
            return previous_summary

        if previous_summary and len(previous_summary.split()) > self.LEDGER_WORD_CAP:
            previous_summary = self._compress_ledger(previous_summary, context_limit)

        prior = f"RUNNING LEDGER SO FAR:\n{previous_summary}\n\n" if previous_summary else ""
        prompt = (
            "You are the Keeper agent tracking narrative state across a manuscript.\n"
            "Update the running ledger by folding in the new text below. Keep it compact and bulleted:\n"
            "1. Events and scenes that have ALREADY occurred (keep old entries, add new ones).\n"
            "2. Specific dialogues, images, or motifs already used (e.g., cold coffee, 3:14 a.m. essays).\n"
            "3. Active plot threads that must move FORWARD.\n"
            "4. Named characters, places, and key facts established (do not contradict).\n\n"
            f"{prior}NEW TEXT TO FOLD IN:\n{new_text}\n\n"
            "Return the complete updated ledger, no preamble."
        )
        response = self.engine.call_ollama(
            model=self.model,
            system_prompt=prompt,
            text="",
            context_size=context_limit,
            is_edit_pass=False
        )
        # The ledger is continuity memory, not manuscript: it does NOT
        # go through the save sanitizer (S12) — a ledger line starting
        # "Note:" in its back half must never truncate the book's
        # memory. Strip reasoning residue only.
        return strip_reasoning_blocks(response).strip()

    def load_story_bible(self, filepath):
        if not filepath or not os.path.exists(filepath):
            return ""
        # Cache on path + mtime: the edit pipeline used to re-read this per chunk.
        try:
            mtime = os.path.getmtime(filepath)
        except OSError:
            return ""
        cached = self._bible_cache.get(filepath)
        if cached and cached[0] == mtime:
            return cached[1]
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                bible_text = f.read()
        except Exception:
            return ""
        self._bible_cache[filepath] = (mtime, bible_text)
        return bible_text
