import docx
from docx.shared import Inches, Pt, RGBColor
from docx.oxml.ns import qn
import urllib.request
import urllib.error
import json
import re
import time
import os
import tempfile

try:
    import tiktoken
except ImportError:
    tiktoken = None  # soft dependency: engine falls back to word-based counting


class CancelRequested(Exception):
    """Raised when the user cancels a running operation. Callers should
    treat this as a graceful stop, not an error."""
    pass


def atomic_write_text(path, text, encoding="utf-8"):
    """Write text to `path` atomically (Rounds 1-3, review R4): write to
    a temp file in the SAME directory, fsync, then os.replace over the
    destination. A crash, kill, or disk-full mid-write leaves the prior
    good file intact instead of a truncated one. Raises on failure and
    cleans up the temp file."""
    directory = os.path.dirname(os.path.abspath(path))
    fd, tmp = tempfile.mkstemp(dir=directory, prefix=".atomic-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding=encoding) as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return path


def atomic_save_docx(doc, path):
    """Save a python-docx Document atomically (review R4): build the
    file at a temp path in the same directory, then os.replace."""
    directory = os.path.dirname(os.path.abspath(path))
    fd, tmp = tempfile.mkstemp(dir=directory, prefix=".atomic-", suffix=".docx")
    os.close(fd)
    try:
        doc.save(tmp)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return path


def update_config_file(config_path, updates):
    """Merge `updates` into the JSON config at `config_path` and write
    it back atomically (review R4/R16c). Shared by the main window and
    the Graphics Studio so the two writers can never truncate each
    other's file: the current on-disk state is re-read and merged
    immediately before the atomic replace.

    Returns (True, "") on success, (False, reason) on failure. A config
    that EXISTS but cannot be read/parsed is NEVER overwritten — the
    save is aborted instead, because the unreadable file may hold the
    other window's settings (the old Graphics Studio code rewrote the
    file with only its own section in exactly that case)."""
    existing = {}
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        except Exception as e:
            return False, f"existing config unreadable, save aborted: {e}"
        if not isinstance(existing, dict):
            return False, "existing config is not a JSON object, save aborted"
    merged = dict(existing)
    merged.update(updates)
    try:
        atomic_write_text(config_path, json.dumps(merged))
    except Exception as e:
        return False, f"config write failed: {e}"
    return True, ""


def strip_reasoning_blocks(text):
    """The one canonical reasoning-trace stripper. Reasoning models
    (Qwen3, DeepSeek-R1) wrap replies in <think> blocks; that text is
    not manuscript and must never reach an audit, a checkpoint, or a
    save. (This used to exist as three near-identical copies — in the
    engine's sanitizer, the Scribe, and the WatchTower — plus a stray
    '/think' pattern in the sanitizer's copy that could eat innocent
    text; there is now exactly one implementation.)"""
    if not text:
        return text
    stripped = re.sub(r'<think>[\s\S]*?</think>', '', text, flags=re.IGNORECASE)
    stripped = re.sub(r'</think>', '', stripped, flags=re.IGNORECASE)
    stripped = re.sub(r'\x60{3}thought[\s\S]*?\x60{3}', '', stripped, flags=re.IGNORECASE)
    stripped = re.sub(r'<thought>[\s\S]*?</thought>', '', stripped, flags=re.IGNORECASE)
    # Do-no-harm bound (Rounds 1-3, review R29): a manuscript that
    # DISCUSSES reasoning tags (a prompt-engineering book is exactly
    # that) can contain an opening tag and a much later closing tag,
    # with real chapters between them; unbounded stripping would eat
    # everything in between. For manuscript-sized inputs (>= 500
    # chars), if the blocks would remove more than
    # REASONING_STRIP_MAX_SHARE of the text, the tags are treated as
    # content and the input is returned unchanged. Short inputs are
    # model replies, where a dominant reasoning block is normal, and
    # strip as before.
    if len(text) >= REASONING_STRIP_MIN_LENGTH:
        removed = len(text) - len(stripped)
        if removed > len(text) * REASONING_STRIP_MAX_SHARE:
            return text
    return stripped


# R29 bound for strip_reasoning_blocks (see its docstring above).
REASONING_STRIP_MAX_SHARE = 0.30
REASONING_STRIP_MIN_LENGTH = 500


class EditorEngine:
    def __init__(self, ollama_url="http://localhost:11434"):
        self.ollama_url = ollama_url
        self.cancel_requested = False
        # Set by the app's "No-think" checkbox: when True, every Ollama
        # request carries "think": false so reasoning models skip the
        # reasoning trace entirely instead of generating text that the
        # pipeline then pays to strip (S11).
        self.think_off = False
        # Image count of the last document given to load_and_chunk (S2):
        # the text pipeline cannot carry images into the output, and the
        # app warns when this is non-zero instead of losing them quietly.
        self._input_image_count = 0
        # Heading texts captured by load_and_chunk; save_document uses them
        # to tell real chapter headings apart from '#' lines that were body
        # text in the source (code comments, prompt examples).
        self._source_headings = set()
        # Normalized heading key -> the heading's original text, line
        # breaks included ("CHAPTER 1\nThe Arithmetic"). save_document
        # writes this display form back so a two-line chapter heading
        # round-trips as two lines instead of one fused line.
        self._heading_display = {}
        if tiktoken is not None:
            try:
                self.tokenizer = tiktoken.get_encoding("cl100k_base")
            except Exception:
                self.tokenizer = None
        else:
            self.tokenizer = None  # _count_tokens falls back to len(words) * 1.3
        # Don't oversubscribe small machines with a hardcoded thread count.
        self.num_thread = os.cpu_count() or 8

    def _count_tokens(self, text):
        if self.tokenizer:
            return len(self.tokenizer.encode(text))
        return len(text.split()) * 1.3

    def _sanitize_output(self, text):
        if not text:
            return ""
        text = text.strip()

        # Unwrap fenced code blocks the model sometimes wraps the output in.
        fence_match = re.match(r'^```(?:markdown|md|text)?\s*\n([\s\S]*?)\n```\s*$', text)
        if fence_match:
            text = fence_match.group(1).strip()
        elif text.startswith("```"):
            # Unclosed fence: drop the fence line itself.
            text = re.sub(r'^```[^\n]*\n', '', text, count=1).strip()

        text = strip_reasoning_blocks(text)

        # Editor working notes are not manuscript text: HTML comments
        # ("<!-- est. words cut: 734 across 62 edits -->") and bracketed
        # deletion markers standing alone on a line ("[paragraphs
        # deleted]") get stripped wherever they appear. The WatchTower
        # rejects chunks containing these outright; this is the backstop
        # for text that reaches save by another path. Narrow on purpose:
        # the author's own bracketed placeholders ("[DEDICATION: Bob to
        # supply]", "[SOURCE DOCUMENT]") carry no deletion verb and are
        # never touched.
        text = re.sub(r'<!--[\s\S]*?-->', '', text)
        artifact_line_re = re.compile(
            r'^\[[^\]\n]{0,60}\b(deleted|removed|omitted|redacted)\b[^\]\n]{0,30}\]\.?$',
            re.IGNORECASE)
        lines = text.split('\n')
        lines = [l for l in lines if not artifact_line_re.match(l.strip())]
        text = '\n'.join(lines)

        if "---EXCEPTIONS---" in text:
            text = text.split("---EXCEPTIONS---")[0]

        # REMOVED (round 15, review S1): the "trailer cut" that deleted
        # everything from a back-half line starting with "Note:" /
        # "Summary:" / "Explanation:" to the end of the chunk. It was
        # meant to strip model meta-commentary, but it ran at save time
        # on EVERY chunk — including do-no-harm fallback chunks holding
        # the untouched original — and in a nonfiction manuscript
        # "Note:" lines are content. Measured damage: a no-edit round
        # trip of the Hey Y'All manuscript lost 1,568 words (−2.8%),
        # all of it this rule amputating two passages (the Ch 5
        # "Note: Project Chimera…" example and the Ch 7 "Note 1:…"
        # Sticky-Note passage — the same two passages that kept
        # vanishing from real runs). Model narration is handled by the
        # preamble rules below and the WatchTower's artifact gate; the
        # sanitizer no longer deletes manuscript lines by shape alone.

        # Strip leading preamble lines ("Here is the edited text:", "Sure, ...").
        preamble_re = re.compile(
            r"^(here(\s+is|'s)\s+(the\s+)?(edited|revised|corrected|updated|proofread)\s+"
            r"(text|version|passage|document)\s*[:.]?|"
            r"sure[,]?\s+here.{0,60}|of\s+course[,]?\s+here.{0,60}|"
            r"here\s+you\s+go\.?)$",
            re.IGNORECASE)
        lines = text.split('\n')
        while lines and preamble_re.match(lines[0].strip()):
            lines.pop(0)
        text = '\n'.join(lines)

        # Also drop standalone preamble lines ANYWHERE in the chunk, not
        # just at the top: current models narrate compliance mid-chunk
        # too ("Here is the edited text, preserving the original
        # formatting and adhering to the mandate:"). A line qualifies
        # only if it starts with the preamble formula, contains no
        # sentence-ending punctuation, and ends with a colon — a shape
        # genuine manuscript lines essentially never take.
        preamble_anywhere_re = re.compile(
            r"^here(\s+is|'s)\s+(the\s+)?(edited|revised|corrected|updated|proofread)"
            r"\b[^.!?]*:\s*$",
            re.IGNORECASE)
        lines = text.split('\n')
        lines = [l for l in lines if not preamble_anywhere_re.match(l.strip())]
        text = '\n'.join(lines)

        banned_phrases = [
            "the text to edit is missing",
            "missing input text",
            "no content provided"
        ]

        cleaned_lines = []
        for line in text.split('\n'):
            line_lower = line.lower()
            if not any(phrase in line_lower for phrase in banned_phrases):
                cleaned_lines.append(line)

        return "\n".join(cleaned_lines).strip()

    @staticmethod
    def _run_text(run):
        """Run text with structural breaks preserved. run.text silently
        drops <w:br/> elements, which is how "CHAPTER 1<break>The
        Arithmetic" used to reach the chunk text fused into
        "CHAPTER 1The Arithmetic" — heading and body line breaks alike."""
        parts = []
        for child in run._element.iter():
            if child.tag == qn('w:t'):
                parts.append(child.text or "")
            elif child.tag in (qn('w:br'), qn('w:cr')):
                parts.append("\n")
            elif child.tag == qn('w:tab'):
                parts.append("\t")
        return "".join(parts)

    def _para_to_markdown(self, para):
        md_text = ""
        for run in para.runs:
            text = self._run_text(run)
            if not text:
                continue
            # Preserve the run's leading/trailing whitespace verbatim —
            # including line breaks. The old space-only version stripped
            # a trailing <w:br/> off its run, fusing the words across it.
            lead_ws = text[:len(text) - len(text.lstrip())]
            trail_ws = text[len(text.rstrip()):]
            clean_text = text.strip()
            if not clean_text:
                md_text += text
                continue
            if run.bold and run.italic:
                md_text += f"{lead_ws}***{clean_text}***{trail_ws}"
            elif run.bold:
                md_text += f"{lead_ws}**{clean_text}**{trail_ws}"
            elif run.italic:
                md_text += f"{lead_ws}*{clean_text}*{trail_ws}"
            else:
                md_text += f"{lead_ws}{clean_text}{trail_ws}"

        if not md_text.strip():
            return ""

        # Preserve heading levels as markdown so they survive the round trip.
        try:
            style_name = para.style.name if para.style else ""
        except Exception:
            style_name = ""
        if style_name.startswith("Heading"):
            try:
                level = int(style_name.rsplit(" ", 1)[-1])
            except (ValueError, IndexError):
                level = 1
            level = max(1, min(level, 6))
            # One line per heading in chunk text, breaks collapsed to
            # spaces: a heading split across lines ("# CHAPTER 1\nThe
            # Arithmetic") reads to the model as a heading plus a stray
            # body line, and the save-side matcher can only match the
            # first fragment. save_document restores the original line
            # breaks from _heading_display.
            return "#" * level + " " + re.sub(r"\s+", " ", md_text).strip()
        return md_text

    def _table_to_markdown(self, table):
        rows = []
        for row in table.rows:
            cells = [c.text.strip().replace("|", "\\|").replace("\n", " ") for c in row.cells]
            rows.append("| " + " | ".join(cells) + " |")
        if not rows:
            return ""
        header_sep = "| " + " | ".join(["---"] * len(table.rows[0].cells)) + " |"
        return "\n".join([rows[0], header_sep] + rows[1:])

    def _markdown_to_table(self, lines, doc, insert_at=None):
        # Drop markdown separator rows like |---|---|
        data = [l for l in lines if not re.match(r'^\|[\s\-:|]+\|$', l.strip())]
        if not data:
            return
        rows = []
        for l in data:
            cells = [c.strip().replace("\\|", "|") for c in l.strip().strip("|").split("|")]
            rows.append(cells)
        ncols = max(len(r) for r in rows)
        table = doc.add_table(rows=len(rows), cols=ncols)
        if insert_at is not None:
            # add_table() appends at the end; move it to the placeholder's spot.
            parent, pos = insert_at
            tbl_el = table._tbl
            parent.remove(tbl_el)
            parent.insert(pos, tbl_el)
        for ri, cells in enumerate(rows):
            for ci in range(ncols):
                table.rows[ri].cells[ci].text = cells[ci] if ci < len(cells) else ""

    def _iter_block_items(self, doc):
        """Yield ('p', paragraph) / ('t', table) in document order, so tables
        aren't silently dropped the way doc.paragraphs drops them."""
        body = doc.element.body
        for child in body.iterchildren():
            if child.tag == qn('w:p'):
                yield ('p', docx.text.paragraph.Paragraph(child, doc))
            elif child.tag == qn('w:tbl'):
                yield ('t', docx.table.Table(child, doc))

    @staticmethod
    def _norm_heading(text):
        return re.sub(r"\s+", " ", (text or "").strip().lower())

    def load_and_chunk(self, filepath, max_tokens_per_chunk=1000):
        doc = docx.Document(filepath)
        self._source_headings = set()
        self._heading_display = {}
        # Images cannot survive the text pipeline (load reads text runs;
        # save rebuilds from text). Count them so the app can warn
        # instead of the figures vanishing silently (S2).
        self._input_image_count = len(
            [e for e in doc.element.iter() if e.tag.endswith('}blip')])
        chunks = []
        current_chunk = []
        current_token_count = 0

        def flush():
            nonlocal current_chunk, current_token_count
            if current_chunk:
                chunks.append("\n\n".join(current_chunk))
                current_chunk = []
                current_token_count = 0

        def push(md_text):
            nonlocal current_token_count
            tokens = self._count_tokens(md_text) if md_text else 0
            if tokens > max_tokens_per_chunk and current_chunk:
                flush()
            current_chunk.append(md_text)
            current_token_count += tokens
            if current_token_count >= max_tokens_per_chunk:
                flush()

        for kind, block in self._iter_block_items(doc):
            if kind == 'p':
                if not block.text.strip():
                    push("")  # keep blank lines / scene breaks
                    continue
                try:
                    _style = block.style.name if block.style else ""
                except Exception:
                    _style = ""
                if _style.startswith("Heading") and block.text.strip():
                    _key = self._norm_heading(block.text)
                    self._source_headings.add(_key)
                    self._heading_display[_key] = block.text.strip()
                push(self._para_to_markdown(block))
            else:
                push(self._table_to_markdown(block))

        flush()
        return chunks

    # Child-element order for word/settings.xml (CT_Settings sequence,
    # abridged) — used to insert <w:mirrorMargins/> in a schema-valid spot.
    _SETTINGS_ORDER = [
        'w:writeProtection', 'w:view', 'w:zoom', 'w:removePersonalInformation',
        'w:removeDateAndTime', 'w:doNotDisplayPageBoundaries',
        'w:printPostScriptOverText', 'w:printFractionalCharacterWidth',
        'w:printFormsData', 'w:embedSystemFonts', 'w:embedTrueTypeFonts',
        'w:doNotEmbedSystemFonts', 'w:saveSubsetFonts', 'w:saveFormsData',
        'w:mirrorMargins', 'w:alignBordersAndEdges',
        'w:bordersDoNotSurroundHeader', 'w:bordersDoNotSurroundFooter',
        'w:gutterAtTop', 'w:hideSpellingErrors', 'w:hideGrammaticalErrors',
        'w:activeWritingStyle', 'w:proofState', 'w:formsDesign',
        'w:attachedTemplate', 'w:linkStyles', 'w:stylePaneFormatFilter',
        'w:stylePaneSortMethods', 'w:documentType', 'w:mailMerge',
        'w:revisionView', 'w:trackRevisions', 'w:doNotTrackMoves',
        'w:doNotTrackFormatting', 'w:documentProtection',
        'w:autoFormatOverride', 'w:styleLockTheme', 'w:styleLockQFSet',
        'w:defaultTabStop', 'w:autoHyphenation', 'w:consecutiveHyphenLimit',
        'w:hyphenationZone', 'w:doNotHyphenateCaps', 'w:showEnvelope',
        'w:summaryLength', 'w:clickAndTypeStyle', 'w:defaultTableStyle',
        'w:evenAndOddHeaders', 'w:bookFoldRevPrinting', 'w:bookFoldPrinting',
        'w:drawingGridHorizontalSpacing', 'w:drawingGridVerticalSpacing',
        'w:displayHorizontalDrawingGridEvery',
        'w:displayVerticalDrawingGridEvery',
        'w:doNotUseMarginsForDrawingGridOrigin',
        'w:drawingGridHorizontalOrigin', 'w:drawingGridVerticalOrigin',
        'w:doNotShadeFormData', 'w:noPunctuationKerning',
        'w:characterSpacingControl', 'w:printTwoOnOne',
        'w:strictFirstAndLastChars', 'w:noLineBalance', 'w:printFullWidth',
        'w:printTextBoundary', 'w:noLeading', 'w:compat', 'w:docVars',
        'w:rsids', 'w:mathPr', 'w:attachedSchema', 'w:themeFontLang',
        'w:clrSchemeMapping', 'w:doNotIncludeSubdocsInStats',
        'w:doNotAutoCompressPictures', 'w:shapeDefaults', 'w:decimalSymbol',
        'w:listSeparator',
    ]

    def _enable_mirror_margins(self, doc):
        """Turn on mirrored (facing-page) margins so the 0.75in margin is
        always the inside/binding edge. Best-effort: never fail a save."""
        try:
            settings = doc.settings.element
            if settings.find(qn('w:mirrorMargins')) is not None:
                return
            el = settings.makeelement(qn('w:mirrorMargins'), {})
            rank = {tag: i for i, tag in enumerate(self._SETTINGS_ORDER)}
            my_rank = rank['w:mirrorMargins']
            for child in settings:
                if rank.get(child.tag, len(rank)) > my_rank:
                    child.addprevious(el)
                    return
            settings.append(el)
        except Exception:
            pass

    def _apply_kdp_profile(self, doc, para_style="indented"):
        """Enforce KDP print layout on a freshly built document:
        6x9in trim, mirrored margins (0.75in inside, 0.5in elsewhere),
        Garamond body at 11pt, justified text, chapter headings that
        start a new page. para_style: 'indented' (fiction: 0.3in first
        line indent, no paragraph spacing) or 'spaced' (nonfiction:
        flush left, 10pt after)."""
        section = doc.sections[0]
        section.page_width = Inches(6)
        section.page_height = Inches(9)
        section.left_margin = Inches(0.75)   # inside (binding) edge
        section.right_margin = Inches(0.5)   # outside edge
        section.top_margin = Inches(0.5)
        section.bottom_margin = Inches(0.5)
        section.header_distance = Inches(0.3)
        section.footer_distance = Inches(0.3)
        self._enable_mirror_margins(doc)

        black = RGBColor(0, 0, 0)
        normal = doc.styles['Normal']
        normal.font.name = 'Garamond'
        normal.font.size = Pt(11)
        normal.font.color.rgb = black
        npf = normal.paragraph_format
        npf.line_spacing = 1.15
        npf.space_before = Pt(0)
        npf.space_after = Pt(10) if para_style == "spaced" else Pt(0)
        npf.alignment = docx.enum.text.WD_ALIGN_PARAGRAPH.JUSTIFY

        h1 = doc.styles['Heading 1']
        h1.font.name = 'Garamond'
        h1.font.size = Pt(16)
        h1.font.bold = True
        h1.font.color.rgb = black
        h1pf = h1.paragraph_format
        h1pf.alignment = docx.enum.text.WD_ALIGN_PARAGRAPH.CENTER
        h1pf.page_break_before = True
        h1pf.space_before = Pt(36)
        h1pf.space_after = Pt(24)
        h1pf.keep_with_next = True

        h2 = doc.styles['Heading 2']
        h2.font.name = 'Garamond'
        h2.font.size = Pt(13)
        h2.font.bold = True
        h2.font.color.rgb = black
        h2.paragraph_format.space_before = Pt(18)
        h2.paragraph_format.space_after = Pt(6)
        h2.paragraph_format.keep_with_next = True

        for name, size in (('Heading 3', 12), ('Heading 4', 11),
                           ('Heading 5', 11), ('Heading 6', 11)):
            try:
                st = doc.styles[name]
            except KeyError:
                continue
            st.font.name = 'Garamond'
            st.font.size = Pt(size)
            st.font.bold = True
            st.font.color.rgb = black
            st.paragraph_format.space_before = Pt(12)
            st.paragraph_format.space_after = Pt(4)

        try:
            title = doc.styles['Title']
            title.font.name = 'Garamond'
            title.font.size = Pt(26)
            title.font.color.rgb = black
            title.paragraph_format.alignment = docx.enum.text.WD_ALIGN_PARAGRAPH.CENTER
        except KeyError:
            pass

    def save_document(self, edited_chunks, output_filepath, kdp_format=False,
                      kdp_para_style="indented", known_headings=None,
                      log_callback=None):
        new_doc = docx.Document()
        if kdp_format:
            self._apply_kdp_profile(new_doc, kdp_para_style)
        # When the caller supplies the source document's heading texts,
        # only those '#' lines are promoted back to heading styles. A '#'
        # line that was body text in the source (a code comment inside an
        # example, say) stays body text, '#' and all. None = legacy
        # behavior (promote every '#' line), used by the co-author flow,
        # whose headings are newly generated.
        known = None
        if known_headings:
            known = {self._norm_heading(h) for h in known_headings}
        at_block_start = True  # first body para after a break: no indent
        for chunk_idx, chunk in enumerate(edited_chunks, 1):
            clean_chunk = self._sanitize_output(chunk)
            # Save-time tripwire (S1) — now with teeth (Rounds 1-3,
            # review R3): the sanitizer should only ever remove model
            # scaffolding. When it would eat a real share of a chunk,
            # the chunk is saved UNSANITIZED — the gated/original text
            # wins over the shape-based deletion rules (the
            # ---EXCEPTIONS--- cut, bracketed-line and preamble
            # deletions), because those shapes can be author text and
            # until now they amputated do-no-harm fallback chunks after
            # every gate had passed them. "Real share" means: >= 50
            # words and > 1% lost (the original S1 tripwire), OR a
            # total wipe of a non-empty chunk, OR > 50% lost from a
            # smaller chunk. The restore is logged loudly either way.
            _before = len(chunk.split())
            _after = len(clean_chunk.split())
            _restore = (
                (_before >= 50 and _after < _before * 0.99)
                or (0 < _before < 50 and _after == 0)
                or (20 <= _before < 50 and _after < _before * 0.5)
            )
            if _restore:
                if log_callback:
                    log_callback(
                        f"WARNING: sanitizer would have dropped {_before - _after} of "
                        f"{_before} words ({(_before - _after) / _before * 100:.1f}%) "
                        f"from chunk {chunk_idx} at save — chunk saved UNSANITIZED "
                        f"(do-no-harm restore, review R3).")
                clean_chunk = chunk.strip()
            elif log_callback and _before >= 50 and _after < _before:
                log_callback(
                    f"Note: sanitizer trimmed {_before - _after} of {_before} words "
                    f"from chunk {chunk_idx} at save (within the do-no-harm threshold).")
            paragraphs = clean_chunk.split('\n\n')
            for p in paragraphs:
                clean_p = p.strip()
                if not clean_p:
                    new_doc.add_paragraph()  # preserve blank lines
                    at_block_start = True
                    continue

                new_para = new_doc.add_paragraph()
                if not kdp_format:
                    new_para.paragraph_format.space_before = Pt(0)
                    new_para.paragraph_format.space_after = Pt(0)

                if clean_p in ["* * *", "# # #", "***"]:
                    new_para.alignment = docx.enum.text.WD_ALIGN_PARAGRAPH.CENTER
                    new_para.paragraph_format.first_line_indent = Inches(0)
                    if kdp_format:
                        # Legacy saves swallowed the marker into an empty
                        # paragraph; KDP output prints it, centered.
                        new_para.add_run("* * *")
                        new_para.paragraph_format.space_before = Pt(12)
                        new_para.paragraph_format.space_after = Pt(12)
                    at_block_start = True
                    continue

                # Markdown tables back to Word tables.
                lines = [l for l in clean_p.split('\n') if l.strip()]
                if lines and all(l.strip().startswith('|') for l in lines):
                    ref_el = new_para._element
                    parent = ref_el.getparent()
                    pos = list(parent).index(ref_el)
                    parent.remove(ref_el)
                    self._markdown_to_table([l.strip() for l in lines], new_doc, insert_at=(parent, pos))
                    at_block_start = True
                    continue

                # Markdown headings back to Word heading styles.
                first_line, _, rest = clean_p.partition('\n')
                m = re.match(r'^(#{1,6})\s+(.*)$', first_line.strip())
                heading_key = None
                if m and known is not None:
                    heading_key = self._norm_heading(m.group(2))
                    if heading_key not in known:
                        # The model sometimes fuses a two-line heading
                        # ("CHAPTER 1The Arithmetic"); retry with all
                        # whitespace removed before giving up on it.
                        squashed = heading_key.replace(" ", "")
                        matches = [k for k in known
                                   if k.replace(" ", "") == squashed]
                        heading_key = matches[0] if len(matches) == 1 else None
                    if heading_key is None:
                        m = None  # body text in the source; keep it body text
                if m:
                    new_para.style = new_doc.styles[f'Heading {len(m.group(1))}']
                    display = None
                    if heading_key is not None:
                        display = getattr(self, "_heading_display", {}).get(heading_key)
                    self._markdown_to_runs(display if display else m.group(2), new_para)
                    at_block_start = True
                    if rest.strip():
                        # Body text shared the block with the heading
                        # line; keep it as its own paragraph, not dropped.
                        body_para = new_doc.add_paragraph()
                        if not kdp_format:
                            body_para.paragraph_format.space_before = Pt(0)
                            body_para.paragraph_format.space_after = Pt(0)
                            body_para.paragraph_format.first_line_indent = Inches(0.3)
                        self._markdown_to_runs(rest.strip(), body_para)
                        at_block_start = False
                    continue

                if kdp_format:
                    if kdp_para_style == "spaced":
                        new_para.paragraph_format.first_line_indent = Inches(0)
                        new_para.paragraph_format.space_after = Pt(10)
                    else:
                        new_para.paragraph_format.first_line_indent = \
                            Inches(0) if at_block_start else Inches(0.3)
                        new_para.paragraph_format.space_after = Pt(0)
                else:
                    new_para.paragraph_format.first_line_indent = Inches(0.3)
                self._markdown_to_runs(clean_p, new_para)
                at_block_start = False

        # Atomic save (Rounds 1-3, review R4): a crash/kill/disk-full
        # here must not corrupt the file already at output_filepath.
        atomic_save_docx(new_doc, output_filepath)
        return output_filepath

    def _markdown_to_runs(self, md_text, new_para):
        # Single newlines are the source's soft line breaks (a heading's
        # second line, a wrapped verse or address): keep them as line
        # breaks inside the paragraph instead of fusing the words they
        # separate into one line.
        for si, segment in enumerate(md_text.split('\n')):
            if si:
                new_para.add_run().add_break()
            parts = re.split(r'(\*\*\*.*?\*\*\*|\*\*.*?\*\*|\*.*?\*)', segment)
            for part in parts:
                if not part:
                    continue
                if part.startswith('***') and part.endswith('***'):
                    run = new_para.add_run(part[3:-3])
                    run.bold = True
                    run.italic = True
                elif part.startswith('**') and part.endswith('**'):
                    run = new_para.add_run(part[2:-2])
                    run.bold = True
                elif part.startswith('*') and part.endswith('*'):
                    run = new_para.add_run(part[1:-1])
                    run.italic = True
                else:
                    new_para.add_run(part)

    @staticmethod
    def _truncate_at_sentence(text, word_limit):
        """Cut text to a word limit at a sentence boundary when one is
        available in the back half of the cut. (The old truncation
        sliced the word list exactly at the limit, leaving generated
        blocks ending mid-sentence — sometimes mid-word.)"""
        words = text.split()
        if len(words) <= word_limit:
            return text
        cut = " ".join(words[:word_limit])
        ends = [m.end() for m in re.finditer(r'[.!?…]["”’\']?', cut)]
        if ends and ends[-1] > len(cut) * 0.5:
            return cut[:ends[-1]]
        return cut

    def call_ollama(self, model, system_prompt, text, context_size=4096, stream_callback=None, max_retries=3, is_edit_pass=True, target_word_limit=None, temperature=None):
        url = f"{self.ollama_url}/api/generate"
        if is_edit_pass:
            final_prompt = (
                f"{system_prompt}\n\n"
                "CRITICAL INSTRUCTION: You are receiving text formatted in Markdown. "
                "You MUST preserve any bold (**text**) or italic (*text*) formatting in your output. "
                "Preserve blank lines exactly as they appear — they mark scene breaks. "
                "Never drop, merge, or invent '#'-style headings. "
                "Return ONLY the edited text — no preamble ('Here is...'), no explanation, "
                "no summary of changes, no code fences.\n\n"
                "TEXT TO EDIT:\n"
                f"{text}"
            )
        else:
            final_prompt = f"{system_prompt}\n\nTEXT:\n{text}"

        # FIT GUARD: never hand Ollama a window too small for the prompt
        # plus the expected reply. When prompt + generation reach num_ctx,
        # Ollama stops mid-stream — for an edit pass the chunk comes back
        # truncated, and the WatchTower rejects it for word-count drift.
        # The caller's context_size is a floor, not a ceiling: raise it
        # (to a sane cap) whenever the work in hand doesn't fit.
        prompt_tokens = self._count_tokens(final_prompt)
        if target_word_limit:
            expected_out = int(target_word_limit * 1.4) + 256
        elif is_edit_pass:
            expected_out = int(self._count_tokens(text) * 1.25) + 256
        else:
            expected_out = 512
        effective_ctx = context_size
        if prompt_tokens + expected_out > effective_ctx:
            effective_ctx = min(prompt_tokens + expected_out, 16384)

        options = {"temperature": 0.3 if temperature is None else temperature, "num_ctx": effective_ctx, "num_thread": self.num_thread, "num_keep": 4}
        if target_word_limit:
            max_tokens = int(target_word_limit * 1.4)
            options["num_predict"] = max_tokens
        elif is_edit_pass:
            # Cap runaway generations: an edit pass shouldn't return 5x what it got.
            options["num_predict"] = int(prompt_tokens * 1.6) + 256

        data = {
            "model": model,
            "prompt": final_prompt,
            "stream": True,
            "options": options
        }
        if self.think_off:
            # Reasoning models: don't generate the trace at all. The
            # strippers remain as a backstop for models that ignore it.
            data["think"] = False
        payload = json.dumps(data).encode('utf-8')
        headers = {'Content-Type': 'application/json'}
        attempt = 0
        base_delay = 2

        while attempt <= max_retries:
            if self.cancel_requested:
                raise CancelRequested("Processing cancelled by user.")
            try:
                req = urllib.request.Request(url, data=payload, headers=headers)
                generated_text = ""
                with urllib.request.urlopen(req, timeout=120) as response:
                    for line in response:
                        if self.cancel_requested:
                            raise CancelRequested("Processing cancelled by user.")
                        if not line or not line.strip():
                            continue  # skip blank keepalive lines
                        chunk_data = json.loads(line.decode('utf-8'))
                        new_words = chunk_data.get("response", "")
                        generated_text += new_words

                        if target_word_limit:
                            current_words = generated_text.split()
                            if len(current_words) >= target_word_limit:
                                generated_text = self._truncate_at_sentence(generated_text, target_word_limit)
                                if stream_callback:
                                    stream_callback(generated_text)
                                return generated_text.strip()

                        if stream_callback:
                            stream_callback(generated_text)
                        if chunk_data.get("done"):
                            return generated_text.strip()
                # Stream ended without done:true — return what we have
                # instead of looping forever on the same request.
                if generated_text.strip():
                    return generated_text.strip()
                raise urllib.error.URLError("Empty response from Ollama (stream ended without done:true).")
            except (urllib.error.URLError, ConnectionResetError, TimeoutError, json.JSONDecodeError) as e:
                attempt += 1
                if attempt > max_retries:
                    raise Exception(f"Ollama API failed after {max_retries} attempts: {e}")
                # Interruptible backoff (round 16, S13): poll the
                # cancel flag through the wait — a Stop click during a
                # retry storm used to wait out the full sleep (and the
                # next attempt) before the run noticed.
                _delay = base_delay ** attempt
                _waited = 0.0
                while _waited < _delay:
                    if self.cancel_requested:
                        raise CancelRequested("Processing cancelled by user.")
                    time.sleep(0.1)
                    _waited += 0.1
