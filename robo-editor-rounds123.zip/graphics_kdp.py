"""KDP graphics math and image builders for the Robo-Editor Graphics Studio.

Pure spec calculations (no third-party imports) plus Pillow-based builders
for print cover wraps, ebook covers, and interior graphics. Defaults are
Bob's novel profile: 6x9 trim, cream paper, 300 DPI, mirrored margins
(inside 0.75in / outside 0.5in) matching the editor's KDP format profile.

KDP paperback figures used here (Amazon's published cover equations):
  - Bleed: 0.125in on every outer edge.
  - Cover width  = bleed + back + spine + front + bleed
  - Cover height = bleed + trim height + bleed
  - Spine per page: white 0.002252in, cream 0.0025in, colour 0.002347in
  - Page count must be 24-828; spine text needs 79+ pages and 0.0625in
    clearance on each side of the spine.
  - Ebook cover: 1600 x 2560 px (1.6:1), JPEG.
"""

import os

BLEED_IN = 0.125
DEFAULT_DPI = 300
PAGE_MIN, PAGE_MAX = 24, 828
SPINE_TEXT_MIN_PAGES = 79
SPINE_TEXT_CLEARANCE_IN = 0.0625
BARCODE_W_IN, BARCODE_H_IN = 2.0, 1.2
BARCODE_INSET_IN = 0.25          # from the back cover's trim edges
TEXT_SAFE_IN = 0.375             # keep cover text this far inside the trim
EBOOK_W_PX, EBOOK_H_PX = 1600, 2560

PAPER_SPINE_PER_PAGE = {
    "White": 0.002252,
    "Cream": 0.0025,
    "Color": 0.002347,
}

TRIM_SIZES = {
    "5 x 8": (5.0, 8.0),
    "5.25 x 8": (5.25, 8.0),
    "5.5 x 8.5": (5.5, 8.5),
    "6 x 9": (6.0, 9.0),
    "6.14 x 9.21": (6.14, 9.21),
    "7 x 10": (7.0, 10.0),
    "8 x 10": (8.0, 10.0),
    "8.5 x 8.5": (8.5, 8.5),
    "8.5 x 11": (8.5, 11.0),
}

# The editor's KDP interior profile (engine save path).
INTERIOR_MARGINS_IN = {"inside": 0.75, "outside": 0.5, "top": 0.5, "bottom": 0.5}

try:
    from PIL import Image, ImageDraw, ImageFont
    HAS_PIL = True
except Exception:  # Pillow missing: spec math still works, builders raise.
    HAS_PIL = False


def _px(inches, dpi):
    return int(round(inches * dpi))


def cover_spec(trim_w, trim_h, pages, paper, dpi=DEFAULT_DPI):
    """Full KDP paperback cover geometry for one book.

    Returns a dict of inches + pixels + layout rectangles (inches, origin
    at the wrap's top-left corner) + a warnings list. Raises ValueError on
    nonsense inputs (unknown paper, non-positive trim/page count).
    """
    if paper not in PAPER_SPINE_PER_PAGE:
        raise ValueError(f"Unknown paper '{paper}'. Choose one of: "
                         + ", ".join(PAPER_SPINE_PER_PAGE))
    pages = int(pages)
    if pages <= 0:
        raise ValueError("Page count must be a positive number.")
    if trim_w <= 0 or trim_h <= 0:
        raise ValueError("Trim size must be positive.")

    warnings = []
    if pages < PAGE_MIN:
        warnings.append(f"KDP paperbacks need at least {PAGE_MIN} pages (you set {pages}).")
    if pages > PAGE_MAX:
        warnings.append(f"KDP paperbacks cap at {PAGE_MAX} pages (you set {pages}).")

    spine_in = pages * PAPER_SPINE_PER_PAGE[paper]
    wrap_w_in = BLEED_IN + trim_w + spine_in + trim_w + BLEED_IN
    wrap_h_in = trim_h + 2 * BLEED_IN

    back_x0 = 0.0
    spine_x0 = BLEED_IN + trim_w
    front_x0 = spine_x0 + spine_in

    spine_text_allowed = pages >= SPINE_TEXT_MIN_PAGES
    if not spine_text_allowed:
        warnings.append(f"Spine text is not allowed under {SPINE_TEXT_MIN_PAGES} pages; "
                        "the spine will be built blank.")
    spine_text_width_in = max(0.0, spine_in - 2 * SPINE_TEXT_CLEARANCE_IN)

    barcode = {
        "x_in": spine_x0 - BARCODE_INSET_IN - BARCODE_W_IN,
        "y_in": BLEED_IN + trim_h - BARCODE_INSET_IN - BARCODE_H_IN,
        "w_in": BARCODE_W_IN,
        "h_in": BARCODE_H_IN,
    }

    return {
        "trim_w_in": trim_w, "trim_h_in": trim_h, "pages": pages,
        "paper": paper, "dpi": dpi,
        "spine_in": round(spine_in, 4),
        "wrap_w_in": round(wrap_w_in, 4), "wrap_h_in": round(wrap_h_in, 4),
        "wrap_w_px": _px(wrap_w_in, dpi), "wrap_h_px": _px(wrap_h_in, dpi),
        "front_w_px": _px(trim_w, dpi), "front_h_px": _px(trim_h, dpi),
        "back_x0_in": back_x0, "spine_x0_in": round(spine_x0, 4),
        "front_x0_in": round(front_x0, 4),
        "spine_text_allowed": spine_text_allowed,
        "spine_text_width_in": round(spine_text_width_in, 4),
        "barcode": barcode,
        "text_safe_in": TEXT_SAFE_IN,
        "ebook_w_px": EBOOK_W_PX, "ebook_h_px": EBOOK_H_PX,
        "warnings": warnings,
    }


def interior_spec(trim_w, dpi=DEFAULT_DPI, margins=None):
    """Usable interior image widths for the editor's KDP margin profile."""
    m = dict(INTERIOR_MARGINS_IN)
    if margins:
        m.update(margins)
    text_w_in = trim_w - m["inside"] - m["outside"]
    return {
        "text_width_in": round(text_w_in, 4),
        "full_width_px": _px(text_w_in, dpi),
        "half_width_px": _px(text_w_in / 2, dpi),
        "margins": m, "dpi": dpi,
    }


def spec_brief(spec, interior, title="", author=""):
    """A plain-text production brief: hand it to a designer or an image
    generator and every number they need is on the page."""
    lines = [
        "KDP COVER PRODUCTION BRIEF",
        f"Book: {title or '(untitled)'}" + (f" by {author}" if author else ""),
        f"Trim: {spec['trim_w_in']} x {spec['trim_h_in']} in | Paper: {spec['paper']} | "
        f"Pages: {spec['pages']} | {spec['dpi']} DPI",
        f"Spine width: {spec['spine_in']} in",
        f"Full wrap (with 0.125 in bleed): {spec['wrap_w_in']} x {spec['wrap_h_in']} in "
        f"= {spec['wrap_w_px']} x {spec['wrap_h_px']} px",
        f"Front cover alone: {spec['front_w_px']} x {spec['front_h_px']} px",
        f"Ebook cover: {spec['ebook_w_px']} x {spec['ebook_h_px']} px JPEG",
        f"Keep all cover text at least {spec['text_safe_in']} in inside the trim lines.",
        f"Barcode box (back cover, bottom right): {BARCODE_W_IN} x {BARCODE_H_IN} in, "
        f"{BARCODE_INSET_IN} in from the trim edges - leave it blank for KDP's barcode.",
        "Spine text: " + ("allowed (79+ pages); keep 0.0625 in clear on both sides."
                          if spec["spine_text_allowed"] else "NOT allowed at this page count."),
        f"Interior images: full text width {interior['text_width_in']} in "
        f"= {interior['full_width_px']} px at {interior['dpi']} DPI; "
        f"half page = {interior['half_width_px']} px.",
    ]
    for w in spec["warnings"]:
        lines.append("WARNING: " + w)
    return "\n".join(lines)


def compose_art_prompt(subject, setting="", mood="", style="", genre="",
                       spec=None):
    """Build a cover-art prompt for an external image generator (Ollama
    models write the words; the picture comes from an image tool)."""
    bits = [b for b in [subject, setting] if b]
    scene = ", ".join(bits) if bits else "a striking novel cover scene"
    lines = [
        "PROMPT:",
        f"{scene}"
        + (f", {mood} mood" if mood else "")
        + (f", {style}" if style else ", painterly, cinematic lighting")
        + (f", {genre} novel cover art" if genre else ", novel cover art")
        + ", no text, no letters, no watermark, leave the top third "
          "uncluttered for the title and the bottom right of the back cover "
          "clear for a barcode",
    ]
    if spec:
        lines.append(
            f"Compose for a {spec['trim_w_in']} x {spec['trim_h_in']} in front cover; "
            f"the full wrap canvas is {spec['wrap_w_px']} x {spec['wrap_h_px']} px "
            f"at {spec['dpi']} DPI with the spine {spec['spine_in']} in wide in the middle.")
    lines += [
        "",
        "NEGATIVE PROMPT:",
        "text, typography, letters, words, logo, watermark, signature, "
        "blurry, low resolution, distorted faces, extra limbs",
    ]
    return "\n".join(lines)


# --------------------------------------------------------------------------
# Pillow builders
# --------------------------------------------------------------------------

def _require_pil():
    if not HAS_PIL:
        raise RuntimeError("Pillow is not installed. Run: pip install Pillow")


_FONT_CANDIDATES = [
    # Windows
    os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts", "georgia.ttf"),
    os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts", "times.ttf"),
    # macOS
    "/Library/Fonts/Georgia.ttf",
    "/System/Library/Fonts/Supplemental/Georgia.ttf",
    # Linux
    "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf",
]
_FONT_CANDIDATES_BOLD = [
    os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts", "georgiab.ttf"),
    os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts", "timesbd.ttf"),
    "/Library/Fonts/Georgia Bold.ttf",
    "/System/Library/Fonts/Supplemental/Georgia Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf",
]


def _find_font(size, bold=False):
    _require_pil()
    for path in (_FONT_CANDIDATES_BOLD if bold else _FONT_CANDIDATES):
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                continue
    try:  # Pillow >= 9.2 can scale its default font
        return ImageFont.load_default(size=size)
    except Exception:
        return ImageFont.load_default()


def _cover_fit(img, target_w, target_h):
    """Resize + center-crop so img fills (target_w, target_h) exactly."""
    scale = max(target_w / img.width, target_h / img.height)
    resized = img.resize((max(1, round(img.width * scale)),
                          max(1, round(img.height * scale))), Image.LANCZOS)
    x = (resized.width - target_w) // 2
    y = (resized.height - target_h) // 2
    return resized.crop((x, y, x + target_w, y + target_h))


def _wrap(draw, text, font, max_w):
    words, lines, cur = text.split(), [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if draw.textlength(trial, font=font) <= max_w or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def _centered(draw, cx, y, text, font, fill, max_w, leading=1.15):
    for line in _wrap(draw, text, font, max_w):
        w = draw.textlength(line, font=font)
        draw.text((cx - w / 2, y), line, font=font, fill=fill)
        y += font.size * leading
    return y


def build_print_cover(out_path, spec, art_path=None, art_image=None,
                      bg_color=(26, 26, 34),
                      title="", author="", series="", tagline="", blurb="",
                      text_color=(245, 240, 228)):
    """Compose a full KDP paperback wrap (back + spine + front) as a PNG
    stamped at the spec's DPI. Returns out_path."""
    _require_pil()
    dpi = spec["dpi"]
    W, H = spec["wrap_w_px"], spec["wrap_h_px"]
    if art_image is not None:
        base = _cover_fit(art_image.convert("RGB"), W, H)
    elif art_path and os.path.exists(art_path):
        base = _cover_fit(Image.open(art_path).convert("RGB"), W, H)
    else:
        base = Image.new("RGB", (W, H), bg_color)
    draw = ImageDraw.Draw(base, "RGBA")

    front_x = _px(spec["front_x0_in"], dpi)
    front_w = spec["front_w_px"]
    back_w = front_w
    safe = _px(TEXT_SAFE_IN, dpi)

    # -- Back cover: darken for legibility, blurb top-left, barcode box.
    draw.rectangle([0, 0, back_w, H], fill=(0, 0, 0, 96))
    if blurb:
        font_b = _find_font(max(24, dpi // 11))
        x, y = safe, safe
        for para in blurb.split("\n"):
            for line in _wrap(draw, para, font_b, back_w - 2 * safe):
                draw.text((x, y), line, font=font_b, fill=text_color)
                y += font_b.size * 1.3
            y += font_b.size * 0.6
    bc = spec["barcode"]
    bx, by = _px(bc["x_in"], dpi), _px(bc["y_in"], dpi)
    bw, bh = _px(bc["w_in"], dpi), _px(bc["h_in"], dpi)
    draw.rectangle([bx, by, bx + bw, by + bh], fill=(255, 255, 255))
    font_bc = _find_font(max(20, dpi // 14), bold=True)
    label = "ISBN BARCODE"
    lw = draw.textlength(label, font=font_bc)
    draw.text((bx + (bw - lw) / 2, by + bh / 2 - font_bc.size / 2),
              label, font=font_bc, fill=(0, 0, 0))

    # -- Spine: vertical text, only when KDP allows it.
    spine_text = " ".join(t for t in [title.upper() if title else "",
                                      author] if t)
    if spec["spine_text_allowed"] and spine_text:
        spine_w_px = _px(spec["spine_in"], dpi)
        font_s = _find_font(max(18, int(spine_w_px * 0.52)), bold=True)
        tl = draw.textlength(spine_text, font=font_s)
        strip = Image.new("RGBA", (int(tl) + 20, font_s.size + 16),
                          (0, 0, 0, 0))
        sd = ImageDraw.Draw(strip)
        sd.text((10, 8), spine_text, font=font_s, fill=text_color)
        strip = strip.rotate(-90, expand=True)  # reads top-to-bottom
        sx = _px(spec["spine_x0_in"], dpi) + (spine_w_px - strip.width) // 2
        sy = (H - strip.height) // 2
        base.paste(strip, (sx, sy), strip)
        draw = ImageDraw.Draw(base, "RGBA")

    # -- Front cover: series, title, tagline, author.
    cx = front_x + front_w / 2
    y = safe
    if series:
        font_ser = _find_font(max(22, dpi // 10), bold=True)
        y = _centered(draw, cx, y, series.upper(), font_ser,
                      text_color, front_w - 2 * safe) + dpi // 12
    if title:
        font_t = _find_font(max(40, dpi // 4), bold=True)
        y = _centered(draw, cx, y, title.upper(), font_t,
                      text_color, front_w - 2 * safe) + dpi // 14
    if tagline:
        font_tag = _find_font(max(22, dpi // 11))
        _centered(draw, cx, y, tagline, font_tag, text_color,
                  front_w - 2 * safe)
    if author:
        font_a = _find_font(max(26, dpi // 8), bold=True)
        lines = _wrap(draw, author.upper(), font_a, front_w - 2 * safe)
        ay = H - safe - len(lines) * font_a.size * 1.15
        _centered(draw, cx, ay, author.upper(), font_a, text_color,
                  front_w - 2 * safe)

    base.save(out_path, dpi=(dpi, dpi))
    return out_path


def build_ebook_cover(out_path, art_path=None, art_image=None,
                      bg_color=(26, 26, 34),
                      title="", author="", series="",
                      text_color=(245, 240, 228)):
    """KDP ebook cover: 1600 x 2560 JPEG."""
    _require_pil()
    W, H = EBOOK_W_PX, EBOOK_H_PX
    if art_image is not None:
        base = _cover_fit(art_image.convert("RGB"), W, H)
    elif art_path and os.path.exists(art_path):
        base = _cover_fit(Image.open(art_path).convert("RGB"), W, H)
    else:
        base = Image.new("RGB", (W, H), bg_color)
    draw = ImageDraw.Draw(base, "RGBA")
    safe = 110
    cx, y = W / 2, safe
    if series:
        f = _find_font(64, bold=True)
        y = _centered(draw, cx, y, series.upper(), f, text_color,
                      W - 2 * safe) + 40
    if title:
        f = _find_font(190, bold=True)
        y = _centered(draw, cx, y, title.upper(), f, text_color,
                      W - 2 * safe) + 30
    if author:
        f = _find_font(96, bold=True)
        lines = _wrap(draw, author.upper(), f, W - 2 * safe)
        ay = H - safe - len(lines) * f.size * 1.15
        _centered(draw, cx, ay, author.upper(), f, text_color, W - 2 * safe)
    base.save(out_path, quality=95)
    return out_path


def inspect_image(path):
    """Facts about an image file, in plain terms."""
    _require_pil()
    with Image.open(path) as img:
        dpi_info = img.info.get("dpi", (None, None))
        w, h = img.size
        return {
            "path": path, "format": img.format, "mode": img.mode,
            "width_px": w, "height_px": h,
            "dpi_x": dpi_info[0], "dpi_y": dpi_info[1],
            "print_width_at_300dpi_in": round(w / 300, 2),
            "print_height_at_300dpi_in": round(h / 300, 2),
        }


def prep_interior_image(src, dst, width_px, grayscale=False, dpi=DEFAULT_DPI):
    """Resize an interior graphic to an exact pixel width at print DPI,
    keeping its aspect ratio. Saves PNG or JPEG by dst extension."""
    _require_pil()
    with Image.open(src) as img:
        img = img.convert("L" if grayscale else "RGB")
        ratio = width_px / img.width
        resized = img.resize((width_px, max(1, round(img.height * ratio))),
                             Image.LANCZOS)
        if dst.lower().endswith((".jpg", ".jpeg")):
            resized.save(dst, quality=95, dpi=(dpi, dpi))
        else:
            resized.save(dst, dpi=(dpi, dpi))
    return dst
