"""Graphics Studio (KDP) tests.

Self-contained: synthetic images only. Run from the project root:

    python -m unittest discover -s tests -v

The spec numbers asserted here are KDP's published cover equations
(the same arithmetic verified against THE BROKEN's shipped cover:
264 pages on cream at 6x9 gave a 0.66in spine).
"""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import graphics_kdp as gk


class CoverSpecTests(unittest.TestCase):
    def test_cream_spine_and_wrap(self):
        spec = gk.cover_spec(6.0, 9.0, 264, "Cream")
        self.assertEqual(spec["spine_in"], 0.66)
        self.assertEqual(spec["wrap_w_in"], 12.91)
        self.assertEqual(spec["wrap_h_in"], 9.25)
        self.assertEqual(spec["wrap_w_px"], 3873)
        self.assertEqual(spec["wrap_h_px"], 2775)
        self.assertTrue(spec["spine_text_allowed"])

    def test_white_spine(self):
        spec = gk.cover_spec(6.0, 9.0, 250, "White")
        self.assertAlmostEqual(spec["spine_in"], 0.563, places=3)

    def test_color_spine(self):
        spec = gk.cover_spec(6.0, 9.0, 100, "Color")
        self.assertAlmostEqual(spec["spine_in"], 0.2347, places=4)

    def test_spine_text_threshold(self):
        self.assertFalse(gk.cover_spec(6.0, 9.0, 78, "Cream")["spine_text_allowed"])
        self.assertTrue(gk.cover_spec(6.0, 9.0, 79, "Cream")["spine_text_allowed"])

    def test_page_count_warnings(self):
        self.assertTrue(gk.cover_spec(6.0, 9.0, 10, "Cream")["warnings"])
        self.assertTrue(gk.cover_spec(6.0, 9.0, 900, "Cream")["warnings"])
        self.assertEqual(gk.cover_spec(6.0, 9.0, 250, "Cream")["warnings"], [])

    def test_unknown_paper_raises(self):
        with self.assertRaises(ValueError):
            gk.cover_spec(6.0, 9.0, 250, "Parchment")

    def test_barcode_box_on_back_cover(self):
        spec = gk.cover_spec(6.0, 9.0, 264, "Cream")
        bc = spec["barcode"]
        # Entirely inside the back cover (0 .. bleed + trim width).
        self.assertGreaterEqual(bc["x_in"], 0)
        self.assertLessEqual(bc["x_in"] + bc["w_in"], 0.125 + 6.0)
        self.assertLessEqual(bc["y_in"] + bc["h_in"], 0.125 + 9.0)


class InteriorSpecTests(unittest.TestCase):
    def test_editor_margin_profile(self):
        spec = gk.interior_spec(6.0)
        self.assertEqual(spec["text_width_in"], 4.75)   # 6 - 0.75 - 0.5
        self.assertEqual(spec["full_width_px"], 1425)  # 4.75in @ 300 DPI
        self.assertEqual(spec["half_width_px"], 712)


@unittest.skipUnless(gk.HAS_PIL, "Pillow not installed")
class BuilderTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        from PIL import Image
        self.art = os.path.join(self.tmp, "art.png")
        Image.new("RGB", (900, 1400), (40, 60, 90)).save(self.art)

    def test_print_wrap_size_and_dpi(self):
        from PIL import Image
        spec = gk.cover_spec(6.0, 9.0, 264, "Cream")
        out = os.path.join(self.tmp, "wrap.png")
        gk.build_print_cover(out, spec, art_path=self.art,
                             title="The Broken", author="Bob Timpone",
                             series="The Second Ledger",
                             tagline="Two hundred and eleven names.",
                             blurb="A thousand-year war. The Broken hold the line.")
        with Image.open(out) as img:
            self.assertEqual(img.size, (3873, 2775))
            dpi = img.info.get("dpi", (0, 0))
            self.assertAlmostEqual(dpi[0], 300, delta=1.5)

    def test_ebook_cover_size(self):
        from PIL import Image
        out = os.path.join(self.tmp, "ebook.jpg")
        gk.build_ebook_cover(out, art_path=self.art,
                             title="The Broken", author="Bob Timpone")
        with Image.open(out) as img:
            self.assertEqual(img.size, (1600, 2560))
            self.assertEqual(img.format, "JPEG")

    def test_prep_interior_image(self):
        from PIL import Image
        src = os.path.join(self.tmp, "fig.png")
        Image.new("RGB", (2850, 1000), (200, 200, 200)).save(src)
        out = os.path.join(self.tmp, "fig-kdp.png")
        gk.prep_interior_image(src, out, 1425)
        with Image.open(out) as img:
            self.assertEqual(img.size, (1425, 500))

    def test_brief_and_prompt_carry_the_numbers(self):
        spec = gk.cover_spec(6.0, 9.0, 264, "Cream")
        brief = gk.spec_brief(spec, gk.interior_spec(6.0),
                              "The Broken", "Bob Timpone")
        self.assertIn("3873", brief)
        self.assertIn("0.66", brief)
        prompt = gk.compose_art_prompt("a scarred drop pod in the mud",
                                       genre="science fiction", spec=spec)
        self.assertIn("NEGATIVE PROMPT", prompt)
        self.assertIn("3873", prompt)


if __name__ == "__main__":
    unittest.main()
