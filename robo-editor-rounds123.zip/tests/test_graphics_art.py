"""Artwork generation tests (Bob's bug report: the first cover builder
only composited text over a flat background - it generated nothing).

Self-contained: the Stable Diffusion tests run against a stub HTTP
server on localhost; no real SD install is required.
"""
import base64
import io
import json
import os
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import graphics_art as ga
import graphics_kdp as gk


class BuiltinArtTests(unittest.TestCase):
    def test_generates_real_artwork_not_a_flat_color(self):
        img = ga.generate_art_image(800, 1200, "a scarred drop pod in the mud",
                                    genre="science fiction")
        self.assertEqual(img.size, (800, 1200))
        small = img.resize((100, 150))
        colors = small.getcolors(100 * 150)
        self.assertGreater(len(colors), 120)  # layered art, not a fill

    def test_deterministic_same_seed_same_picture(self):
        a = ga.generate_art_image(400, 600, "the long dark", genre="fantasy")
        b = ga.generate_art_image(400, 600, "the long dark", genre="fantasy")
        self.assertEqual(a.tobytes(), b.tobytes())

    def test_different_seed_different_picture(self):
        a = ga.generate_art_image(400, 600, "the long dark", genre="fantasy")
        b = ga.generate_art_image(400, 600, "a city of towers", genre="fantasy")
        self.assertNotEqual(a.tobytes(), b.tobytes())

    def test_hero_keywords_pick_shapes(self):
        self.assertEqual(ga._pick_hero("a drop pod lands"), "pod")
        self.assertEqual(ga._pick_hero("the colony ark departs"), "ship")
        self.assertEqual(ga._pick_hero("a castle on the hill"), "tower")
        self.assertEqual(ga._pick_hero("a quiet walk"), "figure")


class WorkerThreadSafetyTests(unittest.TestCase):
    """The cover build worker must never read Tk state: Tk variables
    and widgets are only safe on the main thread, and reading them
    from the worker deadlocked the end-to-end GUI smoke (the build
    hung forever with no output). Values are captured up front by
    _capture_cover_art on the main thread."""

    def _func_source(self, name):
        path = os.path.join(os.path.dirname(os.path.dirname(
            os.path.abspath(__file__))), "graphics_page.py")
        src = open(path, encoding="utf-8").read()
        start = src.index(f"def {name}")
        nxt = src.find("\n    def ", start + 1)
        return src[start:nxt if nxt != -1 else len(src)]

    def test_resolve_cover_art_reads_no_tk_state(self):
        body = self._func_source("_resolve_cover_art")
        self.assertNotIn("_var.get(", body)
        self.assertNotIn("_box.get(", body)
        self.assertNotIn("self.master.", body)

    def test_capture_happens_before_the_worker_starts(self):
        body = self._func_source("_launch_cover_build")
        self.assertLess(body.index("_capture_cover_art"),
                        body.index("threading.Thread"))


class SDSizeTests(unittest.TestCase):
    def test_size_is_capped_aspect_true_multiple_of_8(self):
        w, h = ga.sd_size_for(3873, 2775)
        self.assertLessEqual(max(w, h), 1344)
        self.assertEqual(w % 8, 0)
        self.assertEqual(h % 8, 0)
        self.assertAlmostEqual(w / h, 3873 / 2775, delta=0.02)


class _StubSD(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        body = json.dumps([{"name": "stub-model"}]).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        from PIL import Image
        buf = io.BytesIO()
        Image.new("RGB", (16, 24), (90, 40, 40)).save(buf, format="PNG")
        body = json.dumps(
            {"images": [base64.b64encode(buf.getvalue()).decode()]}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class SDClientTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = HTTPServer(("127.0.0.1", 0), _StubSD)
        cls.port = cls.server.server_address[1]
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.url = f"http://127.0.0.1:{cls.port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def test_available_against_stub(self):
        self.assertTrue(ga.sd_available(self.url, timeout=3))

    def test_unavailable_when_nothing_listens(self):
        self.assertFalse(ga.sd_available("http://127.0.0.1:9", timeout=1))

    def test_txt2img_decodes_the_image(self):
        img = ga.sd_txt2img("a pod in the mud", "blurry", 16, 24,
                            base_url=self.url, timeout=10)
        self.assertEqual(img.size, (16, 24))

    def test_builder_accepts_generated_art(self):
        import tempfile
        from PIL import Image
        art = ga.generate_art_image(500, 800, "a drop pod at dusk",
                                    genre="science fiction")
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "ebook.jpg")
            gk.build_ebook_cover(out, art_image=art, title="The Broken",
                                 author="Bob Timpone")
            with Image.open(out) as img:
                self.assertEqual(img.size, (1600, 2560))


if __name__ == "__main__":
    unittest.main()
