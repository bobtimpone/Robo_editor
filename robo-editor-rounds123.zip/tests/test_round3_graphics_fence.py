"""Round-3 regression tests for the R5 hallucination fence in
graphics_text.parse_ai_graphic_json().

The AI path must not be trusted on its own word: a quote has to be a
verbatim sentence from the source passage (whitespace-normalized),
and each bullet has to share real content words with the passage.
Fabricated material is dropped/replaced, and when nothing trustworthy
survives the built-in deterministic extractor takes over.

Self-contained, synthetic passages only, no Ollama server required:

    python -m unittest tests.test_round3_graphics_fence -v
"""
import json
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import graphics_text as gt


def _flat(s):
    return " ".join(s.split())


class FabricatedContentTests(unittest.TestCase):
    def test_exact_verified_case_fabricated_quote_and_bullet(self):
        # Exact case verified in the round-3 review.
        passage = "The cat sat. It rained all day in the valley."
        reply = json.dumps({
            "title": "T",
            "bullets": ["Invented bullet never in passage"],
            "quote": "This sentence was never written by the author at all.",
            "body": "x",
        })
        a = gt.parse_ai_graphic_json(reply, passage)
        # The fabricated quote must NOT appear: it is replaced by a
        # verbatim passage sentence (or dropped entirely).
        self.assertNotIn("never written by the author", a["quote"])
        self.assertNotEqual(
            _flat(a["quote"]),
            "This sentence was never written by the author at all.")
        if a["quote"]:
            self.assertIn(_flat(a["quote"]), _flat(passage))
        # The invented bullet must NOT survive.
        self.assertNotIn("Invented bullet never in passage", a["bullets"])
        for b in a["bullets"]:
            self.assertIn(_flat(b), _flat(passage))
        # The one-letter body is not trustworthy either.
        self.assertNotEqual(a["body"], "x")

    def test_all_fabricated_falls_back_to_builtin(self):
        passage = "The cat sat. It rained all day in the valley."
        reply = json.dumps({
            "title": "Invented Title",
            "bullets": ["Completely fabricated claim about dragons"],
            "quote": "A line the author simply never wrote down here.",
            "body": "Dragons conquered the kingdom overnight.",
        })
        a = gt.parse_ai_graphic_json(reply, passage)
        base = gt.analyze_text(passage, "Key Points Panel")
        self.assertEqual(a, base)

    def test_mixed_bullets_only_grounded_one_survives(self):
        passage = ("The cat sat by the window all morning. "
                   "It rained all day in the valley and the river rose.")
        reply = json.dumps({
            "title": "Rain",
            "bullets": [
                "It rained all day in the valley",
                "Dragons burned the harbour at midnight",
            ],
            "quote": "It rained all day in the valley and the river rose.",
            "body": "It rained in the valley.",
        })
        a = gt.parse_ai_graphic_json(reply, passage)
        self.assertIn("It rained all day in the valley", a["bullets"])
        self.assertNotIn("Dragons burned the harbour at midnight",
                         a["bullets"])


class GroundedContentTests(unittest.TestCase):
    PASSAGE = ("The cat sat by the window all morning. "
               "It rained all day in the valley and the river rose slowly.")
    QUOTE = "It rained all day in the valley and the river rose slowly."

    def test_verbatim_quote_and_grounded_bullet_survive(self):
        reply = json.dumps({
            "title": "Rain Day",
            "bullets": ["It rained all day in the valley"],
            "quote": self.QUOTE,
            "body": "It rained in the valley.",
        })
        a = gt.parse_ai_graphic_json(reply, self.PASSAGE)
        self.assertEqual(a["title"], "Rain Day")
        self.assertEqual(a["quote"], self.QUOTE)
        self.assertIn("It rained all day in the valley", a["bullets"])
        self.assertEqual(a["body"], "It rained in the valley.")

    def test_whitespace_variant_of_verbatim_quote_survives(self):
        # Comparison is whitespace-normalized: extra spaces / a line
        # break inside the quote do not make it a fabrication.
        messy = ("It rained  all day in the\nvalley and the river "
                 "rose slowly.")
        reply = json.dumps({
            "title": "Rain Day",
            "bullets": ["It rained all day in the valley"],
            "quote": messy,
            "body": "It rained in the valley.",
        })
        a = gt.parse_ai_graphic_json(reply, self.PASSAGE)
        self.assertEqual(a["quote"], self.QUOTE)

    def test_paraphrased_quote_is_replaced_by_verbatim_sentence(self):
        reply = json.dumps({
            "title": "Rain Day",
            "bullets": ["It rained all day in the valley"],
            "quote": "Rain fell in the valley while the river climbed.",
            "body": "It rained in the valley.",
        })
        a = gt.parse_ai_graphic_json(reply, self.PASSAGE)
        self.assertNotEqual(a["quote"],
                            "Rain fell in the valley while the river climbed.")
        self.assertIn(_flat(a["quote"]), _flat(self.PASSAGE))


if __name__ == "__main__":
    unittest.main()
