"""Rounds 1-3 regression tests — Round 1 (atomic saves, config
safety, close guard) and Round 2 (sanitizer restore, reasoning-strip
bound, orchestrator fallback, co-author ledger).

Self-contained like the rest of the suite: synthetic text only, no
Ollama, no real manuscripts. Run from the project root:
    python -m unittest discover -s tests -v
"""
import json
import os
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import docx

import engine as engine_module
from engine import (EditorEngine, CancelRequested, atomic_write_text,
                    atomic_save_docx, strip_reasoning_blocks,
                    update_config_file)


class FakeEngine(EditorEngine):
    """Scripted Ollama: script(call_no, system_prompt, text) -> reply."""

    def __init__(self, script):
        super().__init__()
        self.script = script
        self.calls = 0

    def call_ollama(self, model, system_prompt, text, **kw):
        self.calls += 1
        return self.script(self.calls, system_prompt, text)


def read_docx_text(path):
    return "\n".join(p.text for p in docx.Document(path).paragraphs)


# ---------------------------------------------------------------- Round 1

class AtomicWriteTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.path = os.path.join(self.tmp, "f.txt")

    def test_atomic_write_text_round_trip_and_overwrite(self):
        atomic_write_text(self.path, "first")
        atomic_write_text(self.path, "second")
        with open(self.path) as f:
            self.assertEqual(f.read(), "second")
        self.assertEqual(os.listdir(self.tmp), ["f.txt"])  # no temp litter

    def test_failed_replace_leaves_prior_file_intact(self):
        atomic_write_text(self.path, "good")
        with mock.patch.object(engine_module.os, "replace",
                               side_effect=OSError("disk gone")):
            with self.assertRaises(OSError):
                atomic_write_text(self.path, "bad")
        with open(self.path) as f:
            self.assertEqual(f.read(), "good")
        self.assertEqual(os.listdir(self.tmp), ["f.txt"])

    def test_atomic_save_docx_valid_and_failure_preserves(self):
        out = os.path.join(self.tmp, "out.docx")
        d = docx.Document()
        d.add_paragraph("hello world")
        atomic_save_docx(d, out)
        self.assertIn("hello world", read_docx_text(out))

        class BadDoc:
            def save(self, _p):
                raise OSError("boom")

        before = open(out, "rb").read()
        with self.assertRaises(OSError):
            atomic_save_docx(BadDoc(), out)
        self.assertEqual(open(out, "rb").read(), before)

    def test_save_document_overwrites_atomically(self):
        eng = EditorEngine()
        out = os.path.join(self.tmp, "book.docx")
        eng.save_document(["First version of the text."], out)
        eng.save_document(["Second version of the text."], out)
        self.assertIn("Second version", read_docx_text(out))
        self.assertEqual([f for f in os.listdir(self.tmp)
                          if f.startswith(".atomic-")], [])


class ConfigSafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.cfg = os.path.join(self.tmp, "robo_config.json")

    def test_merge_preserves_both_windows_sections(self):
        ok, _ = update_config_file(self.cfg, {"model": "m1", "chunk_size": "1500"})
        self.assertTrue(ok)
        ok, _ = update_config_file(self.cfg, {"graphics": {"trim": "6 x 9"}})
        self.assertTrue(ok)
        data = json.load(open(self.cfg))
        self.assertEqual(data["model"], "m1")
        self.assertEqual(data["graphics"]["trim"], "6 x 9")
        # Editor saves again: graphics section must survive.
        ok, _ = update_config_file(self.cfg, {"model": "m2"})
        self.assertTrue(ok)
        data = json.load(open(self.cfg))
        self.assertEqual(data["model"], "m2")
        self.assertIn("graphics", data)

    def test_corrupt_config_aborts_and_is_never_wiped(self):
        # The old Graphics Studio bug (R16c): a failed read rewrote the
        # file with only its own section. Now the save aborts and the
        # existing bytes are preserved exactly.
        with open(self.cfg, "w") as f:
            f.write("{not json")
        ok, err = update_config_file(self.cfg, {"graphics": {"trim": "6 x 9"}})
        self.assertFalse(ok)
        self.assertTrue(err)
        with open(self.cfg) as f:
            self.assertEqual(f.read(), "{not json")

    def test_non_dict_config_aborts(self):
        with open(self.cfg, "w") as f:
            f.write("[1, 2, 3]")
        ok, _ = update_config_file(self.cfg, {"model": "m"})
        self.assertFalse(ok)
        with open(self.cfg) as f:
            self.assertEqual(f.read(), "[1, 2, 3]")


class AppRound1Tests(unittest.TestCase):
    """app.py tests — skipped where customtkinter is unavailable,
    following the existing CheckpointTests pattern."""

    def _ui(self):
        try:
            import app as app_module
        except Exception:
            self.skipTest("app module unavailable (customtkinter missing)")
        ui = app_module.RoboEditorUI.__new__(app_module.RoboEditorUI)
        ui.engine = EditorEngine()
        ui.is_processing = False
        ui._close_pending = False
        ui.logs = []
        ui.log = lambda m: ui.logs.append(m)
        ui.statuses = []
        ui.set_status = lambda t: ui.statuses.append(t)
        ui.after_calls = []
        ui.after = lambda ms, cb: ui.after_calls.append(cb)
        ui.saved = []
        ui.save_config = lambda: ui.saved.append(True)
        ui.destroyed = []
        ui.destroy = lambda: ui.destroyed.append(True)
        return app_module, ui

    def test_close_when_idle_saves_and_destroys(self):
        _app, ui = self._ui()
        ui.on_closing()
        self.assertEqual(ui.saved, [True])
        self.assertEqual(ui.destroyed, [True])

    def test_close_declined_keeps_window_open(self):
        app_module, ui = self._ui()
        ui.is_processing = True
        with mock.patch.object(app_module.messagebox, "askyesno", return_value=False):
            ui.on_closing()
        self.assertEqual(ui.destroyed, [])
        self.assertFalse(ui.engine.cancel_requested)

    def test_close_confirmed_cancels_then_destroys_when_idle(self):
        app_module, ui = self._ui()
        ui.is_processing = True
        with mock.patch.object(app_module.messagebox, "askyesno", return_value=True):
            ui.on_closing()
        # Cancel requested, window NOT yet destroyed, poll scheduled.
        self.assertTrue(ui.engine.cancel_requested)
        self.assertEqual(ui.destroyed, [])
        self.assertEqual(len(ui.after_calls), 1)
        # Worker still busy: poll reschedules, no destroy.
        ui._poll_close_when_idle()
        self.assertEqual(ui.destroyed, [])
        # Worker finished: poll saves config and destroys.
        ui.is_processing = False
        ui._poll_close_when_idle()
        self.assertEqual(ui.saved, [True])
        self.assertEqual(ui.destroyed, [True])

    def test_checkpoint_json_is_complete_and_parseable(self):
        app_module, ui = self._ui()
        tmp = tempfile.mkdtemp()
        in_docx = os.path.join(tmp, "in.docx")
        d = docx.Document()
        d.add_paragraph("x")
        d.save(in_docx)
        prog = os.path.join(tmp, "t.progress.json")
        part = os.path.join(tmp, "t.partial.docx")
        ui.kdp_format_var = type("V", (), {"get": lambda s: False})()
        ui.kdp_para_style_var = type("V", (), {"get": lambda s: "indented"})()
        ui._active_settings = {"kdp_format": False, "kdp_para_style": "indented"}
        chunk = "The scope tech counted thirty-three pods over the valley."
        ui._write_edit_checkpoint(prog, part, [chunk], in_docx, 2000, 3,
                                  ["Proofread"], "light", model="m1", style_hash="h1")
        data = json.load(open(prog))  # truncated JSON would raise here
        self.assertEqual(data["chunks"], [chunk])
        self.assertTrue(os.path.exists(part))
        self.assertEqual([f for f in os.listdir(tmp) if f.startswith(".atomic-")], [])


# ---------------------------------------------------------------- Round 2

class SanitizerRestoreTests(unittest.TestCase):
    """R3: save-time sanitizer must never amputate gated/original text."""

    def setUp(self):
        self.eng = EditorEngine()
        self.tmp = tempfile.mkdtemp()
        self.out = os.path.join(self.tmp, "out.docx")
        self.logs = []

    def test_exceptions_marker_tail_survives_save(self):
        head = " ".join(f"head{i}" for i in range(60))
        tail = " ".join(f"tail{i}" for i in range(60))
        chunk = f"{head}\n---EXCEPTIONS---\n{tail}"
        self.eng.save_document([chunk], self.out, log_callback=self.logs.append)
        text = read_docx_text(self.out)
        self.assertIn("tail0", text)
        self.assertIn("tail59", text)
        self.assertTrue(any("UNSANITIZED" in m for m in self.logs))

    def test_small_chunk_total_wipe_restored(self):
        self.eng.save_document(["[paragraph deleted]"], self.out,
                               log_callback=self.logs.append)
        self.assertIn("[paragraph deleted]", read_docx_text(self.out))

    def test_small_preamble_strip_still_works(self):
        chunk = "Here is the edited text:\nReal content stays here now."
        self.eng.save_document([chunk], self.out, log_callback=self.logs.append)
        text = read_docx_text(self.out)
        self.assertIn("Real content stays here now.", text)
        self.assertNotIn("Here is the edited text", text)


class ReasoningStripBoundTests(unittest.TestCase):
    """R29: the 30% share bound on manuscript-sized inputs."""

    def test_manuscript_discussing_tags_survives(self):
        body = ("The chapter explains reasoning traces at length. " * 30)
        text = ("<think> " + body + " </think>\n"
                + "The lesson continues in the author's own words. " * 5)
        self.assertEqual(strip_reasoning_blocks(text), text)

    def test_small_reply_still_strips(self):
        self.assertEqual(
            strip_reasoning_blocks("<think>reasoning</think>Clean text."),
            "Clean text.")

    def test_manuscript_sized_small_block_still_strips(self):
        text = ("Real manuscript content fills this chunk with prose. " * 20
                + "<think>short trace</think>")
        out = strip_reasoning_blocks(text)
        self.assertNotIn("<think>", out)
        self.assertIn("Real manuscript content", out)


class OrchestratorFallbackTests(unittest.TestCase):
    """R7 + R6."""

    PROSE = ("The contact came in at 0244, thirty-three minutes before "
             "the drone. The scope tech caught it on the long array.")

    def test_ollama_exception_falls_back_and_continues(self):
        from orchestrator import AgentPipelineOrchestrator

        def boom(n, sp, t):
            raise RuntimeError("Ollama unreachable")

        orch = AgentPipelineOrchestrator(FakeEngine(boom), "mock")
        out = orch.process_chunk(self.PROSE, "Proofread", skip_llm_audit=True,
                                 log_callback=lambda m: None,
                                 proofread_level="light")
        self.assertEqual(out, self.PROSE)

    def test_cancel_still_propagates(self):
        from orchestrator import AgentPipelineOrchestrator

        def cancelling(n, sp, t):
            raise CancelRequested("Processing cancelled by user.")

        orch = AgentPipelineOrchestrator(FakeEngine(cancelling), "mock")
        with self.assertRaises(CancelRequested):
            orch.process_chunk(self.PROSE, "Proofread", skip_llm_audit=True,
                               log_callback=lambda m: None,
                               proofread_level="light")

    def test_coauthor_ledger_initialised_and_resume_first_call(self):
        from orchestrator import AgentPipelineOrchestrator
        clean = ("The fleet held the line at dawn while the crews "
                 "counted shells in grey light. " * 3)
        orch = AgentPipelineOrchestrator(FakeEngine(lambda n, sp, t: clean), "mock")
        self.assertEqual(orch._ledger, "")
        # First call with sequence_id != 1 raised AttributeError before R6.
        out = orch.generate_new_content(
            "topic", "Novelist", 40, sequence_id=3,
            previous_chunk="An earlier block of the story.",
            log_callback=lambda m: None, skip_llm_audit=True)
        self.assertTrue(out)


if __name__ == "__main__":
    unittest.main()
