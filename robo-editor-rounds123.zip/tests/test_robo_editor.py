"""Robo-Editor regression tests.

Self-contained: synthetic texts and generated documents only — no
Ollama server and no real manuscripts required. Run from the project
root:

    python -m unittest discover -s tests -v

These encode the failures the pipeline actually produced across
rounds 13–16 (mutated numbers, renamed characters, swapped terms,
vanishing 'Note:' passages, fused headings, blind corrections), so a
future change that reopens one of those holes fails loudly here
instead of in a book.
"""
import json
import os
import struct
import sys
import unittest
import zlib
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import docx

import engine as engine_module
from engine import EditorEngine
from agents.watchtower_agent import WatchTowerAgent
from agents.scribe_agent import ScribeAgent


PROSE = (
    "The contact came in at 0244, thirty-three minutes before the drone. "
    "The scope tech caught it on the long array, a smear, then a shape, "
    "then a count she ran three times. She called it up without taking "
    "her eyes off the board. “Eighteen months to cluster-frames. Less, "
    "if they find the belt.” The scope tech didn’t look up."
)


class FakeEngine(EditorEngine):
    """Scripted Ollama: script(call_no, system_prompt, text) -> reply."""
    def __init__(self, script):
        super().__init__()
        self.script = script
        self.calls = 0

    def call_ollama(self, model, system_prompt, text, **kw):
        self.calls += 1
        return self.script(self.calls, system_prompt, text)


class SanitizerTests(unittest.TestCase):
    def setUp(self):
        self.eng = EditorEngine()

    def test_note_passages_survive(self):
        # The round-15 bug: a back-half "Note:" line amputated the rest
        # of the chunk at save time (1,568 words lost on a real book).
        text = ("Body text comes first and carries the argument forward.\n\n"
                "Note 1: \"Make Mara exhausted, sharp-tongued, done with "
                "everybody's nonsense.\"\n\n"
                "That was the light bulb. It was being obedient.")
        self.assertEqual(self.eng._sanitize_output(text), text)

    def test_artifacts_stripped_placeholders_kept(self):
        text = ("Real text.\n\n<!-- est. words cut: 734 -->\n\n"
                "[paragraphs deleted]\n\n[DEDICATION: Bob to supply]\n\nMore text.")
        out = self.eng._sanitize_output(text)
        self.assertNotIn("<!--", out)
        self.assertNotIn("paragraphs deleted", out)
        self.assertIn("[DEDICATION: Bob to supply]", out)
        self.assertIn("More text.", out)

    def test_think_blocks_stripped(self):
        out = self.eng._sanitize_output("<think>reasoning</think>Clean text.")
        self.assertEqual(out, "Clean text.")


class GateTests(unittest.TestCase):
    def setUp(self):
        self.wt = WatchTowerAgent(None, "mock")

    def test_number_mutation_rejected(self):
        ok, _ = self.wt._check_content_invariance(
            PROSE, PROSE.replace("thirty-three", "fifty-three"), "Proofread")
        self.assertFalse(ok)

    def test_name_swap_rejected(self):
        o = "“You’re dropping your elbow, Corb.” Corb didn’t look up. Corb fletched the shaft."
        ok, _ = self.wt._check_content_invariance(o, o.replace("Corb", "Joss"), "Proofread")
        self.assertFalse(ok)

    def test_foreign_name_rejected(self):
        o = "The scope tech caught it on the long array and called it up to the bridge."
        e = "Scope tech Voss caught it on the long array and called it up to the bridge."
        ok, _ = self.wt._check_content_invariance(o, e, "Proofread")
        self.assertFalse(ok)

    def test_possessive_name_not_foreign(self):
        o = "Danth’s sky was clear for the first time in months. The fleet held."
        e = "Danth’s sky was clear for the first time in months. Danth held the fleet."
        ok, _ = self.wt._check_content_invariance(o, e, "Proofread")
        self.assertTrue(ok)

    def test_term_swap_rejected(self):
        o = "The fragment-pods burned in over the far valleys at dawn."
        ok, _ = self.wt._check_content_invariance(
            o, o.replace("fragment-pods", "fragment-vessels"), "Proofread")
        self.assertFalse(ok)

    def test_straight_quotes_rejected(self):
        o = "“Don’t varn it,” Sarge said. “That’s the job.”"
        e = "\"Don't varn it,\" Sarge said. \"That's the job.\""
        ok, _ = self.wt._check_quote_style(o, e, "Proofread")
        self.assertFalse(ok)

    def test_dropped_opening_quote_rejected(self):
        o = "“It was already torn,” Tavo said. “I saw him at the well.”"
        e = "It was already torn,” Tavo said. “I saw him at the well.”"
        ok, _ = self.wt._check_quote_style(o, e, "Proofread")
        self.assertFalse(ok)

    def test_artifacts_rejected(self):
        ok, _ = self.wt._check_no_editor_artifacts(PROSE, PROSE + "\n\n[paragraphs deleted]", "Proofread")
        self.assertFalse(ok)
        ok, _ = self.wt._check_no_editor_artifacts(PROSE, PROSE + "\n\n<!-- tally -->", "Proofread")
        self.assertFalse(ok)

    def test_clean_chunk_passes_everything(self):
        ok, msg = self.wt.inspect_chunk(PROSE, PROSE, "Proofread", skip_llm_audit=True)
        self.assertTrue(ok, msg)

    def test_legit_proofread_fix_passes(self):
        o = "The bead gave a warning whine, it did that when it detected raised voices nearby."
        e = "The bead gave a warning whine; it did that when it detected raised voices nearby."
        ok, msg = self.wt.inspect_chunk(o, e, "Proofread", skip_llm_audit=True)
        self.assertTrue(ok, msg)

    def test_drift_still_rejects_gutting(self):
        ok, _ = self.wt.differential_audit(PROSE, "The contact came in.", stage="Proofread", drift_limit=0.02)
        self.assertFalse(ok)

    def test_banned_vocabulary_is_delta(self):
        # The author's own listed word is his to keep...
        ok, _ = self.wt.check_banned_vocabulary_deterministic(
            "The beacon burned all night.", "The beacon burned all night.")
        self.assertTrue(ok)
        # ...but an edit may not introduce one.
        ok, _ = self.wt.check_banned_vocabulary_deterministic(
            "The light burned all night.", "The robust light burned all night.")
        self.assertFalse(ok)

    def test_validate_chunk_is_the_inspect_chain(self):
        mutated = PROSE.replace("thirty-three", "fifty-three")
        ok_v, _ = self.wt.validate_chunk(PROSE, mutated, "Proofread", drift_limit=0.02)
        ok_i, _ = self.wt.inspect_chunk(PROSE, mutated, "Proofread", skip_llm_audit=True, drift_limit=0.02)
        self.assertFalse(ok_v)
        self.assertEqual(ok_v, ok_i)

    def test_human_score_is_advisory_only(self):
        # Uniform sentence lengths across paragraphs -> cadence variance
        # ~0, plus a banned opening: the old gate REJECTED this; now it
        # must approve and merely record a warning.
        paras = [
            "As an AI the cat sat. The dog ran fast. The bird flew high.",
            "The grey wolf stood watch. The cold wind blew hard. The snow fell soft.",
            "The old ship creaked loud. The torn sail flapped wild. The dark sea rolled deep.",
            "The young guard paced slow. The iron gate stayed shut. The long night wore on.",
        ]
        flat = "\n\n".join(paras)
        ok, _ = self.wt.inspect_chunk(flat, flat, "Proofread", skip_llm_audit=True)
        self.assertTrue(ok)
        self.assertTrue(self.wt.pop_warnings())


class AuditBehaviorTests(unittest.TestCase):
    def test_cosmetic_edit_skips_llm_audit(self):
        class Exploding:
            def call_ollama(self, **kw):
                raise AssertionError("audit should not be called")
        wt = WatchTowerAgent(Exploding(), "mock")
        ok, _ = wt.inspect_chunk(PROSE, PROSE, "Proofread", skip_llm_audit=False)
        self.assertTrue(ok)
        ok, _ = wt.inspect_chunk(PROSE, PROSE.replace("array, a smear", "array. A smear"),
                                 "Proofread", skip_llm_audit=False)
        self.assertTrue(ok)

    def test_audit_temperature_zero_and_neutral(self):
        captured = {}

        class Capture(EditorEngine):
            def call_ollama(self, model, system_prompt, text, **kw):
                captured.update(kw)
                captured["prompt"] = system_prompt
                return "STATUS: APPROVED"

        wt = WatchTowerAgent(Capture(), "mock")
        edited = PROSE.replace("ran three times", "ran three times slowly")
        ok, _ = wt.inspect_chunk(PROSE, edited, "Proofread", skip_llm_audit=False)
        self.assertTrue(ok)
        self.assertEqual(captured.get("temperature"), 0.0)
        self.assertNotIn("Ruthless", captured["prompt"])


class EngineTests(unittest.TestCase):
    def test_think_off_payload(self):
        captured = {}

        class FakeResp:
            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False

            def __iter__(self):
                yield json.dumps({"response": "hi there", "done": True}).encode()

        def fake_urlopen(req, timeout=None):
            captured["payload"] = json.loads(req.data.decode())
            return FakeResp()

        eng = EditorEngine()
        eng.think_off = True
        with mock.patch.object(engine_module.urllib.request, "urlopen", fake_urlopen):
            eng.call_ollama("m", "sys", "text", is_edit_pass=False)
        self.assertIs(captured["payload"].get("think"), False)

        eng2 = EditorEngine()
        with mock.patch.object(engine_module.urllib.request, "urlopen", fake_urlopen):
            eng2.call_ollama("m", "sys", "text", is_edit_pass=False)
        self.assertNotIn("think", captured["payload"])

    def test_truncation_ends_at_sentence(self):
        text = "One two three four. Five six seven eight nine ten eleven twelve. Thirteen fourteen."
        out = EditorEngine._truncate_at_sentence(text, 12)
        self.assertTrue(out.endswith("twelve."))
        self.assertLessEqual(len(out.split()), 12)


def _tiny_png():
    def ch(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n"
            + ch(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0))
            + ch(b"IDAT", zlib.compress(b"\x00\xff\x00\x00"))
            + ch(b"IEND", b""))


class RoundTripTests(unittest.TestCase):
    def test_two_line_heading_round_trips(self):
        import tempfile
        tmp = tempfile.mkdtemp()
        src = os.path.join(tmp, "in.docx")
        out = os.path.join(tmp, "out.docx")
        d = docx.Document()
        h = d.add_heading(level=1)
        r1 = h.add_run("CHAPTER 1")
        r1.add_break()
        h.add_run("The Arithmetic")
        d.add_paragraph("The scope tech counted thirty-three pods over the valley.")
        p = d.add_paragraph()
        png_path = os.path.join(tmp, "dot.png")
        with open(png_path, "wb") as f:
            f.write(_tiny_png())
        p.add_run().add_picture(png_path)
        d.save(src)

        eng = EditorEngine()
        chunks = eng.load_and_chunk(src, max_tokens_per_chunk=2000)
        self.assertEqual(eng._input_image_count, 1)
        eng.save_document(chunks, out, kdp_format=True, known_headings=eng._source_headings)

        b, n = docx.Document(src), docx.Document(out)
        bw = sum(len(p.text.split()) for p in b.paragraphs)
        nw = sum(len(p.text.split()) for p in n.paragraphs)
        self.assertEqual(bw, nw)
        bh = [(p.style.name, p.text) for p in b.paragraphs if p.style.name.startswith("Heading")]
        nh = [(p.style.name, p.text) for p in n.paragraphs if p.style.name.startswith("Heading")]
        self.assertEqual(bh, nh)


class OrchestratorTests(unittest.TestCase):
    def test_mutation_falls_back_to_original(self):
        from orchestrator import AgentPipelineOrchestrator
        eng = FakeEngine(lambda n, sp, t: PROSE.replace("thirty-three", "fifty-three"))
        orch = AgentPipelineOrchestrator(eng, "mock")
        out = orch.process_chunk(PROSE, "Proofread", skip_llm_audit=True,
                                 log_callback=lambda m: None, proofread_level="light")
        self.assertEqual(out, PROSE)

    def test_coauthor_correction_is_audited(self):
        from orchestrator import AgentPipelineOrchestrator
        bad = "This block delves into the tapestry of war and the robust fleet held on. " * 3
        clean = "The fleet held the line at dawn while the crews counted shells in grey light. " * 3

        def script(correct_result):
            def run(n, sp, t):
                if "WATCHTOWER FEEDBACK" in sp:
                    return correct_result
                return bad
            return run

        orch = AgentPipelineOrchestrator(FakeEngine(script(bad)), "mock")
        out = orch.generate_new_content("topic", "Novelist", 40, sequence_id=1,
                                        log_callback=lambda m: None, skip_llm_audit=True)
        self.assertEqual(out, "")

        orch = AgentPipelineOrchestrator(FakeEngine(script(clean)), "mock")
        out = orch.generate_new_content("topic", "Novelist", 40, sequence_id=1,
                                        log_callback=lambda m: None, skip_llm_audit=True)
        self.assertEqual(out, clean.strip())


class KeeperTests(unittest.TestCase):
    def test_ledger_not_sanitized(self):
        from agents.keeper_agent import KeeperAgent
        reply = "- Mara holds the pass.\n- no content provided in the west report."
        kp = KeeperAgent(FakeEngine(lambda n, sp, t: reply), "mock")
        out = kp.summarize_state("New event.", previous_summary="")
        self.assertIn("no content provided", out)

    def test_ledger_cap_compresses(self):
        from agents.keeper_agent import KeeperAgent
        eng = FakeEngine(lambda n, sp, t: "COMPRESSED")
        kp = KeeperAgent(eng, "mock")
        big = " ".join(f"fact{i}" for i in range(2100))
        kp.summarize_state("New event.", previous_summary=big)
        self.assertGreaterEqual(eng.calls, 2)  # compression + fold


class CheckpointTests(unittest.TestCase):
    def test_fingerprint_and_multistage_revalidation(self):
        try:
            import app as app_module
        except Exception:
            self.skipTest("app module unavailable (customtkinter missing)")

        class Var:
            def __init__(self, v):
                self._v = v

            def get(self):
                return self._v

        import tempfile
        tmp = tempfile.mkdtemp()
        in_docx = os.path.join(tmp, "in.docx")
        d = docx.Document()
        d.add_paragraph("x")
        d.save(in_docx)
        prog = os.path.join(tmp, "t.progress.json")
        part = os.path.join(tmp, "t.partial.docx")

        ui = app_module.RoboEditorUI.__new__(app_module.RoboEditorUI)
        ui.engine = EditorEngine()
        ui.logs = []
        ui.log = lambda m: ui.logs.append(m)
        ui.model_var = Var("m1")
        ui.kdp_format_var = Var(False)
        ui.kdp_para_style_var = Var("indented")
        ui._active_settings = {"kdp_format": False, "kdp_para_style": "indented"}

        good = "The scope tech counted thirty-three pods over the valley at dawn and logged them all."
        bad = good.replace("thirty-three", "fifty-three")
        sources = [good, good, good]

        ui._write_edit_checkpoint(prog, part, [good, good], in_docx, 2000, 3,
                                  ["Proofread"], "light", model="m1", style_hash="h1")
        ec = []
        n = ui._load_edit_checkpoint(prog, in_docx, 2000, 3, ["Proofread"], "light",
                                     ec, source_chunks=sources, model="m2", style_hash="h1")
        self.assertEqual(n, 0)  # model changed -> fresh start

        ui._write_edit_checkpoint(prog, part, [good, bad], in_docx, 2000, 3,
                                  ["Line Edit", "Proofread"], "light", model="m1", style_hash="h1")
        ec = []
        n = ui._load_edit_checkpoint(prog, in_docx, 2000, 3, ["Line Edit", "Proofread"],
                                     "light", ec, source_chunks=sources, model="m1", style_hash="h1")
        self.assertEqual(n, 1)  # multi-stage revalidation truncates at the mutation


class ScribePromptTests(unittest.TestCase):
    def test_prompts_carry_shared_vocabulary(self):
        from agents.vocab import BANNED_TERMS
        scribe = ScribeAgent(None, "mock")
        prompt = scribe._get_mechanical_prompt()
        for term in ("delve", "robust", "crucial"):
            self.assertIn(term, prompt)
        self.assertIn("semicolon in place of a comma", prompt)
        self.assertTrue(set(BANNED_TERMS))


if __name__ == "__main__":
    unittest.main()
