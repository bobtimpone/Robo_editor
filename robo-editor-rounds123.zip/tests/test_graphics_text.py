"""Text-to-Graphic tests.

Self-contained: synthetic passages only, no Ollama server required
(the one AI-path test only checks the no-model guard, which never
touches the network). Run from the project root:

    python -m unittest discover -s tests -v
"""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import graphics_kdp as gk
import graphics_text as gt

PASSAGE = """The Night the Pods Fell

The first pod hit the north field just after supper, and the whole valley heard it ring against the frozen ground. Mara counted eleven lights in the sky before the second one fell beyond the ridge. The Broken came down from the ridge road at a run, their nanites already knitting the cuts from the climb.

Nobody in the valley had ever seen a fragment pod land so close to the houses. The elders said the war stayed in orbit, where it belonged, and the children believed them because children always do. By midnight the field was cordoned, the lanterns were lit, and Sarge was writing names in a notebook with a stub of pencil.

"We hold the field until the relief column arrives," Sarge said, "and then we hold it some more." It was not a speech. It was just the arithmetic of the place, the way the valley had always done its sums."""


def _flat(s):
    return " ".join(s.split())


class AnalysisTests(unittest.TestCase):
    def test_heading_becomes_title(self):
        a = gt.analyze_text(PASSAGE, "Key Points Panel")
        self.assertEqual(a["title"], "The Night the Pods Fell")

    def test_bullets_and_quote_come_from_the_text(self):
        a = gt.analyze_text(PASSAGE, "Key Points Panel")
        self.assertGreaterEqual(len(a["bullets"]), 3)
        for b in a["bullets"]:
            self.assertIn(_flat(b), _flat(PASSAGE))
        self.assertIn(_flat(a["quote"]), _flat(PASSAGE))

    def test_timeline_prefers_dated_ordered_sentences(self):
        text = ("In 2140 the first beacon lit. Then the fleet assembled "
                "above the yard. Workers loaded forty tons of grain in "
                "the spring of 2141. Finally, the ark cast off and the "
                "radios went quiet.")
        a = gt.analyze_text(text, "Timeline")
        self.assertGreaterEqual(len(a["bullets"]), 3)
        self.assertTrue(a["bullets"][0].startswith("In 2140"))

    def test_empty_text_raises(self):
        with self.assertRaises(ValueError):
            gt.analyze_text("   ", "Key Points Panel")


class ContextTests(unittest.TestCase):
    def test_find_context_with_neighbors(self):
        ctx = gt.find_text_context(PASSAGE, "nanites", neighbors=1)
        self.assertIn("nanites", ctx)
        self.assertIn("The Night the Pods Fell", ctx)  # paragraph before

    def test_find_context_missing_raises(self):
        with self.assertRaises(ValueError):
            gt.find_text_context(PASSAGE, "starship Enterprise")

    def test_find_context_needs_query(self):
        with self.assertRaises(ValueError):
            gt.find_text_context(PASSAGE, "  ")


class FileTests(unittest.TestCase):
    def test_docx_round_trip(self):
        import docx
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "chapter.docx")
            doc = docx.Document()
            doc.add_paragraph("Chapter One")
            doc.add_paragraph("The pods fell early that year.")
            doc.save(p)
            text = gt.extract_text_from_file(p)
        self.assertIn("Chapter One", text)
        self.assertIn("pods fell early", text)

    def test_txt_round_trip(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "note.txt")
            with open(p, "w", encoding="utf-8") as f:
                f.write("A small note about spines.")
            self.assertIn("spines", gt.extract_text_from_file(p))

    def test_unsupported_type_raises(self):
        with self.assertRaises(ValueError):
            gt.extract_text_from_file("cover.psd")


class AIParseTests(unittest.TestCase):
    def test_fenced_json_is_sanitized(self):
        # R5 fence: the quote must be a verbatim sentence from PASSAGE
        # and the bullets must be grounded in its words, so the fixture
        # uses a real passage sentence and passage-grounded bullets.
        reply = ('Here you go:\n```json\n{"title": "Pods Fell", '
                 '"bullets": ["The first pod hit the north field just '
                 'after supper.", "Mara counted eleven lights in the '
                 'sky.", "Sarge was writing names in a notebook."], '
                 '"quote": "It was just the arithmetic of the place, '
                 'the way the valley had always done its sums.", '
                 '"body": "A valley meets the war."}\n```')
        a = gt.parse_ai_graphic_json(reply, PASSAGE)
        self.assertEqual(a["title"], "Pods Fell")
        self.assertEqual(len(a["bullets"]), 3)
        self.assertIn("arithmetic of the place", a["quote"])

    def test_garbage_falls_back_to_builtin(self):
        a = gt.parse_ai_graphic_json("no json here at all", PASSAGE)
        self.assertEqual(a["title"], "The Night the Pods Fell")

    def test_ai_requires_a_model(self):
        with self.assertRaises(RuntimeError):
            gt.ai_analyze_text(PASSAGE, "http://localhost:11434", "")


@unittest.skipUnless(gk.HAS_PIL, "Pillow not installed")
class RenderTests(unittest.TestCase):
    def test_render_full_width_light(self):
        from PIL import Image
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "panel.png")
            a = gt.analyze_text(PASSAGE, "Key Points Panel", "chapter-09.txt")
            gt.render_text_graphic(out, a, width_px=1425)
            with Image.open(out) as img:
                self.assertEqual(img.width, 1425)
                self.assertGreater(img.height, 500)
                dpi = img.info.get("dpi", (0, 0))
                self.assertAlmostEqual(dpi[0], 300, delta=1.5)

    def test_render_quote_card_dark_half_width(self):
        from PIL import Image
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "quote.png")
            a = gt.analyze_text(PASSAGE, "Pull-Quote Card")
            gt.render_text_graphic(out, a, width_px=712, dark=True)
            with Image.open(out) as img:
                self.assertEqual(img.width, 712)


if __name__ == "__main__":
    unittest.main()
