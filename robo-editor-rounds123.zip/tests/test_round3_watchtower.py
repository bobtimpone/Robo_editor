"""Round 3 WatchTower regression tests (R12, R13a, R13b, R22, R23).

Self-contained synthetic texts only — no Ollama, no manuscripts.
Run from the project root:

    python -m unittest discover -s tests -v
"""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.watchtower_agent import WatchTowerAgent


class BannedCountTests(unittest.TestCase):
    """R12: banned-word check is count-based with word boundaries."""

    def setUp(self):
        self.wt = WatchTowerAgent(None, "mock")

    def test_banned_count_up_rejected(self):
        ok, _ = self.wt.check_banned_vocabulary_deterministic(
            "The robust light burned all night.",
            "The robust, robust light burned all night.")
        self.assertFalse(ok)

    def test_banned_introduced_from_zero_rejected(self):
        ok, _ = self.wt.check_banned_vocabulary_deterministic(
            "The light burned all night.",
            "The robust light burned all night.")
        self.assertFalse(ok)

    def test_banned_same_count_passes(self):
        ok, msg = self.wt.check_banned_vocabulary_deterministic(
            "The robust light burned all night.",
            "All night the robust light burned.")
        self.assertTrue(ok, msg)

    def test_banned_substring_does_not_fire(self):
        # 'highlighter' contains 'highlight' as a substring only.
        ok, msg = self.wt.check_banned_vocabulary_deterministic(
            "The pen sat on the desk by the lamp.",
            "The highlighter sat on the desk by the lamp.")
        self.assertTrue(ok, msg)

    def test_banned_multiword_phrase_count_up_rejected(self):
        ok, _ = self.wt.check_banned_vocabulary_deterministic(
            "He paused, a reminder that the gate was shut.",
            "He paused, a reminder that the gate was shut, "
            "a reminder that the road was long.")
        self.assertFalse(ok)


class DuplicatePreservationTests(unittest.TestCase):
    """R13a: heading / short-line preservation uses Counter multisets."""

    def setUp(self):
        self.wt = WatchTowerAgent(None, "mock")

    def test_duplicate_heading_drop_caught(self):
        orig = ("# Chapter One\n\nBody text for the first part here.\n\n"
                "# Chapter One\n\nBody text for the second part here.")
        edited = "# Chapter One\n\nBody text for the first part here.\n\nBody text for the second part here."
        ok, _ = self.wt._check_headings_preserved(orig, edited, "Proofread")
        self.assertFalse(ok)

    def test_duplicate_headings_kept_pass(self):
        orig = ("# Chapter One\n\nBody text for the first part here.\n\n"
                "# Chapter One\n\nBody text for the second part here.")
        ok, msg = self.wt._check_headings_preserved(orig, orig, "Proofread")
        self.assertTrue(ok, msg)

    LABEL = "Figure 1: The Bowl on the bench"
    BODY1 = "The crew waited beside the gate for the signal to move forward."
    BODY2 = "The crew waited beside the gate for the signal to move onward."

    def test_duplicate_short_line_drop_caught(self):
        orig = f"{self.LABEL}\n\n{self.BODY1}\n\n{self.LABEL}\n\n{self.BODY2}"
        edited = f"{self.LABEL}\n\n{self.BODY1}\n\n{self.BODY2}"
        ok, _ = self.wt._check_short_lines_preserved(orig, edited, "Proofread")
        self.assertFalse(ok)

    def test_duplicate_short_lines_kept_pass(self):
        orig = f"{self.LABEL}\n\n{self.BODY1}\n\n{self.LABEL}\n\n{self.BODY2}"
        ok, msg = self.wt._check_short_lines_preserved(orig, orig, "Proofread")
        self.assertTrue(ok, msg)


class SentenceInitialNameTests(unittest.TestCase):
    """R13b: a single sentence-initial name may not be swapped out."""

    def setUp(self):
        self.wt = WatchTowerAgent(None, "mock")

    def test_mira_to_joss_caught(self):
        ok, msg = self.wt._check_content_invariance(
            "Mira stood.", "Joss stood.", "Proofread")
        self.assertFalse(ok, msg)

    def test_single_initial_name_kept_passes(self):
        ok, msg = self.wt._check_content_invariance(
            "Mira stood.", "Mira stood still.", "Proofread")
        self.assertTrue(ok, msg)

    def test_existing_name_used_once_more_passes(self):
        # The conservative asymmetry R13b is tuned for: an existing
        # (possessive) name gaining one plain use is a legit edit,
        # mirroring GateTests.test_possessive_name_not_foreign.
        o = "Danth\u2019s sky was clear for the first time in months. The fleet held."
        e = "Danth\u2019s sky was clear for the first time in months. Danth held the fleet."
        ok, msg = self.wt._check_content_invariance(o, e, "Proofread")
        self.assertTrue(ok, msg)

    def test_common_sentence_starter_change_passes(self):
        o = "However, the fleet held the pass through the long night."
        e = "But the fleet held the pass through the long night."
        ok, msg = self.wt._check_content_invariance(o, e, "Proofread")
        self.assertTrue(ok, msg)


class StageBindingTests(unittest.TestCase):
    """R22: Combined/Developmental/unknown stages are rewrite-bound;
    only the recognised generation stage (Co-Author) is unbound."""

    def setUp(self):
        self.wt = WatchTowerAgent(None, "mock")
        self.orig = "The crew counted thirty-three pods at dawn."
        self.mutated = self.orig.replace("thirty-three", "fifty-three")

    def test_combined_edit_still_catches_number_change(self):
        ok, _ = self.wt._check_content_invariance(
            self.orig, self.mutated, "Combined Edit")
        self.assertFalse(ok)

    def test_developmental_edit_still_catches_number_change(self):
        ok, _ = self.wt._check_content_invariance(
            self.orig, self.mutated, "Developmental Edit")
        self.assertFalse(ok)

    def test_unknown_stage_still_catches_number_change(self):
        ok, _ = self.wt._check_content_invariance(
            self.orig, self.mutated, "Totally Unknown Stage")
        self.assertFalse(ok)

    def test_unknown_stage_still_catches_quote_change(self):
        o = "\u201cDon\u2019t varn it,\u201d Sarge said. \u201cThat\u2019s the job.\u201d"
        e = "\"Don't varn it,\" Sarge said. \"That's the job.\""
        ok, _ = self.wt._check_quote_style(o, e, "Totally Unknown Stage")
        self.assertFalse(ok)

    def test_combined_edit_still_catches_short_line_drop(self):
        orig = "Figure 1: The Bowl on the bench\n\nThe crew waited beside the gate for the signal to move forward."
        edited = "The crew waited beside the gate for the signal to move forward."
        ok, _ = self.wt._check_short_lines_preserved(orig, edited, "Combined Edit")
        self.assertFalse(ok)

    def test_coauthor_generation_remains_unbound(self):
        # Genuinely unbound case defined by the existing code: a
        # generation stage has no source text to preserve.
        ok, msg = self.wt._check_content_invariance(
            self.orig, self.mutated, "Co-Author Generation")
        self.assertTrue(ok, msg)


class CosmeticOnlyTests(unittest.TestCase):
    """R23: emphasis stripping and word joining are NOT cosmetic."""

    def setUp(self):
        self.wt = WatchTowerAgent(None, "mock")

    def test_bold_stripping_is_not_cosmetic(self):
        self.assertFalse(self.wt._is_cosmetic_only(
            "The **scope tech** caught the signal at dawn.",
            "The scope tech caught the signal at dawn."))

    def test_italic_stripping_is_not_cosmetic(self):
        self.assertFalse(self.wt._is_cosmetic_only(
            "The *scope tech* caught the signal at dawn.",
            "The scope tech caught the signal at dawn."))

    def test_word_join_is_not_cosmetic(self):
        self.assertFalse(self.wt._is_cosmetic_only(
            "The pass was well known to the crew at dawn.",
            "The pass was wellknown to the crew at dawn."))

    def test_hyphen_join_removal_is_not_cosmetic(self):
        self.assertFalse(self.wt._is_cosmetic_only(
            "The pass was well-known to the crew at dawn.",
            "The pass was wellknown to the crew at dawn."))

    def test_truly_cosmetic_punctuation_edit_is_cosmetic(self):
        self.assertTrue(self.wt._is_cosmetic_only(
            "The bead gave a warning whine, it did that when it detected raised voices nearby.",
            "The bead gave a warning whine; it did that when it detected raised voices nearby."))

    def test_unchanged_text_is_cosmetic(self):
        text = "The bead gave a warning whine, it did that at dawn."
        self.assertTrue(self.wt._is_cosmetic_only(text, text))

    def test_bold_stripping_reaches_llm_audit(self):
        calls = []

        class Capture:
            def call_ollama(self, **kw):
                calls.append(kw)
                return "STATUS: APPROVED"

        wt = WatchTowerAgent(Capture(), "mock")
        orig = "The **scope tech** caught it on the long array and called it up."
        edited = "The scope tech caught it on the long array and called it up."
        ok, msg = wt.inspect_chunk(orig, edited, "Proofread", skip_llm_audit=False)
        self.assertTrue(ok, msg)
        self.assertEqual(len(calls), 1)


if __name__ == "__main__":
    unittest.main()
