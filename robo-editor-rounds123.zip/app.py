import customtkinter as ctk
from tkinter import filedialog, messagebox
import threading
import os
import json
import re
import hashlib
import urllib.request

import docx

from engine import (EditorEngine, CancelRequested, atomic_write_text,
                    update_config_file)
from orchestrator import AgentPipelineOrchestrator
from agents.watchtower_agent import WatchTowerAgent
from agents.vocab import (EDIT_STAGES, REWRITE_BOUND_STAGES,
                          STAGE_COMBINED, STAGE_DEVELOPMENTAL, STAGE_PROOFREAD)

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")
# Anchor the config to the script's directory, not the launch CWD.
APP_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(APP_DIR, "robo_config.json")

class RoboEditorUI(ctk.CTk):
    # Checkpoint format marker. Bump whenever a fix changes what stored
    # chunks can be trusted to contain; checkpoints written by older
    # builds are then discarded (fresh start) instead of resumed.
    CHECKPOINT_SCHEMA = 2

    def __init__(self):
        super().__init__()
        self.title("Robo-Editor: Multi-Agent Pipeline & Co-Author")
        # Fit the window to the screen instead of assuming a tall monitor.
        # The settings panels scroll if they don't fit (see setup_ui);
        # the Run controls, status, and log stay pinned and visible.
        _sw = self.winfo_screenwidth()
        _sh = self.winfo_screenheight()
        _w = min(850, _sw - 40)
        _h = min(950, _sh - 80)
        self.geometry(f"{_w}x{_h}+{max(0, (_sw - _w) // 2)}+{max(0, (_sh - _h) // 3)}")
        self.minsize(700, 520)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.engine = EditorEngine()
        self.is_processing = False
        self._close_pending = False  # R2 close guard: waiting for a run to stop
        # (Round 16, S13: the app's own ollama_url copy is gone — the
        # engine owns the URL; fetch_models reads it from there, so the
        # two can never diverge.)

        self.setup_variables()
        self.setup_ui()
        self.load_config()
        self.fetch_models()
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

    # --- Thread-Safe UI Helpers ---
    def log(self, message):
        if threading.current_thread() is threading.main_thread():
            self.log_area.insert("end", f"{message}\n")
            self.log_area.see("end")
        else:
            self.after(0, lambda: self.log(message))

    def set_status(self, text):
        if threading.current_thread() is threading.main_thread():
            self.status_label.configure(text=text)
        else:
            self.after(0, lambda: self.set_status(text))

    def set_progress(self, val):
        if threading.current_thread() is threading.main_thread():
            self.progress_bar.set(val)
        else:
            self.after(0, lambda: self.set_progress(val))

    def show_info(self, title, message):
        if threading.current_thread() is threading.main_thread():
            messagebox.showinfo(title, message)
        else:
            self.after(0, lambda: self.show_info(title, message))

    def show_error(self, title, message):
        if threading.current_thread() is threading.main_thread():
            messagebox.showerror(title, message)
        else:
            self.after(0, lambda: self.show_error(title, message))

    def update_model_dropdown(self, models, error=False):
        if not threading.current_thread() is threading.main_thread():
            self.after(0, lambda: self.update_model_dropdown(models, error))
            return

        self.model_dropdown.configure(values=models)
        if error:
            self.model_var.set(models[0])
        elif models and hasattr(self, 'saved_model') and self.saved_model in models:
            self.model_var.set(self.saved_model)
        elif models:
            self.model_var.set(models[0])

    def reset_ui_state(self, mode="ready"):
        if not threading.current_thread() is threading.main_thread():
            self.after(0, lambda: self.reset_ui_state(mode))
            return

        self.is_processing = False
        if mode == "ready":
            self.start_btn.configure(state="normal", text="Run Editing Pipeline")
            self.stop_btn.configure(state="disabled", text="Stop/Cancel")
            self.set_status("Ready.")
            self.progress_bar.set(0)

    # --- Setup & Config ---
    def setup_variables(self):
        self.input_var = ctk.StringVar()
        self.output_var = ctk.StringVar()
        self.bible_var = ctk.StringVar()
        self.model_var = ctk.StringVar()
        self.chunk_size_var = ctk.StringVar(value="1500")
        self.context_size_var = ctk.StringVar(value="4096")
        self.genre_var = ctk.StringVar(value="None")
        self.voice_var = ctk.StringVar(value="None")
        self.tempo_var = ctk.StringVar(value="None")
        self.fast_mode_var = ctk.BooleanVar(value=False)
        self.skip_audit_var = ctk.BooleanVar(value=False)
        self.no_think_var = ctk.BooleanVar(value=False)
        self.proofread_level_var = ctk.StringVar(value="light")
        self.kdp_format_var = ctk.BooleanVar(value=True)
        self.kdp_para_style_var = ctk.StringVar(value="indented")
        self.coauthor_role_var = ctk.StringVar(value="AI Expert")
        self.word_count_var = ctk.StringVar(value="500")
        self.prompt_topic_var = ctk.StringVar(value="")

        self.edit_vars = {stage: ctk.BooleanVar(value=True) for stage in EDIT_STAGES}

    def setup_ui(self):
        # Settings panels live in a scrollable area so the window fits
        # smaller screens; everything below it is pinned to the window.
        self.scroll_frame = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll_frame.grid(row=0, column=0, sticky="nsew")
        self.scroll_frame.grid_columnconfigure(0, weight=1)

        file_frame = ctk.CTkFrame(self.scroll_frame)
        file_frame.grid(row=0, column=0, padx=20, pady=(15, 10), sticky="ew")
        file_frame.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(file_frame, text="File Settings", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=10, sticky="w")

        ctk.CTkLabel(file_frame, text="Input (.docx):").grid(row=1, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkEntry(file_frame, textvariable=self.input_var).grid(row=1, column=1, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(file_frame, text="Browse...", width=100, command=self.browse_input).grid(row=1, column=2, padx=10, pady=5)

        ctk.CTkLabel(file_frame, text="Output (.docx):").grid(row=2, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkEntry(file_frame, textvariable=self.output_var).grid(row=2, column=1, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(file_frame, text="Browse...", width=100, command=self.browse_output).grid(row=2, column=2, padx=10, pady=5)

        ctk.CTkLabel(file_frame, text="Bible File (Opt.):").grid(row=3, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkEntry(file_frame, textvariable=self.bible_var, placeholder_text="Optional reference text (.docx or .txt)...").grid(row=3, column=1, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(file_frame, text="Browse...", width=100, command=self.browse_bible).grid(row=3, column=2, padx=10, pady=5)

        model_frame = ctk.CTkFrame(self.scroll_frame)
        model_frame.grid(row=1, column=0, padx=20, pady=10, sticky="ew")
        model_frame.grid_columnconfigure(1, weight=1)
        model_frame.grid_columnconfigure(3, weight=1)

        ctk.CTkLabel(model_frame, text="Engine & Watch Tower Settings", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=10, sticky="w")

        ctk.CTkLabel(model_frame, text="Select Model:").grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.model_dropdown = ctk.CTkOptionMenu(model_frame, variable=self.model_var, values=["Loading..."])
        self.model_dropdown.grid(row=1, column=1, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(model_frame, text="Refresh", width=80, command=self.fetch_models).grid(row=1, column=2, padx=10, pady=5)

        ctk.CTkLabel(model_frame, text="Max Tokens:").grid(row=2, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(model_frame, variable=self.chunk_size_var, values=["500", "1000", "1500", "2000"]).grid(row=2, column=1, padx=10, pady=5, sticky="ew")

        ctk.CTkLabel(model_frame, text="Context Limit:").grid(row=2, column=2, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(model_frame, variable=self.context_size_var, values=["2048", "4096", "8192"]).grid(row=2, column=3, padx=10, pady=5, sticky="ew")

        ctk.CTkCheckBox(model_frame, text="Fast QA: skip AI audit (deterministic checks only)", variable=self.skip_audit_var).grid(row=3, column=0, columnspan=4, padx=10, pady=5, sticky="w")

        ctk.CTkCheckBox(model_frame, text="No-think: tell reasoning models (Qwen3 etc.) not to think — faster, no reasoning trace", variable=self.no_think_var).grid(row=4, column=0, columnspan=4, padx=10, pady=5, sticky="w")

        ctk.CTkCheckBox(model_frame, text="KDP Format (6x9 print layout)", variable=self.kdp_format_var).grid(row=5, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkLabel(model_frame, text="Paragraphs:").grid(row=5, column=1, padx=10, pady=5, sticky="e")
        ctk.CTkRadioButton(model_frame, text="Indented", variable=self.kdp_para_style_var, value="indented").grid(row=5, column=2, padx=10, pady=5, sticky="w")
        ctk.CTkRadioButton(model_frame, text="Spaced", variable=self.kdp_para_style_var, value="spaced").grid(row=5, column=3, padx=10, pady=5, sticky="w")

        coauthor_frame = ctk.CTkFrame(self.scroll_frame)
        coauthor_frame.grid(row=2, column=0, padx=20, pady=10, sticky="ew")
        coauthor_frame.grid_columnconfigure(1, weight=1)
        coauthor_frame.grid_columnconfigure(3, weight=1)

        ctk.CTkLabel(coauthor_frame, text="Co-Author Generation Agent", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=10, sticky="w")

        ctk.CTkLabel(coauthor_frame, text="Role:").grid(row=1, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(coauthor_frame, variable=self.coauthor_role_var, values=["AI Expert", "Engineer", "Novelist", "Researcher"]).grid(row=1, column=1, padx=10, pady=5, sticky="ew")

        ctk.CTkLabel(coauthor_frame, text="Target Words:").grid(row=1, column=2, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(coauthor_frame, variable=self.word_count_var, values=["500", "1500", "5000", "15000", "30000", "60000", "70000", "80000", "95000"]).grid(row=1, column=3, padx=10, pady=5, sticky="ew")

        ctk.CTkLabel(coauthor_frame, text="Prompt:").grid(row=2, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkEntry(coauthor_frame, textvariable=self.prompt_topic_var, placeholder_text="Leave blank to read topic from .docx...").grid(row=2, column=1, columnspan=2, padx=10, pady=5, sticky="ew")

        ctk.CTkButton(coauthor_frame, text="Generate Section", fg_color="#e67e22", hover_color="#d35400", command=self.start_coauthor_process).grid(row=2, column=3, padx=10, pady=5, sticky="ew")

        style_frame = ctk.CTkFrame(self.scroll_frame)
        style_frame.grid(row=3, column=0, padx=20, pady=10, sticky="ew")
        for i in range(1, 6, 2):
            style_frame.grid_columnconfigure(i, weight=1)

        ctk.CTkLabel(style_frame, text="Style Directives", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=10, sticky="w")

        ctk.CTkLabel(style_frame, text="Genre:").grid(row=1, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(style_frame, variable=self.genre_var, values=["None", "Self-Help", "Generic Fiction", "Sci-Fi", "Fantasy", "Romance"]).grid(row=1, column=1, padx=(0,10), pady=5, sticky="ew")

        ctk.CTkLabel(style_frame, text="Voice:").grid(row=1, column=2, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(style_frame, variable=self.voice_var, values=["None", "Authoritative", "Conversational", "Gritty", "Humorous", "Lyrical"]).grid(row=1, column=3, padx=(0,10), pady=5, sticky="ew")

        ctk.CTkLabel(style_frame, text="Tempo:").grid(row=1, column=4, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(style_frame, variable=self.tempo_var, values=["None", "Fast", "Balanced", "Slow"]).grid(row=1, column=5, padx=(0,10), pady=5, sticky="ew")

        pipe_frame = ctk.CTkFrame(self.scroll_frame)
        pipe_frame.grid(row=4, column=0, padx=20, pady=10, sticky="ew")

        ctk.CTkLabel(pipe_frame, text="Editing Stages", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=10, sticky="w")

        stages_frame = ctk.CTkFrame(pipe_frame, fg_color="transparent")
        stages_frame.grid(row=1, column=0, columnspan=4, padx=10, sticky="w")

        for i, (name, var) in enumerate(self.edit_vars.items()):
            ctk.CTkCheckBox(stages_frame, text=name, variable=var).grid(row=0, column=i, padx=(0, 15), pady=5)

        ctk.CTkSwitch(pipe_frame, text="⚡ Fast Mode: Single generation", variable=self.fast_mode_var, progress_color="#d35400").grid(row=2, column=0, padx=10, pady=10, sticky="w")

        ctk.CTkLabel(pipe_frame, text="Proofread level:").grid(row=3, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkRadioButton(pipe_frame, text="Light: grammar, spelling, dedup (±2% cap)", variable=self.proofread_level_var, value="light").grid(row=3, column=1, padx=10, pady=5, sticky="w")
        ctk.CTkRadioButton(pipe_frame, text="Full: style polish, ±5% word cap", variable=self.proofread_level_var, value="full").grid(row=3, column=2, padx=10, pady=5, sticky="w")

        control_frame = ctk.CTkFrame(self, fg_color="transparent")
        control_frame.grid(row=1, column=0, padx=20, pady=10, sticky="ew")
        control_frame.grid_columnconfigure(0, weight=1)
        control_frame.grid_columnconfigure(1, weight=1)

        self.start_btn = ctk.CTkButton(control_frame, text="Run Editing Pipeline", fg_color="#2ecc71", hover_color="#27ae60", font=ctk.CTkFont(weight="bold"), command=self.start_process)
        self.start_btn.grid(row=0, column=0, padx=(0, 5), sticky="ew")

        self.stop_btn = ctk.CTkButton(control_frame, text="Stop/Cancel", fg_color="#e74c3c", hover_color="#c0392b", font=ctk.CTkFont(weight="bold"), state="disabled", command=self.stop_process)
        self.stop_btn.grid(row=0, column=1, padx=(5, 0), sticky="ew")

        self.graphics_btn = ctk.CTkButton(control_frame, text="🎨 Graphics Studio (KDP)", fg_color="#8e44ad", hover_color="#71368a", font=ctk.CTkFont(weight="bold"), command=self.open_graphics)
        self.graphics_btn.grid(row=1, column=0, columnspan=2, pady=(8, 0), sticky="ew")

        self.progress_bar = ctk.CTkProgressBar(self)
        self.progress_bar.grid(row=2, column=0, padx=20, pady=(0, 10), sticky="ew")
        self.progress_bar.set(0)

        self.status_label = ctk.CTkLabel(self, text="Ready.", text_color="gray")
        self.status_label.grid(row=3, column=0, padx=20, sticky="w")

        self.log_area = ctk.CTkTextbox(self, height=150)
        self.log_area.grid(row=4, column=0, padx=20, pady=(0, 20), sticky="ew")

    def save_config(self):
        config = {
            "chunk_size": self.chunk_size_var.get(),
            "context_size": self.context_size_var.get(),
            "genre": self.genre_var.get(),
            "voice": self.voice_var.get(),
            "tempo": self.tempo_var.get(),
            "fast_mode": self.fast_mode_var.get(),
            "skip_audit": self.skip_audit_var.get(),
            "no_think": self.no_think_var.get(),
            "proofread_level": self.proofread_level_var.get(),
            "kdp_format": self.kdp_format_var.get(),
            "kdp_para_style": self.kdp_para_style_var.get(),
            "model": self.model_var.get(),
            "bible_file": self.bible_var.get(),
            "coauthor_role": self.coauthor_role_var.get(),
            "stages": {k: v.get() for k, v in self.edit_vars.items()}
        }
        # Merge over whatever is already on disk so other sections
        # (e.g. the Graphics Studio's "graphics" settings) survive an
        # editor save, and vice versa — and write atomically (Rounds
        # 1-3, review R4/R16c). update_config_file re-reads + merges
        # immediately before an os.replace write, and ABORTS rather
        # than overwriting a config it could not read, so a corrupt or
        # momentarily locked robo_config.json can never be truncated
        # or rewritten with only this window's section. Failures are
        # logged, not swallowed.
        ok, err = update_config_file(CONFIG_FILE, config)
        if not ok:
            try:
                self.log(f"Warning: settings not saved — {err}")
            except Exception:
                pass

    def load_config(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r') as f:
                    config = json.load(f)
                self.chunk_size_var.set(config.get("chunk_size", "1500"))
                self.context_size_var.set(config.get("context_size", "4096"))
                self.genre_var.set(config.get("genre", "None"))
                self.voice_var.set(config.get("voice", "None"))
                self.tempo_var.set(config.get("tempo", "None"))
                self.fast_mode_var.set(config.get("fast_mode", False))
                self.skip_audit_var.set(config.get("skip_audit", False))
                self.no_think_var.set(config.get("no_think", False))
                _lvl = config.get("proofread_level", "light")
                self.proofread_level_var.set("light" if str(_lvl).lower().startswith("light") else "full")
                self.kdp_format_var.set(config.get("kdp_format", True))
                self.kdp_para_style_var.set("spaced" if str(config.get("kdp_para_style", "indented")).lower().startswith("spac") else "indented")
                self.bible_var.set(config.get("bible_file", ""))
                self.coauthor_role_var.set(config.get("coauthor_role", "AI Expert"))
                stages = config.get("stages", {})
                for k, v in stages.items():
                    if k in self.edit_vars:
                        self.edit_vars[k].set(v)
                self.saved_model = config.get("model", "")
            except Exception:
                pass

    def on_closing(self):
        # Close guard (Rounds 1-3, review R2): the old code destroyed
        # the window unconditionally, killing the daemon worker threads
        # mid-save/mid-checkpoint and truncating the file being written.
        # Now: with a run in flight, ask first; if the user confirms,
        # request a cancel and wait — polling on the main thread — for
        # the worker to finish its interrupt/checkpoint path before
        # saving config and destroying. Declining keeps the window open.
        if self.is_processing:
            if self._close_pending:
                return  # already asked and confirmed; just waiting
            if not messagebox.askyesno(
                    "Run in progress",
                    "An editing/co-author run is still processing.\n\n"
                    "Stop it and close? The run will checkpoint its "
                    "progress first, so a later run can resume."):
                return
            self._close_pending = True
            self.engine.cancel_requested = True
            self.set_status("Stopping run before closing…")
            self.log("Close requested — cancelling run; window will close when the worker finishes.")
            self.after(200, self._poll_close_when_idle)
            return
        self.save_config()
        self.destroy()

    def _poll_close_when_idle(self):
        if self.is_processing:
            self.after(200, self._poll_close_when_idle)
            return
        self._close_pending = False
        self.save_config()
        self.destroy()

    def browse_input(self):
        filename = filedialog.askopenfilename(defaultextension=".docx", filetypes=[("Word Documents", "*.docx")])
        if filename:
            self.input_var.set(filename)
            base, ext = os.path.splitext(filename)
            self.output_var.set(f"{base}_edited{ext}")

    def browse_output(self):
        filename = filedialog.asksaveasfilename(defaultextension=".docx", filetypes=[("Word Documents", "*.docx")])
        if filename:
            self.output_var.set(filename)

    def browse_bible(self):
        filename = filedialog.askopenfilename(defaultextension=".docx", filetypes=[("Word/Text Files", "*.docx;*.txt"), ("All Files", "*.*")])
        if filename:
            self.bible_var.set(filename)
            self.log(f"Bible file loaded: {os.path.basename(filename)}")

    def open_graphics(self):
        win = getattr(self, "graphics_window", None)
        if win is not None:
            try:
                if win.winfo_exists():
                    win.lift()
                    win.focus_force()
                    return
            except Exception:
                pass
        try:
            from graphics_page import GraphicsStudio
            self.graphics_window = GraphicsStudio(self, CONFIG_FILE)
        except Exception as e:
            self.show_error("Graphics Studio",
                            f"Could not open the Graphics Studio.\n\n{e}\n\n"
                            "Tip: it needs Pillow — run: pip install Pillow")

    def fetch_models(self):
        def _task():
            try:
                req = urllib.request.Request(f"{self.engine.ollama_url}/api/tags")
                with urllib.request.urlopen(req, timeout=3) as response:
                    data = json.loads(response.read().decode())
                    models = [m['name'] for m in data.get('models', [])]
                    if models:
                        self.update_model_dropdown(models, error=False)
                        self.log("Models loaded from Ollama.")
                    else:
                        self.update_model_dropdown(["No models found"], error=True)
            except Exception:
                self.update_model_dropdown(["Connection Error"], error=True)
                self.log("Could not connect to Ollama. Ensure localhost:11434 is running.")

        threading.Thread(target=_task, daemon=True).start()

    def stop_process(self):
        if self.is_processing:
            self.engine.cancel_requested = True
            self.stop_btn.configure(state="disabled", text="Saving partial file...")
            self.log("Cancel requested... finishing current operation and saving progress.")

    def _handle_thread_error(self, e, context):
        """A user cancel is a graceful stop, not a critical error."""
        if isinstance(e, CancelRequested) or self.engine.cancel_requested:
            self.log(f"\n{context} cancelled by user.")
            self.set_status("Cancelled.")
        else:
            self.log(f"\nCRITICAL ERROR: {str(e)}")
            self.show_error("Pipeline Error", str(e))
            self.set_status("Error encountered.")

    @staticmethod
    def _input_signature(in_file):
        """mtime+size of the input docx, so editing the source file
        invalidates a checkpoint (path alone would silently resume
        from the OLD run's chunks)."""
        try:
            st = os.stat(in_file)
            return {"mtime": st.st_mtime, "size": st.st_size}
        except OSError:
            return {"mtime": 0, "size": 0}

    def _save_args(self, for_edit=False):
        """Output-formatting arguments for engine.save_document. Edit-
        pipeline saves also pass the source document's heading texts so
        '#' lines that were body text stay body text; co-author saves
        pass none (its headings are newly generated).

        During a run the KDP values come from the main-thread settings
        snapshot (round 16, S13) — worker threads never read Tk
        variables."""
        snap = getattr(self, "_active_settings", None)
        if snap is not None:
            kdp_format = snap["kdp_format"]
            kdp_style = snap["kdp_para_style"]
        else:
            kdp_format = bool(self.kdp_format_var.get())
            kdp_style = "spaced" if str(self.kdp_para_style_var.get()).lower().startswith("spac") else "indented"
        return {
            "kdp_format": kdp_format,
            "kdp_para_style": kdp_style,
            "known_headings": getattr(self.engine, "_source_headings", None) if for_edit else None,
        }

    def _write_edit_checkpoint(self, progress_path, partial_path, edited_chunks,
                                 in_file, chunk_size, total_chunks, active_stages, proofread_level,
                                 model="", style_hash=""):
        try:
            # Atomic write (review R4): a crash mid-dump used to leave
            # a truncated, unresumable checkpoint JSON behind.
            atomic_write_text(progress_path, json.dumps({
                    "schema": self.CHECKPOINT_SCHEMA,
                    "input": os.path.abspath(in_file),
                    "input_sig": self._input_signature(in_file),
                    "chunk_size": chunk_size,
                    "total_chunks": total_chunks,
                    "stages": active_stages,
                    "proofread_level": proofread_level,
                    # Fingerprint (round 15, S4): the model and the
                    # style directives shape every chunk; changing
                    # either between runs must not silently resume.
                    "model": model,
                    "style_hash": style_hash,
                    "chunks": edited_chunks,
                }))
            self.engine.save_document(edited_chunks, partial_path, log_callback=self.log, **self._save_args(for_edit=True))
            self.log(f"Checkpoint saved: {len(edited_chunks)}/{total_chunks} chunks -> {os.path.basename(partial_path)}")
        except Exception as ex:
            self.log(f"Warning: checkpoint write failed: {ex}")

    def _load_edit_checkpoint(self, progress_path, in_file, chunk_size, total_chunks, active_stages, proofread_level, edited_chunks, source_chunks=None, model="", style_hash=""):
        """Resume a previous run if the checkpoint matches this input/settings.
        Returns the chunk index to start from (0 = fresh start)."""
        if not os.path.exists(progress_path):
            return 0
        try:
            with open(progress_path, "r", encoding="utf-8") as f:
                saved = json.load(f)
            settings_match = (
                saved.get("schema") == self.CHECKPOINT_SCHEMA
                and saved.get("input") == os.path.abspath(in_file)
                and saved.get("chunk_size") == chunk_size
                and saved.get("total_chunks") == total_chunks
                and saved.get("stages") == active_stages
                and saved.get("proofread_level", "light") == proofread_level
                and saved.get("model", "") == model
                and saved.get("style_hash", "") == style_hash
                and isinstance(saved.get("chunks"), list)
                and 0 < len(saved["chunks"]) < total_chunks)
            if settings_match:
                if saved.get("input_sig") != self._input_signature(in_file):
                    # Same settings, but the source file changed since the
                    # checkpoint (or an older checkpoint without a signature).
                    # Resuming would mix old-run chunks with new-run chunks,
                    # so start fresh instead of silently corrupting output.
                    self.log("Input file changed since checkpoint — starting fresh (old progress discarded).")
                else:
                    edited_chunks.extend(saved["chunks"])
                    # Revalidate stored chunks before trusting them, for
                    # ANY stage count (round 15, S4 — this used to run
                    # single-stage only, and multi-stage is the default
                    # configuration, so the common case resumed blind).
                    # A checkpoint written under a gate regime with a
                    # hole in it can hold a damaged chunk that resume
                    # would otherwise ship untouched — the live gates
                    # only ever see NEW chunks.
                    #
                    # Multi-stage stored text is post-final-stage, so it
                    # is judged as the final stage's output: drift uses
                    # the loosest cap in the chain (stages accumulate
                    # legitimate drift), the artifact/heading/duplication
                    # gates always apply, and the invariance family
                    # (short lines, invariance, quotes) applies when
                    # every stage in the chain is bound by it — a chain
                    # containing Developmental/Combined is licensed to
                    # rewrite, so those gates can't judge its output
                    # against the original.
                    if source_chunks is not None and active_stages:
                        final_stage = active_stages[-1]
                        if len(active_stages) == 1:
                            if final_stage == STAGE_PROOFREAD:
                                drift_limit = 0.02 if proofread_level == "light" else 0.05
                            else:
                                drift_limit = None
                        else:
                            caps = []
                            for s in active_stages:
                                if s == STAGE_PROOFREAD:
                                    caps.append(0.02 if proofread_level == "light" else 0.05)
                                else:
                                    caps.append(WatchTowerAgent.DRIFT_LIMITS.get(
                                        s, WatchTowerAgent.DEFAULT_DRIFT_LIMIT))
                            drift_limit = max(caps)
                        rewrite_bound = set(active_stages) <= REWRITE_BOUND_STAGES
                        wt = WatchTowerAgent(self.engine, model)
                        for k, stored in enumerate(list(edited_chunks)):
                            if k >= len(source_chunks):
                                break
                            # The one canonical gate chain (round 16,
                            # S13): the same validate_chunk the live
                            # pipeline runs — no second hand-maintained
                            # copy to drift out of sync again.
                            ok_k, why_k = wt.validate_chunk(
                                source_chunks[k], stored, final_stage,
                                drift_limit=drift_limit, rewrite_bound=rewrite_bound)
                            if not ok_k:
                                self.log(f"Checkpoint chunk {k+1} failed revalidation ({why_k[:80]}) — it will be reprocessed.")
                                del edited_chunks[k:]
                                break
                    self.log(f"Resuming from checkpoint: {len(edited_chunks)}/{total_chunks} chunks already done.")
                    return len(edited_chunks)
        except Exception as ex:
            self.log(f"Ignoring unreadable checkpoint: {ex}")
        return 0

    def _post_save_audit(self, in_file, out_file, chapter_cap, model=""):
        """Grade the finished book as a book (round 15, S6).

        Every gate in the pipeline is per-chunk; nothing used to verify
        the saved file whole — totals, per-chapter drift, heading
        census, quote census, name and term census. That audit was
        being done by hand after runs, and it is the audit that caught
        the damage the pipeline itself reported as success. Writes a
        .report.txt beside the output and logs the verdict."""
        try:
            wt = WatchTowerAgent(self.engine, model)

            def sections_of(path):
                d = docx.Document(path)
                paras = []
                for p in d.paragraphs:
                    try:
                        sty = p.style.name if p.style else ""
                    except Exception:
                        sty = ""
                    paras.append((sty, p.text))
                # Section starts are found three ways, because the
                # failure this audit exists to catch is headings that
                # lost their style: (1) a real Heading 1 style, (2) a
                # markdown '#' line standing as body text, (3) a short
                # standalone line whose text matches a heading known
                # from either document. Keys are whitespace-free so a
                # fused heading ("CHAPTER 1The Arithmetic") still keys
                # to its chapter.
                def squash(t):
                    return re.sub(r"\s+", "", t.replace("#", "")).lower()
                known = set()
                for sty, t in paras:
                    s = t.strip()
                    if (sty == "Heading 1" or s.startswith("#")) and s:
                        known.add(squash(s))
                secs, order, cur = {}, [], "FRONT"
                display = {}
                for sty, t in paras:
                    s = t.strip()
                    is_head = bool(s) and (
                        sty == "Heading 1" or s.startswith("#")
                        or (len(s.split()) <= 12 and squash(s) in known))
                    if is_head:
                        cur = squash(s)
                        if cur not in secs:
                            secs[cur] = []
                            order.append(cur)
                            display[cur] = re.sub(r"\s+", " ", s.replace("#", "")).strip()
                    secs.setdefault(cur, []).append(t)
                return {k: "\n".join(v) for k, v in secs.items()}, order, display

            src, s_order, s_disp = sections_of(in_file)
            out, o_order, o_disp = sections_of(out_file)
            src_text = "\n".join(src.values())
            out_text = "\n".join(out.values())
            src_words = len(src_text.split())
            out_words = len(out_text.split())
            total_drift = (abs(out_words - src_words) / src_words) if src_words else 0.0

            problems = []
            detail = []
            for key in s_order:
                name = s_disp.get(key, key)[:50]
                if key not in out:
                    problems.append(f"section MISSING from output: '{s_disp.get(key, key)[:60]}'")
                    continue
                sw, ow = len(src[key].split()), len(out[key].split())
                if sw and abs(ow - sw) / sw > chapter_cap:
                    problems.append(
                        f"section '{name}' drifted {abs(ow - sw) / sw * 100:.1f}% "
                        f"({sw} -> {ow} words), beyond the {chapter_cap * 100:.0f}% cap")
                detail.append(f"  {name:52s} {sw:>7,} -> {ow:>7,} words")
            for key in o_order:
                if key not in src:
                    problems.append(f"section INVENTED in output: '{o_disp.get(key, key)[:60]}'")
            if out_text.count('"') > src_text.count('"'):
                problems.append(f"straight double quotes introduced: {src_text.count(chr(34))} -> {out_text.count(chr(34))}")
            _apos = lambda t: len(re.findall(r"[A-Za-z]'[A-Za-z]", t))
            if _apos(out_text) > _apos(src_text):
                problems.append(f"straight apostrophes introduced: {_apos(src_text)} -> {_apos(out_text)}")
            src_fused = {wt._name_key(w) for w in src_text.split()}
            src_fused.discard("")
            gained = sorted({k for k, initial in wt._capitalized_tokens(out_text)
                             if not initial and k not in src_fused})
            if gained:
                problems.append("names in output that appear nowhere in the input: "
                                + ", ".join(gained[:10]))
            o_terms, e_terms = wt._term_multiset(src_text), wt._term_multiset(out_text)
            if o_terms != e_terms:
                lost = o_terms - e_terms
                new = e_terms - o_terms
                bits = []
                if lost:
                    bits.append("lost " + ", ".join(f"'{k}' x{v}" for k, v in list(lost.items())[:6]))
                if new:
                    bits.append("gained " + ", ".join(f"'{k}' x{v}" for k, v in list(new.items())[:6]))
                problems.append("hyphenated terms changed (" + "; ".join(bits) + ")")

            verdict = "CLEAN" if not problems else f"{len(problems)} PROBLEM(S)"
            report_path = os.path.splitext(out_file)[0] + ".report.txt"
            lines = [
                f"POST-SAVE AUDIT: {verdict}",
                f"Input:  {os.path.basename(in_file)} ({src_words:,} words, {len(s_order)} sections)",
                f"Output: {os.path.basename(out_file)} ({out_words:,} words, total drift {total_drift * 100:.2f}%)",
                "",
                "Per-section words:",
                *detail,
            ]
            if problems:
                lines += ["", "Problems:"] + [f"  - {p}" for p in problems]
            _report_written = True
            try:
                atomic_write_text(report_path, "\n".join(lines) + "\n")
            except Exception:
                _report_written = False
            if _report_written:
                self.log(f"\nPost-save audit: {verdict} (report: {os.path.basename(report_path)})")
            else:
                self.log(f"\nPost-save audit: {verdict} (report could not be written: {os.path.basename(report_path)})")
            for p in problems[:8]:
                self.log(f"  AUDIT: {p}")
        except Exception as ex:
            self.log(f"Post-save audit could not run: {ex}")

    # --- Processing Execution ---
    def start_process(self):
        if self.is_processing:
            return

        in_file = self.input_var.get().strip()
        out_file = self.output_var.get().strip()

        if not in_file or not os.path.exists(in_file):
            messagebox.showwarning("Missing Input", "Please select a valid input .docx file.")
            return
        if not out_file:
            messagebox.showwarning("Missing Output", "Please select an output file path.")
            return
        if os.path.abspath(in_file) == os.path.abspath(out_file):
            # The pipeline would overwrite the source manuscript with
            # its own output (round 15, S3). The browse auto-fill uses
            # a safe _edited name; a hand-typed path may not.
            messagebox.showwarning("Output Is the Input",
                "The output file is the input file — running would overwrite your manuscript. Choose a different output path.")
            return

        # Snapshot every setting HERE, on the main thread (round 16,
        # S13). Tkinter variables are not thread-safe — the worker used
        # to read a dozen of them from its own thread, which works
        # until it doesn't. The worker receives plain values only.
        style_parts = []
        if self.genre_var.get() != "None": style_parts.append(f"Genre: {self.genre_var.get()}")
        if self.voice_var.get() != "None": style_parts.append(f"Voice: {self.voice_var.get()}")
        if self.tempo_var.get() != "None": style_parts.append(f"Tempo: {self.tempo_var.get()}")
        settings = {
            "model": self.model_var.get(),
            "chunk_size": int(self.chunk_size_var.get()),
            "context_limit": int(self.context_size_var.get()),
            "fast_mode": bool(self.fast_mode_var.get()),
            "skip_audit": bool(self.skip_audit_var.get()),
            "no_think": bool(self.no_think_var.get()),
            "proofread_level": "light" if self.proofread_level_var.get().lower().startswith("light") else "full",
            "bible_file": self.bible_var.get().strip(),
            "style_prompt": "\nSTYLE DIRECTIVES:\n" + ", ".join(style_parts) + "\n" if style_parts else "",
            "kdp_format": bool(self.kdp_format_var.get()),
            "kdp_para_style": "spaced" if str(self.kdp_para_style_var.get()).lower().startswith("spac") else "indented",
        }
        if settings["fast_mode"]:
            settings["active_stages"] = [STAGE_COMBINED]
        else:
            settings["active_stages"] = [s for s, v in self.edit_vars.items() if v.get()]
        settings["style_hash"] = hashlib.md5(settings["style_prompt"].encode("utf-8")).hexdigest()[:12]
        self._active_settings = settings

        if not settings["active_stages"]:
            messagebox.showwarning("No Stages", "Select at least one editing stage.")
            return

        self.is_processing = True
        self.engine.cancel_requested = False
        self.start_btn.configure(state="disabled", text="Processing...")
        self.stop_btn.configure(state="normal", text="Stop/Cancel")
        self.log_area.delete("1.0", "end")

        threading.Thread(target=self._run_pipeline_thread, args=(in_file, out_file, settings), daemon=True).start()

    def _run_pipeline_thread(self, in_file, out_file, settings):
        try:
            # Plain values from the main-thread snapshot (round 16,
            # S13) — no Tk variable is read on this thread.
            model = settings["model"]
            self.engine.think_off = settings["no_think"]
            chunk_size = settings["chunk_size"]
            context_limit = settings["context_limit"]
            skip_audit = settings["skip_audit"]
            proofread_level = settings["proofread_level"]
            bible_file = settings["bible_file"]
            style_prompt = settings["style_prompt"]
            active_stages = settings["active_stages"]
            style_hash = settings["style_hash"]

            self.log(f"Loading and chunking {os.path.basename(in_file)} (Max Tokens: {chunk_size})...")
            chunks = self.engine.load_and_chunk(in_file, max_tokens_per_chunk=chunk_size)
            total_chunks = len(chunks)
            if total_chunks == 0:
                self.log("Document is empty or could not be read.")
                return

            self.log(f"Document split into {total_chunks} chunk(s).")
            _img_n = getattr(self.engine, "_input_image_count", 0)
            if _img_n:
                self.log(f"WARNING: the input document contains {_img_n} image(s). The editor's text pipeline does NOT carry images into the output — they will be MISSING from the saved file. Edit a no-graphics copy, or plan to re-insert the images afterward.")

            orchestrator = AgentPipelineOrchestrator(self.engine, model)

            # Checkpoint sidecars: a crash or cancel mid-run no longer loses hours
            # of work. The JSON holds the exact edited chunks (resume); the docx
            # is for human inspection. Both are deleted on a clean finish.
            out_base = os.path.splitext(out_file)[0]
            progress_path = out_base + ".progress.json"
            partial_path = out_base + ".partial.docx"

            edited_chunks = []
            start_idx = self._load_edit_checkpoint(
                progress_path, in_file, chunk_size, total_chunks, active_stages, proofread_level, edited_chunks,
                source_chunks=chunks, model=model, style_hash=style_hash)

            for i in range(start_idx, total_chunks):
                chunk = chunks[i]
                if self.engine.cancel_requested:
                    self.log("\nPipeline stopped by user. Saving progress...")
                    break

                self.log(f"\n--- Processing Chunk {i+1}/{total_chunks} ---")
                current_text = chunk
                # Continuity: the previous (fully edited) chunk keeps names,
                # pronouns, and tense consistent across chunk boundaries.
                previous_chunk = edited_chunks[-1] if edited_chunks else ""

                for stage in active_stages:
                    if self.engine.cancel_requested: break
                    self.set_status(f"Processing Chunk {i+1}/{total_chunks} | Stage: {stage}")

                    current_text = orchestrator.process_chunk(
                        chunk_text=current_text,
                        stage=stage,
                        style_prompt=style_prompt,
                        context_limit=context_limit,
                        stream_callback=None,
                        log_callback=self.log,
                        bible_path=bible_file if bible_file else "",
                        skip_llm_audit=skip_audit,
                        previous_chunk=previous_chunk,
                        proofread_level=proofread_level
                    )

                edited_chunks.append(current_text)
                self.set_progress((i + 1) / total_chunks)

                if (i + 1) % 5 == 0:
                    self._write_edit_checkpoint(
                        progress_path, partial_path, edited_chunks,
                        in_file, chunk_size, total_chunks, active_stages, proofread_level,
                        model=model, style_hash=style_hash)

            if len(edited_chunks) == total_chunks and not self.engine.cancel_requested:
                self.log("\nSaving final document...")
                self.engine.save_document(edited_chunks, out_file, log_callback=self.log, **self._save_args(for_edit=True))
                self.log(f"Successfully saved to {out_file}")
                # Grade the finished book before declaring victory (S6).
                if STAGE_PROOFREAD in active_stages:
                    _cap = 0.02 if proofread_level == "light" else 0.05
                elif any(s in (STAGE_DEVELOPMENTAL, STAGE_COMBINED) for s in active_stages):
                    _cap = 0.35
                else:
                    _cap = 0.15
                self._post_save_audit(in_file, out_file, _cap, model=model)
                self.set_status("Pipeline complete.")
                for p in (progress_path, partial_path):
                    try:
                        if os.path.exists(p):
                            os.remove(p)
                    except Exception:
                        pass
            elif edited_chunks:
                # Cancelled or interrupted: checkpoint so a re-run resumes.
                self._write_edit_checkpoint(
                    progress_path, partial_path, edited_chunks,
                    in_file, chunk_size, total_chunks, active_stages, proofread_level,
                    model=model, style_hash=style_hash)
                self.log(f"\nInterrupted at chunk {len(edited_chunks)}/{total_chunks} — progress saved. Re-run to resume.")
                self.set_status("Interrupted — progress saved.")
            else:
                self.log("\nNo chunks were processed — no file written.")
                self.set_status("Cancelled before any output.")
            self.set_progress(1.0)

        except Exception as e:
            self._handle_thread_error(e, "Pipeline")
        finally:
            self.reset_ui_state("ready")

    def start_coauthor_process(self):
        if self.is_processing: return
        topic = self.prompt_topic_var.get().strip()
        in_file = self.input_var.get().strip()

        if not topic and in_file:
            try:
                chunks = self.engine.load_and_chunk(in_file, max_tokens_per_chunk=1000)
                if chunks:
                    topic = chunks[0]
                    self.log("Loaded topic outline from input file.")
            except Exception as e:
                self.log(f"Failed to load topic from input file: {e}")

        if not topic:
            messagebox.showwarning("Missing Prompt", "Please enter a topic prompt or input .docx file.")
            return

        role = self.coauthor_role_var.get()
        word_count = int(self.word_count_var.get())
        model = self.model_var.get()
        out_file = self.output_var.get()

        if not out_file:
            messagebox.showwarning("Missing Output", "Please select an output file path.")
            return
        if in_file and os.path.exists(in_file) and os.path.abspath(in_file) == os.path.abspath(out_file):
            messagebox.showwarning("Output Is the Input",
                "The output file is the input file — generating would overwrite it. Choose a different output path.")
            return

        # Main-thread settings snapshot, same rule as the edit
        # pipeline (round 16, S13): the worker gets plain values.
        settings = {
            "context_limit": int(self.context_size_var.get()),
            "skip_audit": bool(self.skip_audit_var.get()),
            "no_think": bool(self.no_think_var.get()),
            "bible_file": self.bible_var.get().strip(),
            "kdp_format": bool(self.kdp_format_var.get()),
            "kdp_para_style": "spaced" if str(self.kdp_para_style_var.get()).lower().startswith("spac") else "indented",
        }
        self._active_settings = settings

        self.is_processing = True
        self.engine.cancel_requested = False
        self.start_btn.configure(state="disabled", text="Processing...")
        self.stop_btn.configure(state="normal", text="Stop/Cancel")
        self.log_area.delete("1.0", "end")

        threading.Thread(target=self._run_coauthor_thread, args=(topic, role, word_count, model, out_file, settings), daemon=True).start()

    def _run_coauthor_thread(self, topic, role, word_count, model, out_file, settings):
        try:
            self.engine.think_off = settings["no_think"]
            context_limit = settings["context_limit"]
            skip_audit = settings["skip_audit"]
            orchestrator = AgentPipelineOrchestrator(self.engine, model)
            bible_file = settings["bible_file"]

            generated_chunks = []
            generated_words = 0
            block_target = 1500

            sequence_id = 1
            max_blocks = max(1, word_count // block_target + (1 if word_count % block_target > 0 else 0))
            # Guard against a stingy model: don't loop forever on tiny blocks.
            max_iterations = max_blocks * 3
            partial_file = os.path.splitext(out_file)[0] + ".partial.docx"

            self.log(f"Starting long-form generation. Target: {word_count} words.")

            while generated_words < word_count and sequence_id <= max_iterations:
                if self.engine.cancel_requested:
                    self.log("\nStop requested by user. Halting generation loop...")
                    break

                remaining_words = word_count - generated_words
                current_block_target = min(block_target, remaining_words)

                def stream_update(text):
                    current_total = generated_words + len(text.split())
                    self.set_status(f"Generating block {sequence_id}/{max_blocks} (~{current_total}/{word_count} words)...")

                self.log(f"\nGenerating block {sequence_id}/{max_blocks} (Target: {current_block_target} words)...")

                draft = orchestrator.generate_new_content(
                    prompt_topic=topic,
                    role=role,
                    target_word_count=current_block_target,
                    sequence_id=sequence_id,
                    max_blocks=max_blocks,
                    context_limit=context_limit,
                    stream_callback=stream_update,
                    log_callback=self.log,
                    bible_path=bible_file if bible_file else "",
                    previous_chunk=generated_chunks[-1] if generated_chunks else "",
                    skip_llm_audit=skip_audit
                )

                if draft:
                    generated_chunks.append(draft)
                    generated_words += len(draft.split())
                    self.log(f"Block {sequence_id} complete. Total words so far: ~{generated_words}")
                    if sequence_id % 5 == 0:
                        self.engine.save_document(generated_chunks, partial_file, log_callback=self.log, **self._save_args())
                        self.log(f"Checkpoint saved: {partial_file}")
                else:
                    self.log("Generation yielded no text, aborting loop.")
                    break

                sequence_id += 1

            if sequence_id > max_iterations and generated_words < word_count:
                self.log(f"\nReached iteration cap ({max_iterations} blocks) at ~{generated_words} words. Stopping.")

            if generated_chunks:
                self.engine.save_document(generated_chunks, out_file, log_callback=self.log, **self._save_args())
                self.log(f"\nProcessing complete! File saved to: {out_file}")
                self.set_status("Generation complete.")
            else:
                self.log("\nNothing was generated — no file written.")
                self.set_status("Cancelled before any output.")
            self.set_progress(1.0)

        except Exception as e:
            self._handle_thread_error(e, "Generation")
        finally:
            self.reset_ui_state("ready")

if __name__ == "__main__":
    app = RoboEditorUI()
    app.mainloop()
