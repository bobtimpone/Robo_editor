from agents.scribe_agent import ScribeAgent
from agents.watchtower_agent import WatchTowerAgent
from agents.keeper_agent import KeeperAgent
from agents.coauthor_agent import CoAuthorAgent

try:
    from agents.vocab import STAGE_PROOFREAD, STAGE_COAUTHOR
except ImportError:  # flat layout (tests, direct runs)
    from vocab import STAGE_PROOFREAD, STAGE_COAUTHOR

# Stamped into the first log line of every chunk pass so a pasted log
# excerpt identifies the exact build that produced it. Bump on every
# shipped fix round and announce the tag with the zip.
BUILD_TAG = "2026-10-28-r123"

try:
    from engine import CancelRequested
except ImportError:  # pragma: no cover - engine is a sibling module
    class CancelRequested(Exception):
        pass

class AgentPipelineOrchestrator:
    def __init__(self, engine, model):
        self.engine = engine
        self.model = model
        self.scribe = ScribeAgent(engine, model)
        self.watchtower = WatchTowerAgent(engine, model)
        self.keeper = KeeperAgent(engine, model)
        self.coauthor = CoAuthorAgent(engine, model)
        # Co-author continuity ledger (Rounds 1-3, review R6): always
        # initialised, so a resumed session whose first call has
        # sequence_id != 1 reads "" instead of raising AttributeError.
        self._ledger = ""

    def process_chunk(self, chunk_text, stage, style_prompt="", context_limit=4096, stream_callback=None, log_callback=None, bible_path="story_bible.txt", skip_llm_audit=False, previous_chunk="", proofread_level="full"):
        if log_callback: log_callback(f"[{stage}] Starting processing pass... (build {BUILD_TAG})")

        story_bible = self.keeper.load_story_bible(bible_path)
        bible_context = f"\nSTORY BIBLE / CANON LOCK:\n{story_bible}\n" if story_bible else ""

        # Light proofread is spelling/grammar only: ~zero word-count change is
        # expected, so the leash is ±2%. Full proofread gets ±5%. Anything
        # over the cap falls back to the original chunk (do-no-harm rule).
        if stage == STAGE_PROOFREAD:
            drift_limit = 0.02 if proofread_level == "light" else 0.05
        else:
            drift_limit = None

        def audit(candidate):
            result = self.watchtower.inspect_chunk(
                chunk_text, candidate, stage,
                context_limit=context_limit, skip_llm_audit=skip_llm_audit,
                previous_chunk=previous_chunk, drift_limit=drift_limit,
                audit_context=style_prompt)
            # Advisory notes (e.g. the demoted human score) surface in
            # the log instead of silently vanishing (round 16, S13).
            for w in self.watchtower.pop_warnings():
                if log_callback: log_callback(f"[{stage}] Watch Tower advisory: {w}")
            return result

        if self.engine.cancel_requested:
            return chunk_text

        # Do-no-harm on failure too (Rounds 1-3, review R7): an ordinary
        # exception anywhere in the edit / inspect / correct chain (an
        # Ollama outage mid-book is the realistic case) must not abort
        # the run — the chunk falls back to its original text and the
        # pipeline continues with the next one. CancelRequested is NOT
        # swallowed: a user stop must still reach the app's
        # interrupt/checkpoint flow immediately.
        try:
            edited_text = self.scribe.edit(chunk_text, stage, style_prompt=style_prompt + bible_context, context_limit=context_limit, stream_callback=stream_callback, continuity_context=previous_chunk, proofread_level=proofread_level)

            if log_callback: log_callback(f"[{stage}] Watch Tower inspecting...")
            is_approved, qa_feedback = audit(edited_text)
            if is_approved:
                if log_callback: log_callback(f"[{stage}] Watch Tower: STATUS APPROVED.")
                return edited_text

            # Up to TWO correction attempts, each one told the audit's actual
            # feedback and audited before acceptance. (correct() used to drop
            # the feedback argument entirely, so the single correction was a
            # blind re-polish that failed the same gate again. The pre-review
            # code shipped its correction unaudited — that is how chunks got
            # gutted — so every attempt here is audited, and if none pass,
            # the original is kept.)
            candidate = edited_text
            feedback = qa_feedback
            for attempt in (1, 2):
                if log_callback: log_callback(f"[{stage}] Watch Tower Rejection: {feedback[:100]}... Refining correction (attempt {attempt} of 2)...")
                if self.engine.cancel_requested:
                    return chunk_text
                candidate = self.scribe.correct(candidate, feedback + bible_context, context_limit=context_limit, continuity_context=previous_chunk)
                is_approved_c, feedback = audit(candidate)
                if is_approved_c:
                    if log_callback: log_callback(f"[{stage}] Watch Tower: STATUS APPROVED after correction (attempt {attempt}).")
                    return candidate

            # DO NO HARM: the WatchTower never approved this chunk. Returning an
            # unapproved correction is how chapters get gutted — keep the original.
            if log_callback: log_callback(f"[{stage}] Watch Tower never approved — keeping original chunk (do-no-harm fallback).")
            return chunk_text
        except CancelRequested:
            raise
        except Exception as e:
            if getattr(self.engine, "cancel_requested", False):
                raise CancelRequested("Processing cancelled by user.")
            if log_callback: log_callback(f"[{stage}] Processing error ({e}) — keeping original chunk (do-no-harm fallback, review R7).")
            return chunk_text

    def generate_new_content(self, prompt_topic, role, target_word_count, sequence_id=1, max_blocks=1, context_limit=4096, stream_callback=None, log_callback=None, bible_path="story_bible.txt", previous_chunk="", skip_llm_audit=False):
        if log_callback: log_callback(f"[Co-Author] Generating block {sequence_id}/{max_blocks}... (build {BUILD_TAG})")

        # Rolling continuity ledger: fold the previous block into the running
        # summary instead of re-reading the whole manuscript every block.
        # (The old per-block summarize_state only ever saw the last 3 blocks,
        # so long books lost their early chapters.)
        if sequence_id == 1:
            self._ledger = ""
        if previous_chunk:
            self._ledger = self.keeper.summarize_state(previous_chunk, previous_summary=self._ledger, context_limit=context_limit)

        bible_text = self.keeper.load_story_bible(bible_path)
        bible_context = f"\n\nSTORY BIBLE / CANON LOCK (do not contradict):\n{bible_text}\n" if bible_text else ""
        continuity = (
            f"\n\nPREVIOUS BLOCK (tail end — continue seamlessly, do not repeat it):\n{previous_chunk[-2000:]}\n"
            if previous_chunk else ""
        )
        ledger = (
            f"\n\nESTABLISHED STATE LEDGER (DO NOT REPEAT THESE EVENTS):\n{self._ledger}"
            if self._ledger else ""
        )

        full_prompt = f"{prompt_topic}{ledger}{continuity}{bible_context}"

        draft = self.coauthor.write_section(
            full_prompt, role, target_word_count,
            context_limit=context_limit,
            stream_callback=stream_callback,
            target_word_limit=target_word_count,
        )

        def inspect_gen(candidate):
            result = self.watchtower.inspect_chunk("", candidate, STAGE_COAUTHOR, context_limit=context_limit, skip_llm_audit=skip_llm_audit)
            for w in self.watchtower.pop_warnings():
                if log_callback: log_callback(f"[Co-Author] Watch Tower advisory: {w}")
            return result

        is_approved, qa_feedback = inspect_gen(draft)
        if not is_approved:
            if log_callback: log_callback(f"[Co-Author] Watch Tower flagged loop/quality violation. Running corrective pass...")
            corrected = self.scribe.correct(draft, qa_feedback, context_limit=context_limit)
            # Audit the correction before shipping it (round 15, S5).
            # This path used to ship its corrective pass unreviewed —
            # the exact blind-correction anti-pattern round 12 removed
            # from the edit pipeline. A correction that fails its own
            # audit discards the block instead.
            ok_c, fb_c = inspect_gen(corrected)
            if ok_c:
                draft = corrected
            else:
                if log_callback: log_callback(f"[Co-Author] Corrective pass failed its audit too ({fb_c[:100]}) — discarding block rather than shipping unreviewed text.")
                return ""
        # Guard against a degenerate block: the app treats "" as a stop signal,
        # which beats silently saving garbage into the manuscript.
        if len(draft.split()) < 20:
            if log_callback: log_callback(f"[Co-Author] Block came back degenerate ({len(draft.split())} words) — discarding.")
            return ""
        return draft
