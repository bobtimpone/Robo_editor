"""Text-to-graphic helpers for the Robo-Editor Graphics Studio.

Take a passage of manuscript text and turn it into a clean, print-ready
graphic at KDP sizes: a key-points panel, a pull-quote card, a chapter
callout, a scene card, or a simple timeline.

Two brains, one renderer:
  - Built-in extractor (no AI, no network): deterministic sentence
    scoring pulls a title, key points, and a pull-quote from the text.
  - Ollama (optional): the editor's selected model reads the passage
    and returns structured JSON (title / bullets / quote), which is
    sanitized by parse_ai_graphic_json() before it is trusted.

Rendering is Pillow, sized in exact pixels at 300 DPI, grayscale-safe
light panel by default (novel interiors print in black ink).
"""

import json
import os
import re
import urllib.error
import urllib.request

import graphics_kdp as gk

GRAPHIC_KINDS = [
    "Key Points Panel",
    "Pull-Quote Card",
    "Chapter Callout",
    "Scene Card",
    "Timeline",
]

_WORD_RE = re.compile(r"[A-Za-z][A-Za-z'’-]*")
_STOPWORDS = {
    "the", "and", "that", "with", "from", "this", "were", "was", "are",
    "have", "had", "has", "but", "not", "you", "your", "they", "them",
    "then", "than", "into", "onto", "over", "under", "when", "what",
    "who", "whom", "which", "there", "here", "been", "being", "would",
    "could", "should", "about", "because", "before", "after", "between",
    "through", "their", "there", "these", "those", "very", "just",
    "like", "more", "most", "some", "such", "only", "also", "said",
    "says", "one", "two", "all", "any", "can", "will", "shall", "may",
}

_KIND_TITLES = {
    "Key Points Panel": "Key Points",
    "Pull-Quote Card": "From the Manuscript",
    "Chapter Callout": "Chapter Callout",
    "Scene Card": "Scene Card",
    "Timeline": "Timeline",
}


# ----------------------------------------------------------------------
# Loading manuscript text
# ----------------------------------------------------------------------

def extract_text_from_file(path):
    """Plain text from a .docx (paragraphs), .txt, or .md file."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".docx":
        import docx
        doc = docx.Document(path)
        return "\n\n".join(p.text for p in doc.paragraphs if p.text.strip())
    if ext in (".txt", ".md"):
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    raise ValueError(f"Unsupported file type '{ext}'. Use .docx, .txt, or .md.")


def split_paragraphs(text):
    paras = [p.strip() for p in re.split(r"\n\s*\n", text.replace("\r\n", "\n"))]
    if len(paras) <= 1 and "\n" in text:
        paras = [p.strip() for p in text.split("\n")]
    return [p for p in paras if p]


def find_text_context(text, query, neighbors=1):
    """The paragraph containing `query`, plus `neighbors` on each side."""
    if not query or not query.strip():
        raise ValueError("Type a word or phrase to search for first.")
    paras = split_paragraphs(text)
    q = query.strip().lower()
    for i, p in enumerate(paras):
        if q in p.lower():
            lo = max(0, i - neighbors)
            hi = min(len(paras), i + neighbors + 1)
            return "\n\n".join(paras[lo:hi])
    raise ValueError(f"'{query}' was not found in the manuscript text.")


# ----------------------------------------------------------------------
# Built-in (deterministic) analysis
# ----------------------------------------------------------------------

def split_sentences(text):
    flat = re.sub(r"\s+", " ", text).strip()
    parts = re.findall(r"[^.!?]+(?:[.!?]+[\"”’']*)?", flat)
    return [p.strip() for p in parts if len(p.strip()) > 2]


def _content_words(s):
    return [w.lower() for w in _WORD_RE.findall(s)
            if len(w) > 3 and w.lower() not in _STOPWORDS]


def _score(sentence, freq):
    words = _content_words(sentence)
    if not words:
        return 0.0
    density = sum(freq.get(w, 0) for w in words) / len(words)
    length_fit = max(0.0, 1.0 - abs(len(sentence) - 115) / 260)
    bonus = 0.4 if ("“" in sentence or '"' in sentence) else 0.0
    return density + length_fit + bonus


def _pick_diverse(sentences, freq, count):
    ranked = sorted(sentences, key=lambda s: _score(s, freq), reverse=True)
    picked = []
    for s in ranked:
        ws = set(_content_words(s))
        if any(len(ws & set(_content_words(p))) > 0.6 * max(1, len(ws))
               for p in picked):
            continue
        picked.append(s)
        if len(picked) >= count:
            break
    # Restore reading order for the panel.
    return [s for s in sentences if s in picked]


def analyze_text(text, kind="Key Points Panel", source_name=""):
    """Deterministic title / bullets / quote / body from a passage."""
    if kind not in GRAPHIC_KINDS:
        kind = "Key Points Panel"
    paras = split_paragraphs(text)
    sentences = split_sentences(text)
    if not sentences:
        raise ValueError("That passage has no readable sentences in it.")

    freq = {}
    for s in sentences:
        for w in set(_content_words(s)):
            freq[w] = freq.get(w, 0) + 1

    # Title: a short heading-like first paragraph, else the opening
    # sentence's first seven words, else the kind's default label.
    title = _KIND_TITLES[kind]
    if paras:
        first = paras[0]
        if len(first) <= 90 and len(first.split()) <= 12 \
                and not first.endswith((".", "!", "?")):
            title = first
        elif sentences:
            words = sentences[0].split()[:7]
            cand = " ".join(words).strip(" ,;:")
            if len(cand) >= 8:
                title = cand[0].upper() + cand[1:]

    if kind == "Timeline":
        steps = [s for s in sentences
                 if re.search(r"\d", s) or re.search(
                     r"\b(first|then|next|finally|after|before|later)\b",
                     s, re.I)]
        bullets = (steps or _pick_diverse(sentences, freq, 4))[:6]
    else:
        bullets = _pick_diverse(sentences, freq, 5 if kind != "Pull-Quote Card" else 3)

    quote_pool = [s for s in sentences if 40 <= len(s) <= 200] or sentences
    quote = max(quote_pool, key=lambda s: _score(s, freq)) if quote_pool else ""

    body = ""
    if kind in ("Chapter Callout", "Scene Card") and paras:
        body = paras[0] if paras[0] != title else (paras[1] if len(paras) > 1 else "")
        if len(body) > 460:
            body = body[:457].rstrip() + "..."

    return {
        "title": title,
        "subtitle": kind,
        "bullets": bullets,
        "quote": quote,
        "body": body,
        "footer": source_name or "Generated from manuscript text",
    }


# ----------------------------------------------------------------------
# Ollama analysis (optional)
# ----------------------------------------------------------------------

_AI_SYSTEM = (
    "You turn manuscript passages into graphic content. Reply with ONLY a "
    "JSON object, no markdown fences, no commentary. Keys: "
    "\"title\" (short, under 8 words), \"bullets\" (array of 3-5 short "
    "plain sentences drawn ONLY from the passage), \"quote\" (one exact "
    "sentence copied from the passage), \"body\" (one or two sentences "
    "summarizing the passage in the author's voice). Invent nothing."
)


# Small stopword set for the hallucination fence: the shared _STOPWORDS
# plus short function words _content_words() drops by length instead.
_FENCE_STOPWORDS = _STOPWORDS | {
    "a", "an", "in", "on", "of", "to", "it", "its", "is", "at", "by",
    "as", "be", "am", "he", "she", "we", "i", "me", "my", "his", "her",
    "him", "us", "our", "do", "does", "did", "if", "or", "so", "no",
    "nor", "per", "via",
}


def _normalize_ws(s):
    """Collapse runs of whitespace and strip (fence comparison form)."""
    return " ".join(str(s).split())


def _fence_words(s):
    """Lowercase alphabetic content words (stopwords dropped)."""
    return [w for w in re.findall(r"[a-z]+", str(s).lower())
            if w not in _FENCE_STOPWORDS]


def _is_grounded(text, passage_words):
    """True when at least half of text's content words, and at least
    two of them, actually appear in the passage's content-word set."""
    words = set(_fence_words(text))
    if not words:
        return False
    hits = words & passage_words
    return len(hits) >= 2 and len(hits) * 2 >= len(words)


def parse_ai_graphic_json(content, fallback_text, kind="Key Points Panel",
                          source_name=""):
    """Sanitize a model's reply into an analysis dict. Anything missing
    or malformed falls back to the deterministic analysis of the text.

    Hallucination fence (R5): the model's quote must be a verbatim
    sentence from the passage (whitespace-normalized, case-sensitive),
    and every bullet / the body must be grounded in the passage's
    content words. Untrusted pieces are replaced from the deterministic
    analysis; if nothing trustworthy survives, it is returned whole."""
    base = analyze_text(fallback_text, kind, source_name)
    try:
        start, end = content.find("{"), content.rfind("}")
        data = json.loads(content[start:end + 1])
    except Exception:
        return base
    if not isinstance(data, dict):
        return base
    out = dict(base)

    # Normalized verbatim sentence -> the passage's own sentence text.
    verbatim = {_normalize_ws(s): s for s in split_sentences(fallback_text)}
    passage_words = set(_fence_words(fallback_text))

    title = str(data.get("title", "")).strip()

    fenced_bullets = []
    bullets = data.get("bullets", [])
    if isinstance(bullets, list):
        clean = [str(b).strip() for b in bullets if str(b).strip()]
        fenced_bullets = [b[:200] for b in clean
                          if _is_grounded(b, passage_words)][:5]
        if fenced_bullets:
            out["bullets"] = fenced_bullets
        # else: keep base bullets (deterministic, from the passage).

    quote_accepted = False
    quote = str(data.get("quote", "")).strip()
    if 20 <= len(quote) <= 240:
        match = verbatim.get(_normalize_ws(quote))
        if match is not None:
            out["quote"] = match
            quote_accepted = True
        else:
            # Fabricated/paraphrased quote: replace it with the
            # deterministic pick, which is a verbatim passage sentence.
            out["quote"] = base["quote"]

    body_accepted = False
    body = str(data.get("body", "")).strip()
    if body and _is_grounded(body, passage_words):
        out["body"] = body[:500]
        body_accepted = True
    # else: keep base body (deterministic).

    if not fenced_bullets and not quote_accepted and not body_accepted:
        # Nothing from the model can be trusted: fall back wholesale
        # to the built-in deterministic extractor (existing pattern).
        return base

    if 0 < len(title) <= 90:
        out["title"] = title
    return out


def ai_analyze_text(text, ollama_url, model, kind="Key Points Panel",
                    source_name="", timeout=120, think_off=False):
    """Ask the editor's Ollama model to structure the passage. Raises
    RuntimeError with a plain message on any failure - callers fall
    back to analyze_text()."""
    if not model:
        raise RuntimeError("No Ollama model is selected in the main window.")
    passage = text if len(text) <= 12000 else text[:12000]
    payload = {
        "model": model,
        "stream": False,
        "messages": [
            {"role": "system", "content": _AI_SYSTEM},
            {"role": "user",
             "content": f"Graphic kind: {kind}\n\nPASSAGE:\n{passage}"},
        ],
        "options": {"temperature": 0.3},
    }
    if think_off:
        payload["think"] = False
    req = urllib.request.Request(
        ollama_url.rstrip("/") + "/api/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as e:
        raise RuntimeError(f"Ollama did not answer: {e}")
    content = (data.get("message") or {}).get("content", "")
    if not content:
        raise RuntimeError("Ollama returned an empty reply.")
    return parse_ai_graphic_json(content, text, kind, source_name)


# ----------------------------------------------------------------------
# Rendering
# ----------------------------------------------------------------------

def render_text_graphic(out_path, analysis, width_px=1425, dpi=300,
                        dark=False):
    """Render an analysis dict to a PNG at an exact pixel width, stamped
    at `dpi`. Height follows the content. Returns out_path."""
    gk._require_pil()
    from PIL import Image, ImageDraw

    kind = analysis.get("subtitle", "Key Points Panel")
    bg = (24, 24, 30) if dark else (248, 246, 239)
    ink = (240, 236, 226) if dark else (28, 26, 24)
    accent = (200, 160, 80) if dark else (122, 30, 30)
    faint = (150, 146, 138) if dark else (110, 104, 96)

    margin = max(28, int(width_px * 0.07))
    inner_w = width_px - 2 * margin
    f_title = gk._find_font(max(24, width_px // 15), bold=True)
    f_kind = gk._find_font(max(16, width_px // 44), bold=True)
    f_body = gk._find_font(max(18, width_px // 30))
    f_quote = gk._find_font(max(20, int(width_px // 25)))
    f_small = gk._find_font(max(14, width_px // 52))

    dummy = ImageDraw.Draw(Image.new("RGB", (10, 10)))

    blocks = []  # (font, text, color, gap_after_factor, centered)

    def add_wrapped(font, text, color, gap=0.7, centered=False, prefix=""):
        for line in gk._wrap(dummy, prefix + text, font, inner_w):
            blocks.append((font, line, color, 0.28, centered))

    blocks.append((f_kind, kind.upper(), accent, 0.5, False))
    add_wrapped(f_title, analysis.get("title", ""), ink, gap=0.8)
    blocks.append((f_body, "-" * 34, accent, 0.8, False))

    if kind == "Pull-Quote Card":
        add_wrapped(f_quote, "“" + analysis.get("quote", "") + "”",
                    ink, gap=0.9, centered=True)
    else:
        if analysis.get("body"):
            add_wrapped(f_body, analysis["body"], ink, gap=0.9)
        bullets = analysis.get("bullets", [])
        for i, b in enumerate(bullets):
            prefix = f"{i + 1}. " if kind == "Timeline" else "• "
            add_wrapped(f_body, b, ink, gap=0.55, prefix=prefix)
        if kind != "Pull-Quote Card" and analysis.get("quote"):
            blocks.append((f_body, "", ink, 0.4, False))
            add_wrapped(f_quote, "“" + analysis["quote"] + "”", faint,
                        gap=0.6)

    blocks.append((f_small, "", ink, 0.5, False))
    blocks.append((f_small, analysis.get("footer", ""), faint, 0.0, False))

    line_h = [f.size * (1.22 + gap) for (f, _t, _c, gap, _ct) in blocks]
    height = int(margin * 1.6 + sum(line_h) + margin * 0.9)
    min_h = int(width_px * (0.62 if kind == "Pull-Quote Card" else 0.5))
    height = max(height, min_h)

    img = Image.new("RGB", (width_px, height), bg)
    draw = ImageDraw.Draw(img)
    border_w = max(3, width_px // 340)
    draw.rectangle([border_w, border_w, width_px - border_w - 1,
                    height - border_w - 1], outline=accent, width=border_w)
    y = margin * 0.8
    for (font, line, color, gap, centered), _h in zip(blocks, line_h):
        if centered:
            w = draw.textlength(line, font=font)
            draw.text(((width_px - w) / 2, y), line, font=font, fill=color)
        else:
            draw.text((margin, y), line, font=font, fill=color)
        y += font.size * (1.22 + gap)

    if out_path.lower().endswith((".jpg", ".jpeg")):
        img.save(out_path, quality=95, dpi=(dpi, dpi))
    else:
        img.save(out_path, dpi=(dpi, dpi))
    return out_path
