"""Graphics Studio page for the Robo-Editor (KDP novel graphics).

Opened from the main window's "Graphics Studio (KDP)" button. Everything
is sized off graphics_kdp's KDP spec math, defaulting to Bob's novel
profile: 6x9 trim, cream paper, 300 DPI, the editor's mirrored margins.

Settings persist in robo_config.json under the "graphics" key via
engine.update_config_file (re-read + merge immediately before an
atomic os.replace write, and the save ABORTS if the existing config
cannot be read — Rounds 1-3, review R4/R16c — so neither window's
save can wipe or truncate the other's settings).
"""

import json
import os
import queue
import threading

import customtkinter as ctk
from tkinter import filedialog, messagebox

import graphics_art as ga
import graphics_kdp as gk
import graphics_text as gt

BG_PRESETS = {
    "Midnight": (26, 26, 34),
    "Black": (8, 8, 10),
    "Charcoal": (38, 38, 38),
    "Deep green": (18, 34, 28),
    "Burgundy": (52, 18, 24),
    "Slate blue": (24, 34, 52),
}


class GraphicsStudio(ctk.CTkToplevel):
    def __init__(self, master, config_path):
        super().__init__(master)
        self.config_path = config_path
        self.title("Graphics Studio - KDP Novel Graphics")
        _sw, _sh = self.winfo_screenwidth(), self.winfo_screenheight()
        _w, _h = min(880, _sw - 40), min(900, _sh - 80)
        self.geometry(f"{_w}x{_h}+{max(0, (_sw - _w) // 2)}+{max(0, (_sh - _h) // 3)}")
        self.minsize(680, 520)

        self.tg_full_text = ""
        self.tg_ms_path = ""
        self.tg_results = queue.Queue()
        self.tg_busy = False
        self.cover_results = queue.Queue()
        self.cover_busy = False
        self.setup_variables()
        self.load_graphics_config()
        self.setup_ui()
        self.update_spec()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    # ------------------------------------------------------------------
    def setup_variables(self):
        self.trim_var = ctk.StringVar(value="6 x 9")
        self.paper_var = ctk.StringVar(value="Cream")
        self.pages_var = ctk.StringVar(value="250")
        self.art_var = ctk.StringVar()
        self.bg_var = ctk.StringVar(value="Midnight")
        self.art_mode_var = ctk.StringVar(
            value="Auto (AI if running, else built-in)")
        self.title_var = ctk.StringVar()
        self.author_var = ctk.StringVar(value="Bob Timpone")
        self.series_var = ctk.StringVar()
        self.tagline_var = ctk.StringVar()
        self.interior_img_var = ctk.StringVar()
        self.interior_width_var = ctk.StringVar(value="Full text width")
        self.interior_gray_var = ctk.BooleanVar(value=False)
        self.p_subject_var = ctk.StringVar()
        self.p_setting_var = ctk.StringVar()
        self.p_mood_var = ctk.StringVar()
        self.p_style_var = ctk.StringVar(value="painterly, cinematic lighting")
        self.p_genre_var = ctk.StringVar(value="science fiction")
        self.tg_type_var = ctk.StringVar(value="Key Points Panel")
        self.tg_size_var = ctk.StringVar(value="Full text width")
        self.tg_dark_var = ctk.BooleanVar(value=False)
        self.tg_use_ai_var = ctk.BooleanVar(value=True)
        self.tg_query_var = ctk.StringVar()
        self.tg_ms_label_var = ctk.StringVar(
            value="No manuscript linked - paste text, load a passage, or link the editor's manuscript.")
        self.status_var = ctk.StringVar(value="Ready.")

    def setup_ui(self):
        frame = ctk.CTkScrollableFrame(self)
        frame.pack(fill="both", expand=True, padx=10, pady=10)
        frame.grid_columnconfigure(0, weight=1)

        # ---- Book spec ------------------------------------------------
        spec = ctk.CTkFrame(frame)
        spec.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        spec.grid_columnconfigure(1, weight=1)
        spec.grid_columnconfigure(3, weight=1)
        ctk.CTkLabel(spec, text="Book Spec (KDP defaults)",
                     font=ctk.CTkFont(weight="bold")).grid(
            row=0, column=0, padx=10, pady=10, sticky="w")
        ctk.CTkLabel(spec, text="Trim:").grid(row=1, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(spec, variable=self.trim_var,
                          values=list(gk.TRIM_SIZES),
                          command=lambda _: self.update_spec()).grid(
            row=1, column=1, padx=10, pady=5, sticky="ew")
        ctk.CTkLabel(spec, text="Paper:").grid(row=1, column=2, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(spec, variable=self.paper_var,
                          values=list(gk.PAPER_SPINE_PER_PAGE),
                          command=lambda _: self.update_spec()).grid(
            row=1, column=3, padx=10, pady=5, sticky="ew")
        ctk.CTkLabel(spec, text="Page count:").grid(row=2, column=0, padx=10, pady=5, sticky="w")
        pages_entry = ctk.CTkEntry(spec, textvariable=self.pages_var)
        pages_entry.grid(row=2, column=1, padx=10, pady=5, sticky="ew")
        pages_entry.bind("<KeyRelease>", lambda _: self.update_spec())
        ctk.CTkLabel(spec, text="(final count from your formatted interior)").grid(
            row=2, column=2, columnspan=2, padx=10, pady=5, sticky="w")
        self.spec_label = ctk.CTkLabel(spec, text="", justify="left", anchor="w")
        self.spec_label.grid(row=3, column=0, columnspan=4, padx=10, pady=5, sticky="w")
        ctk.CTkButton(spec, text="Copy Spec Brief", command=self.copy_brief).grid(
            row=4, column=0, columnspan=4, padx=10, pady=(0, 10), sticky="ew")

        # ---- Cover builder ---------------------------------------------
        cov = ctk.CTkFrame(frame)
        cov.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        cov.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(cov, text="Cover Builder",
                     font=ctk.CTkFont(weight="bold")).grid(
            row=0, column=0, padx=10, pady=10, sticky="w")
        rows = [
            ("Art file (opt.):", self.art_var, "browse_art"),
            ("Title:", self.title_var, None),
            ("Author:", self.author_var, None),
            ("Series line:", self.series_var, None),
            ("Tagline:", self.tagline_var, None),
        ]
        for i, (label, var, browse) in enumerate(rows, start=1):
            ctk.CTkLabel(cov, text=label).grid(row=i, column=0, padx=10, pady=4, sticky="w")
            ctk.CTkEntry(cov, textvariable=var).grid(row=i, column=1, padx=10, pady=4, sticky="ew")
            if browse:
                ctk.CTkButton(cov, text="Browse...", width=100,
                              command=getattr(self, browse)).grid(
                    row=i, column=2, padx=10, pady=4)
        ctk.CTkLabel(cov, text="Background:").grid(row=6, column=0, padx=10, pady=4, sticky="w")
        ctk.CTkOptionMenu(cov, variable=self.bg_var, values=list(BG_PRESETS)).grid(
            row=6, column=1, padx=10, pady=4, sticky="ew")
        ctk.CTkLabel(cov, text="(solid fallback color)").grid(
            row=6, column=2, padx=10, pady=4, sticky="w")
        ctk.CTkLabel(cov, text="Artwork:").grid(row=7, column=0, padx=10, pady=4, sticky="w")
        ctk.CTkOptionMenu(
            cov, variable=self.art_mode_var,
            values=["Auto (AI if running, else built-in)",
                    "Built-in generated art", "Art file",
                    "Solid background"]).grid(
            row=7, column=1, padx=10, pady=4, sticky="ew")
        ctk.CTkLabel(cov, text="(Auto uses a local Stable Diffusion server if one is running)").grid(
            row=7, column=2, padx=10, pady=4, sticky="w")
        ctk.CTkLabel(cov, text="Back blurb:").grid(row=8, column=0, padx=10, pady=4, sticky="nw")
        self.blurb_box = ctk.CTkTextbox(cov, height=90)
        self.blurb_box.grid(row=8, column=1, columnspan=2, padx=10, pady=4, sticky="ew")
        btns = ctk.CTkFrame(cov, fg_color="transparent")
        btns.grid(row=9, column=0, columnspan=3, padx=10, pady=(4, 10), sticky="ew")
        btns.grid_columnconfigure(0, weight=1)
        btns.grid_columnconfigure(1, weight=1)
        self.wrap_btn = ctk.CTkButton(btns, text="Build Print Cover Wrap (PNG, 300 DPI)",
                      fg_color="#2ecc71", hover_color="#27ae60",
                      command=self.build_wrap)
        self.wrap_btn.grid(row=0, column=0, padx=(0, 5), sticky="ew")
        self.ebook_btn = ctk.CTkButton(btns, text="Build Ebook Cover (JPG, 1600x2560)",
                      fg_color="#2ecc71", hover_color="#27ae60",
                      command=self.build_ebook)
        self.ebook_btn.grid(row=0, column=1, padx=(5, 0), sticky="ew")

        # ---- Interior graphics ------------------------------------------
        inter = ctk.CTkFrame(frame)
        inter.grid(row=2, column=0, sticky="ew", pady=(0, 10))
        inter.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(inter, text="Interior Graphics",
                     font=ctk.CTkFont(weight="bold")).grid(
            row=0, column=0, padx=10, pady=10, sticky="w")
        ctk.CTkLabel(inter, text="Image:").grid(row=1, column=0, padx=10, pady=4, sticky="w")
        ctk.CTkEntry(inter, textvariable=self.interior_img_var).grid(
            row=1, column=1, padx=10, pady=4, sticky="ew")
        ctk.CTkButton(inter, text="Browse...", width=100,
                      command=self.browse_interior).grid(row=1, column=2, padx=10, pady=4)
        self.interior_label = ctk.CTkLabel(inter, text="", justify="left", anchor="w")
        self.interior_label.grid(row=2, column=0, columnspan=3, padx=10, pady=4, sticky="w")
        ctk.CTkLabel(inter, text="Target width:").grid(row=3, column=0, padx=10, pady=4, sticky="w")
        ctk.CTkOptionMenu(inter, variable=self.interior_width_var,
                          values=["Full text width", "Half page"]).grid(
            row=3, column=1, padx=10, pady=4, sticky="ew")
        ctk.CTkCheckBox(inter, text="Grayscale", variable=self.interior_gray_var).grid(
            row=3, column=2, padx=10, pady=4, sticky="w")
        ctk.CTkButton(inter, text="Prep Print-Ready Copy (300 DPI)",
                      command=self.prep_interior).grid(
            row=4, column=0, columnspan=3, padx=10, pady=(4, 10), sticky="ew")

        # ---- AI art prompt ------------------------------------------------
        pr = ctk.CTkFrame(frame)
        pr.grid(row=3, column=0, sticky="ew", pady=(0, 10))
        pr.grid_columnconfigure(1, weight=1)
        pr.grid_columnconfigure(3, weight=1)
        ctk.CTkLabel(pr, text="Cover Art Prompt (for an image generator)",
                     font=ctk.CTkFont(weight="bold")).grid(
            row=0, column=0, padx=10, pady=10, sticky="w")
        fields = [
            ("Subject:", self.p_subject_var, "Setting:", self.p_setting_var),
            ("Mood:", self.p_mood_var, "Genre:", self.p_genre_var),
            ("Style:", self.p_style_var, None, None),
        ]
        for i, (l1, v1, l2, v2) in enumerate(fields, start=1):
            ctk.CTkLabel(pr, text=l1).grid(row=i, column=0, padx=10, pady=4, sticky="w")
            ctk.CTkEntry(pr, textvariable=v1).grid(row=i, column=1, padx=10, pady=4, sticky="ew")
            if l2:
                ctk.CTkLabel(pr, text=l2).grid(row=i, column=2, padx=10, pady=4, sticky="w")
                ctk.CTkEntry(pr, textvariable=v2).grid(row=i, column=3, padx=10, pady=4, sticky="ew")
        self.prompt_box = ctk.CTkTextbox(pr, height=110)
        self.prompt_box.grid(row=4, column=0, columnspan=4, padx=10, pady=4, sticky="ew")
        pb = ctk.CTkFrame(pr, fg_color="transparent")
        pb.grid(row=5, column=0, columnspan=4, padx=10, pady=(4, 10), sticky="ew")
        pb.grid_columnconfigure(0, weight=1)
        pb.grid_columnconfigure(1, weight=1)
        ctk.CTkButton(pb, text="Build Prompt", command=self.build_prompt).grid(
            row=0, column=0, padx=(0, 5), sticky="ew")
        ctk.CTkButton(pb, text="Copy Prompt", command=self.copy_prompt).grid(
            row=0, column=1, padx=(5, 0), sticky="ew")

        # ---- Text to graphic ----------------------------------------------
        tg = ctk.CTkFrame(frame)
        tg.grid(row=4, column=0, sticky="ew", pady=(0, 10))
        tg.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(tg, text="Text to Graphic (manuscript -> KDP graphic)",
                     font=ctk.CTkFont(weight="bold")).grid(
            row=0, column=0, padx=10, pady=10, sticky="w")
        src_btns = ctk.CTkFrame(tg, fg_color="transparent")
        src_btns.grid(row=1, column=0, columnspan=3, padx=10, pady=4, sticky="ew")
        for i in range(4):
            src_btns.grid_columnconfigure(i, weight=1)
        ctk.CTkButton(src_btns, text="Paste Text", command=self.tg_paste).grid(
            row=0, column=0, padx=(0, 5), sticky="ew")
        ctk.CTkButton(src_btns, text="Load Passage (.docx/.txt)",
                      command=self.tg_load_passage).grid(
            row=0, column=1, padx=5, sticky="ew")
        ctk.CTkButton(src_btns, text="Use Editor's Manuscript",
                      command=self.tg_use_editor_manuscript).grid(
            row=0, column=2, padx=5, sticky="ew")
        ctk.CTkButton(src_btns, text="Clear",
                      command=lambda: self.tg_set_passage("")).grid(
            row=0, column=3, padx=(5, 0), sticky="ew")
        ctk.CTkLabel(tg, textvariable=self.tg_ms_label_var, justify="left",
                     anchor="w").grid(row=2, column=0, columnspan=3, padx=10,
                                      pady=4, sticky="w")
        ctk.CTkLabel(tg, text="Find in manuscript:").grid(
            row=3, column=0, padx=10, pady=4, sticky="w")
        ctk.CTkEntry(tg, textvariable=self.tg_query_var,
                     placeholder_text="a name, a place, a phrase...").grid(
            row=3, column=1, padx=10, pady=4, sticky="ew")
        ctk.CTkButton(tg, text="Pull Passage", width=110,
                      command=self.tg_pull_context).grid(
            row=3, column=2, padx=10, pady=4)
        ctk.CTkLabel(tg, text="Passage:").grid(row=4, column=0, padx=10, pady=4, sticky="nw")
        self.tg_box = ctk.CTkTextbox(tg, height=110)
        self.tg_box.grid(row=4, column=1, columnspan=2, padx=10, pady=4, sticky="ew")
        ctk.CTkLabel(tg, text="Graphic:").grid(row=5, column=0, padx=10, pady=4, sticky="w")
        tg_opts = ctk.CTkFrame(tg, fg_color="transparent")
        tg_opts.grid(row=5, column=1, columnspan=2, padx=10, pady=4, sticky="ew")
        tg_opts.grid_columnconfigure(0, weight=1)
        tg_opts.grid_columnconfigure(1, weight=1)
        ctk.CTkOptionMenu(tg_opts, variable=self.tg_type_var,
                          values=gt.GRAPHIC_KINDS).grid(
            row=0, column=0, padx=(0, 5), pady=2, sticky="ew")
        ctk.CTkOptionMenu(tg_opts, variable=self.tg_size_var,
                          values=["Full text width", "Half page",
                                  "Front-cover width"]).grid(
            row=0, column=1, padx=(5, 0), pady=2, sticky="ew")
        ctk.CTkCheckBox(tg_opts, text="Dark panel (screen/promo)",
                        variable=self.tg_dark_var).grid(
            row=1, column=0, padx=0, pady=2, sticky="w")
        ctk.CTkCheckBox(tg_opts, text="Use Ollama model to shape it",
                        variable=self.tg_use_ai_var).grid(
            row=1, column=1, padx=0, pady=2, sticky="w")
        self.tg_generate_btn = ctk.CTkButton(
            tg, text="Generate Graphic (PNG, 300 DPI)",
            fg_color="#8e44ad", hover_color="#71368a",
            command=self.tg_generate)
        self.tg_generate_btn.grid(row=6, column=0, columnspan=3, padx=10,
                                  pady=(4, 10), sticky="ew")

        ctk.CTkLabel(self, textvariable=self.status_var, text_color="gray").pack(
            side="bottom", anchor="w", padx=20, pady=(0, 10))

    # ------------------------------------------------------------------
    def current_spec(self):
        trim_w, trim_h = gk.TRIM_SIZES[self.trim_var.get()]
        pages = int(self.pages_var.get() or 0)
        spec = gk.cover_spec(trim_w, trim_h, pages, self.paper_var.get())
        interior = gk.interior_spec(trim_w)
        return spec, interior

    def update_spec(self):
        try:
            spec, interior = self.current_spec()
        except Exception as e:
            self.spec_label.configure(text=f"Spec: {e}")
            return
        text = (f"Spine: {spec['spine_in']}\"  |  Full wrap: {spec['wrap_w_in']} x "
                f"{spec['wrap_h_in']} in = {spec['wrap_w_px']} x {spec['wrap_h_px']} px "
                f"@ {spec['dpi']} DPI  |  Ebook: {spec['ebook_w_px']} x {spec['ebook_h_px']} px\n"
                f"Interior images: full width {interior['full_width_px']} px, "
                f"half page {interior['half_width_px']} px "
                f"({interior['text_width_in']}\" text width)")
        if spec["warnings"]:
            text += "\n" + " ".join("⚠ " + w for w in spec["warnings"])
        self.spec_label.configure(text=text)

    def slug(self):
        s = "".join(c if c.isalnum() else "-" for c in self.title_var.get().lower())
        return "-".join(p for p in s.split("-") if p) or "book"

    def copy_brief(self):
        try:
            spec, interior = self.current_spec()
        except Exception as e:
            messagebox.showerror("Graphics Studio", str(e), parent=self)
            return
        brief = gk.spec_brief(spec, interior, self.title_var.get(),
                              self.author_var.get())
        self.clipboard_clear()
        self.clipboard_append(brief)
        self.status_var.set("Spec brief copied to the clipboard.")

    # ---- cover builds ---------------------------------------------------
    def browse_art(self):
        fn = filedialog.askopenfilename(
            parent=self, filetypes=[("Images", "*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.bmp"),
                                    ("All Files", "*.*")])
        if fn:
            self.art_var.set(fn)

    def _cover_text_kwargs(self):
        return dict(
            bg_color=BG_PRESETS[self.bg_var.get()],
            title=self.title_var.get(), author=self.author_var.get(),
            series=self.series_var.get(), tagline=self.tagline_var.get(),
            blurb=self.blurb_box.get("1.0", "end").strip(),
        )

    def _art_seed_and_prompt(self, spec=None):
        subject = self.p_subject_var.get().strip() \
            or self.title_var.get().strip() or "a lone figure on a ridge"
        seed = " ".join(x for x in [self.title_var.get(),
                                    self.p_subject_var.get(),
                                    self.p_setting_var.get(),
                                    self.tagline_var.get()] if x)
        composed = gk.compose_art_prompt(
            subject, self.p_setting_var.get(), self.p_mood_var.get(),
            self.p_style_var.get(), self.p_genre_var.get(), spec=spec)
        prompt = composed.split("PROMPT:\n", 1)[1].split(
            "\n\nNEGATIVE PROMPT:")[0].strip()
        negative = composed.split("NEGATIVE PROMPT:\n", 1)[1].strip() \
            if "NEGATIVE PROMPT:" in composed else ""
        return seed, prompt, negative

    def _capture_cover_art(self, spec=None):
        """Read every Tk value the cover build needs. MUST run on the
        main thread: Tk variables and widgets are not thread-safe, and
        reading them from the build worker can deadlock the app (the
        S13 rule - capture plain values first, then start the thread)."""
        seed, prompt, negative = self._art_seed_and_prompt(spec)
        return {
            "mode": self.art_mode_var.get(),
            "art_file": self.art_var.get() or None,
            "seed": seed, "prompt": prompt, "negative": negative,
            "genre": self.p_genre_var.get(), "mood": self.p_mood_var.get(),
        }

    def _resolve_cover_art(self, canvas_w, canvas_h, hero_x_frac, art):
        """Worker-thread artwork resolution over pre-captured plain
        values (see _capture_cover_art). Returns (art_image, art_path,
        note). Exactly one of art_image/art_path is set, or both None
        for a solid background."""
        mode = art["mode"]
        art_file = art["art_file"]
        if mode == "Art file":
            return None, art_file, "your art file"
        if mode == "Solid background":
            return None, None, "solid background"
        seed, prompt, negative = art["seed"], art["prompt"], art["negative"]
        genre, mood = art["genre"], art["mood"]
        if mode.startswith("Auto"):
            if art_file:
                return None, art_file, "your art file"
            if ga.sd_available():
                try:
                    w, h = ga.sd_size_for(canvas_w, canvas_h)
                    img = ga.sd_txt2img(prompt, negative, w, h)
                    return img, None, "Stable Diffusion (local server)"
                except Exception:
                    pass  # fall through to the built-in engine
            img = ga.generate_art_image(canvas_w, canvas_h, seed,
                                        genre=genre, mood=mood,
                                        hero_x_frac=hero_x_frac)
            return img, None, "built-in art engine (no SD server found)"
        # Built-in generated art
        img = ga.generate_art_image(canvas_w, canvas_h, seed,
                                    genre=genre, mood=mood,
                                    hero_x_frac=hero_x_frac)
        return img, None, "built-in art engine"

    def _launch_cover_build(self, out, is_wrap, spec):
        if self.cover_busy:
            return
        self.cover_busy = True
        self.wrap_btn.configure(state="disabled")
        self.ebook_btn.configure(state="disabled")
        self.status_var.set(
            "Generating artwork and building the cover - "
            "a local Stable Diffusion can take a minute...")
        text_kw = self._cover_text_kwargs()
        art = self._capture_cover_art(spec)

        def work():
            # Worker thread: no Tk calls; results via the queue.
            try:
                if is_wrap:
                    hero = (spec["front_x0_in"] + spec["trim_w_in"] / 2) \
                        / spec["wrap_w_in"]
                    img, path, note = self._resolve_cover_art(
                        spec["wrap_w_px"], spec["wrap_h_px"], hero, art)
                    gk.build_print_cover(out, spec, art_path=path,
                                         art_image=img, **text_kw)
                else:
                    img, path, note = self._resolve_cover_art(
                        gk.EBOOK_W_PX, gk.EBOOK_H_PX, 0.5, art)
                    kw = dict(text_kw)
                    kw.pop("tagline", None)
                    kw.pop("blurb", None)
                    gk.build_ebook_cover(out, art_path=path,
                                         art_image=img, **kw)
                self.cover_results.put(
                    (f"Saved {out} (artwork: {note}).", None))
            except Exception as e:
                self.cover_results.put(("", e))

        threading.Thread(target=work, daemon=True).start()
        self.after(150, self._cover_poll)

    def _cover_poll(self):
        try:
            msg, err = self.cover_results.get_nowait()
        except queue.Empty:
            if self.cover_busy:
                self.after(150, self._cover_poll)
            return
        self.cover_busy = False
        self.wrap_btn.configure(state="normal")
        self.ebook_btn.configure(state="normal")
        if err is not None:
            messagebox.showerror("Graphics Studio", str(err), parent=self)
        else:
            self.status_var.set(msg)
            self.save_graphics_config()

    def build_wrap(self):
        try:
            spec, _ = self.current_spec()
        except Exception as e:
            messagebox.showerror("Graphics Studio", str(e), parent=self)
            return
        out = filedialog.asksaveasfilename(
            parent=self, defaultextension=".png",
            initialfile=f"{self.slug()}-cover-wrap-300dpi.png",
            filetypes=[("PNG", "*.png")])
        if out:
            self._launch_cover_build(out, True, spec)

    def build_ebook(self):
        try:
            spec, _ = self.current_spec()
        except Exception:
            spec = None
        out = filedialog.asksaveasfilename(
            parent=self, defaultextension=".jpg",
            initialfile=f"{self.slug()}-ebook-cover.jpg",
            filetypes=[("JPEG", "*.jpg")])
        if out:
            self._launch_cover_build(out, False, spec)

    # ---- interior ---------------------------------------------------------
    def browse_interior(self):
        fn = filedialog.askopenfilename(
            parent=self, filetypes=[("Images", "*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.bmp"),
                                    ("All Files", "*.*")])
        if fn:
            self.interior_img_var.set(fn)
            try:
                info = gk.inspect_image(fn)
                self.interior_label.configure(text=(
                    f"{info['format']} {info['mode']} - {info['width_px']} x "
                    f"{info['height_px']} px, stored DPI: {info['dpi_x']} x {info['dpi_y']}\n"
                    f"Prints {info['print_width_at_300dpi_in']}\" wide at 300 DPI."))
            except Exception as e:
                self.interior_label.configure(text=f"Could not read image: {e}")

    def prep_interior(self):
        src = self.interior_img_var.get()
        if not src or not os.path.exists(src):
            messagebox.showerror("Graphics Studio", "Pick an interior image first.",
                                 parent=self)
            return
        try:
            _, interior = self.current_spec()
            width = (interior["full_width_px"]
                     if self.interior_width_var.get().startswith("Full")
                     else interior["half_width_px"])
            base, _ = os.path.splitext(src)
            out = filedialog.asksaveasfilename(
                parent=self, defaultextension=".png",
                initialfile=os.path.basename(base) + "-kdp-300dpi.png",
                filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg")])
            if not out:
                return
            gk.prep_interior_image(src, out, width,
                                   grayscale=self.interior_gray_var.get())
            info = gk.inspect_image(out)
            self.status_var.set(
                f"Saved {out} - {info['width_px']} x {info['height_px']} px @ 300 DPI.")
            self.save_graphics_config()
        except Exception as e:
            messagebox.showerror("Graphics Studio", str(e), parent=self)

    # ---- art prompt ---------------------------------------------------------
    def build_prompt(self):
        try:
            spec, _ = self.current_spec()
        except Exception:
            spec = None
        text = gk.compose_art_prompt(
            self.p_subject_var.get(), self.p_setting_var.get(),
            self.p_mood_var.get(), self.p_style_var.get(),
            self.p_genre_var.get(), spec=spec)
        self.prompt_box.delete("1.0", "end")
        self.prompt_box.insert("1.0", text)

    def copy_prompt(self):
        text = self.prompt_box.get("1.0", "end").strip()
        if not text:
            self.build_prompt()
            text = self.prompt_box.get("1.0", "end").strip()
        self.clipboard_clear()
        self.clipboard_append(text)
        self.status_var.set("Art prompt copied to the clipboard.")

    # ---- text to graphic -------------------------------------------------
    def tg_set_passage(self, text):
        self.tg_box.delete("1.0", "end")
        if text:
            self.tg_box.insert("1.0", text)
            self.status_var.set(f"Passage ready: {len(text.split())} words.")

    def tg_paste(self):
        try:
            text = self.clipboard_get()
        except Exception:
            text = ""
        if text and text.strip():
            self.tg_set_passage(text)
        else:
            messagebox.showinfo("Text to Graphic",
                                "The clipboard is empty.", parent=self)

    def tg_load_passage(self):
        fn = filedialog.askopenfilename(
            parent=self,
            filetypes=[("Manuscripts", "*.docx;*.txt;*.md"),
                       ("All Files", "*.*")])
        if not fn:
            return
        try:
            text = gt.extract_text_from_file(fn)
        except Exception as e:
            messagebox.showerror("Text to Graphic", str(e), parent=self)
            return
        if len(text) > 40000:
            text = text[:40000]
            self.status_var.set(
                "Loaded the first 40,000 characters - for a sharper graphic, "
                "load just the passage you want.")
        self.tg_set_passage(text)

    def tg_use_editor_manuscript(self):
        path = ""
        try:
            path = self.master.input_var.get()
        except Exception:
            path = ""
        if not path or not os.path.exists(path):
            messagebox.showerror(
                "Text to Graphic",
                "The main window has no manuscript input file set. Set one "
                "there first, or use Load Passage.", parent=self)
            return
        try:
            self.tg_full_text = gt.extract_text_from_file(path)
        except Exception as e:
            messagebox.showerror("Text to Graphic", str(e), parent=self)
            return
        self.tg_ms_path = path
        self.tg_ms_label_var.set(
            f"Manuscript: {os.path.basename(path)} "
            f"({len(self.tg_full_text.split())} words). Pull a passage by "
            "search, or Generate straight from the opening.")
        self.status_var.set("Manuscript linked.")

    def tg_pull_context(self):
        source = self.tg_full_text or self.tg_box.get("1.0", "end")
        try:
            ctx = gt.find_text_context(source, self.tg_query_var.get(),
                                       neighbors=1)
        except Exception as e:
            messagebox.showerror("Text to Graphic", str(e), parent=self)
            return
        self.tg_set_passage(ctx)

    def tg_generate(self):
        passage = self.tg_box.get("1.0", "end").strip()
        if not passage and self.tg_full_text:
            passage = self.tg_full_text[:3000]
        if not passage:
            messagebox.showerror(
                "Text to Graphic",
                "Add some manuscript text first - paste it, load a passage, "
                "or link the editor's manuscript.", parent=self)
            return
        kind = self.tg_type_var.get()
        try:
            spec, interior = self.current_spec()
        except Exception as e:
            messagebox.showerror("Text to Graphic", str(e), parent=self)
            return
        size = self.tg_size_var.get()
        if size.startswith("Full"):
            width = interior["full_width_px"]
        elif size.startswith("Half"):
            width = interior["half_width_px"]
        else:
            width = spec["front_w_px"]
        out = filedialog.asksaveasfilename(
            parent=self, defaultextension=".png",
            initialfile=f"{self.slug()}-{kind.lower().replace(' ', '-')}.png",
            filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg")])
        if not out:
            return
        source_name = (os.path.basename(self.tg_ms_path) if self.tg_ms_path
                       else (self.title_var.get() or "Manuscript passage"))
        use_ai = self.tg_use_ai_var.get()
        dark = self.tg_dark_var.get()
        model, url, think_off = "", "http://localhost:11434", False
        try:
            model = self.master.model_var.get()
        except Exception:
            pass
        try:
            url = self.master.engine.ollama_url
        except Exception:
            pass
        try:
            think_off = bool(self.master.no_think_var.get())
        except Exception:
            pass
        self.tg_generate_btn.configure(state="disabled")
        self.status_var.set("Building your graphic...")
        self.tg_busy = True

        def work():
            # Worker thread: NO Tk calls here (Tk is not thread-safe).
            # Results travel back through a queue that the main thread
            # polls - the same rule the editor's S13 round enforced.
            note = "built-in extractor"
            try:
                if use_ai:
                    try:
                        analysis = gt.ai_analyze_text(
                            passage, url, model, kind,
                            source_name=source_name, think_off=think_off)
                        note = f"Ollama ({model})"
                    except Exception as e:
                        analysis = gt.analyze_text(passage, kind, source_name)
                        note = f"built-in extractor (Ollama unavailable: {e})"
                else:
                    analysis = gt.analyze_text(passage, kind, source_name)
                gt.render_text_graphic(out, analysis, width_px=width,
                                       dark=dark)
                info = gk.inspect_image(out)
                msg = (f"Saved {out} - {info['width_px']} x "
                       f"{info['height_px']} px @ 300 DPI ({note}). "
                       f"Title: {analysis['title']}")
                self.tg_results.put((msg, None))
            except Exception as e:
                self.tg_results.put(("", e))

        threading.Thread(target=work, daemon=True).start()
        self.after(150, self._tg_poll)

    def _tg_poll(self):
        try:
            msg, err = self.tg_results.get_nowait()
        except queue.Empty:
            if self.tg_busy:
                self.after(150, self._tg_poll)
            return
        self._tg_done(msg, err)

    def _tg_done(self, msg, err):
        self.tg_busy = False
        try:
            self.tg_generate_btn.configure(state="normal")
        except Exception:
            pass
        if err is not None:
            messagebox.showerror("Text to Graphic", str(err), parent=self)
        else:
            self.status_var.set(msg)

    # ---- persistence ---------------------------------------------------------
    def save_graphics_config(self):
        # Rounds 1-3 (review R16c): the old code read the config, and
        # on ANY read failure fell back to {} and then rewrote the
        # whole file containing only the "graphics" key — wiping every
        # editor setting. The shared helper aborts in that case and
        # writes atomically; a failure is surfaced on the status line
        # instead of a bare except: pass.
        graphics = {
            "trim": self.trim_var.get(), "paper": self.paper_var.get(),
            "pages": self.pages_var.get(), "art": self.art_var.get(),
            "bg": self.bg_var.get(), "art_mode": self.art_mode_var.get(),
            "title": self.title_var.get(),
            "author": self.author_var.get(), "series": self.series_var.get(),
            "tagline": self.tagline_var.get(),
        }
        try:
            from engine import update_config_file
            ok, err = update_config_file(self.config_path, {"graphics": graphics})
        except Exception as e:
            ok, err = False, str(e)
        if not ok:
            try:
                self.status_var.set(f"Warning: graphics settings not saved — {err}")
            except Exception:
                pass

    def load_graphics_config(self):
        if not os.path.exists(self.config_path):
            return
        try:
            with open(self.config_path) as f:
                g = json.load(f).get("graphics", {})
        except Exception:
            return
        if not g:
            return
        self.trim_var.set(g.get("trim", self.trim_var.get()))
        self.paper_var.set(g.get("paper", self.paper_var.get()))
        self.pages_var.set(g.get("pages", self.pages_var.get()))
        self.art_var.set(g.get("art", ""))
        self.bg_var.set(g.get("bg", self.bg_var.get()))
        self.art_mode_var.set(g.get("art_mode", self.art_mode_var.get()))
        self.title_var.set(g.get("title", ""))
        self.author_var.set(g.get("author", self.author_var.get()))
        self.series_var.set(g.get("series", ""))
        self.tagline_var.set(g.get("tagline", ""))

    def on_close(self):
        # Close-while-busy guard (Rounds 1-3, review R33): destroying
        # the window with a cover/Text-to-Graphic build in flight
        # orphaned its result-queue poll chain. Ask first when busy.
        if self.tg_busy or self.cover_busy:
            if not messagebox.askyesno(
                    "Build in progress",
                    "A graphics build is still running.\n\nClose anyway? "
                    "The in-flight build will be abandoned.",
                    parent=self):
                return
        self.save_graphics_config()
        self.destroy()
