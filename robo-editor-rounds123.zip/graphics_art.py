"""Artwork generation for the Graphics Studio.

Bob's report on the first build was fair: the cover builder only
composited text over an art file or a flat color - it did not
*generate* anything. This module is the fix, two engines deep:

1. Built-in procedural art (always available, offline): layered,
   PIL-drawn illustration - gradient sky, celestial body, terrain
   silhouettes, a hero shape chosen from the words of the title /
   prompt (drop pod, starship, tower, skyline, forest, sea), grain
   and vignette. Deterministic: the same seed text always paints the
   same picture, so a series can share a look.

2. Local Stable Diffusion (optional, much stronger): if an
   AUTOMATIC1111 server is running on this machine (default
   http://127.0.0.1:7860), sd_txt2img() sends the prompt to it and
   returns the generated image. Nothing leaves the computer.

Ollama is not involved in either engine - its models write words,
not pictures.
"""

import base64
import hashlib
import io
import json
import math
import random
import urllib.error
import urllib.request

DEFAULT_SD_URL = "http://127.0.0.1:7860"

_PALETTES = {
    # sky_top, sky_mid, ground_far, ground_near, accent, celestial
    "science fiction": ((16, 22, 38), (58, 74, 96), (38, 46, 58), (16, 18, 24), (232, 116, 44), (214, 222, 235)),
    "fantasy": ((24, 34, 30), (74, 96, 74), (44, 58, 44), (18, 26, 20), (216, 178, 92), (226, 230, 200)),
    "horror": ((14, 12, 16), (52, 44, 52), (34, 28, 34), (12, 10, 14), (168, 44, 44), (206, 200, 190)),
    "romance": ((52, 30, 44), (148, 84, 96), (84, 52, 62), (36, 20, 30), (236, 168, 152), (240, 226, 210)),
    "thriller": ((18, 20, 26), (66, 72, 84), (40, 44, 52), (14, 16, 20), (96, 168, 220), (214, 222, 235)),
    "default": ((18, 24, 40), (66, 78, 102), (40, 48, 62), (16, 19, 26), (220, 150, 70), (216, 224, 238)),
}


def _rng(seed_text):
    digest = hashlib.sha256(seed_text.encode("utf-8")).digest()
    return random.Random(int.from_bytes(digest[:8], "big"))


def _lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def _gradient(width, height, top, mid):
    from PIL import Image
    steps = 256
    strip = Image.new("RGB", (1, steps))
    px = strip.load()
    for i in range(steps):
        t = i / (steps - 1)
        c = _lerp(top, mid, t)
        px[0, i] = c
    return strip.resize((width, height))


def _ridge(rng, width, base_y, amp):
    pts = []
    n = rng.randint(6, 10)
    for i in range(n + 1):
        x = int(width * i / n)
        y = base_y + rng.randint(-amp, amp)
        pts.append((x, y))
    pts.append((width, base_y + amp * 3))
    pts.append((0, base_y + amp * 3))
    return pts


def _hero(draw, kind, cx, ground_y, scale, dark, accent, rng):
    """Draw the hero silhouette centered near cx, standing on ground_y."""
    s = scale
    if kind == "pod":
        w, h = int(150 * s), int(210 * s)
        x0, y0 = cx - w // 2, ground_y - h
        draw.rounded_rectangle([x0, y0, x0 + w, y0 + h],
                               radius=int(60 * s), fill=dark)
        draw.ellipse([cx - int(26 * s), y0 + int(52 * s),
                      cx + int(26 * s), y0 + int(104 * s)], fill=accent)
        draw.polygon([(x0, ground_y), (x0 - int(46 * s), ground_y),
                      (x0 + int(30 * s), ground_y - int(60 * s))], fill=dark)
        draw.polygon([(x0 + w, ground_y), (x0 + w + int(46 * s), ground_y),
                      (x0 + w - int(30 * s), ground_y - int(60 * s))], fill=dark)
        # scorch glow
        draw.ellipse([cx - int(120 * s), ground_y - int(14 * s),
                      cx + int(120 * s), ground_y + int(16 * s)], fill=accent)
    elif kind == "ship":
        top_y = ground_y - int(430 * s)
        draw.polygon([(cx, top_y), (cx - int(54 * s), ground_y - int(120 * s)),
                      (cx + int(54 * s), ground_y - int(120 * s))], fill=dark)
        draw.polygon([(cx - int(54 * s), ground_y - int(120 * s)),
                      (cx - int(120 * s), ground_y - int(40 * s)),
                      (cx - int(40 * s), ground_y - int(60 * s))], fill=dark)
        draw.polygon([(cx + int(54 * s), ground_y - int(120 * s)),
                      (cx + int(120 * s), ground_y - int(40 * s)),
                      (cx + int(40 * s), ground_y - int(60 * s))], fill=dark)
        draw.polygon([(cx - int(22 * s), ground_y - int(110 * s)),
                      (cx + int(22 * s), ground_y - int(110 * s)),
                      (cx, ground_y + int(60 * s))], fill=accent)
    elif kind == "tower":
        w, h = int(120 * s), int(330 * s)
        x0, y0 = cx - w // 2, ground_y - h
        draw.rectangle([x0, y0, x0 + w, ground_y], fill=dark)
        for bx in (-1, 1):
            tw = int(34 * s)
            tx = cx + bx * int(70 * s) - tw // 2
            draw.rectangle([tx, y0 + int(60 * s), tx + tw, ground_y], fill=dark)
            draw.polygon([(tx - 4, y0 + int(60 * s)), (tx + tw + 4, y0 + int(60 * s)),
                          (tx + tw // 2, y0 + int(24 * s))], fill=dark)
        draw.polygon([(x0 - 6, y0), (x0 + w + 6, y0), (cx, y0 - int(44 * s))], fill=dark)
        for i in range(4):
            for jx in (-1, 0, 1):
                wx = cx + jx * int(30 * s)
                wy = y0 + int(70 * s) + i * int(58 * s)
                draw.rectangle([wx - 5, wy, wx + 5, wy + int(16 * s)], fill=accent)
    elif kind == "city":
        x = cx - int(330 * s)
        while x < cx + int(330 * s):
            bw = rng.randint(int(50 * s), int(95 * s))
            bh = rng.randint(int(110 * s), int(300 * s))
            draw.rectangle([x, ground_y - bh, x + bw, ground_y], fill=dark)
            for _ in range(rng.randint(2, 6)):
                wx = x + rng.randint(6, max(7, bw - 12))
                wy = ground_y - bh + rng.randint(8, max(9, bh - 18))
                draw.rectangle([wx, wy, wx + 5, wy + 7], fill=accent)
            x += bw + rng.randint(4, 16)
    elif kind == "forest":
        for i in range(11):
            tx = cx - int(300 * s) + i * int(60 * s) + rng.randint(-8, 8)
            th = rng.randint(int(120 * s), int(230 * s))
            draw.polygon([(tx - int(34 * s), ground_y), (tx + int(34 * s), ground_y),
                          (tx, ground_y - th)], fill=dark)
            draw.rectangle([tx - int(5 * s), ground_y - int(30 * s),
                            tx + int(5 * s), ground_y], fill=dark)
    elif kind == "figure":
        # A lone traveler on the ridge: head, cloak, staff.
        hy = ground_y - int(150 * s)
        draw.ellipse([cx - int(17 * s), hy, cx + int(17 * s), hy + int(34 * s)], fill=dark)
        draw.polygon([(cx - int(30 * s), ground_y), (cx + int(30 * s), ground_y),
                      (cx + int(12 * s), hy + int(30 * s)),
                      (cx - int(12 * s), hy + int(30 * s))], fill=dark)
        draw.line([(cx + int(34 * s), ground_y), (cx + int(46 * s), hy + int(44 * s))],
                  fill=dark, width=max(3, int(6 * s)))


def _pick_hero(seed_text):
    t = seed_text.lower()
    if any(k in t for k in ("pod", "capsule", "lander", "crash")):
        return "pod"
    if any(k in t for k in ("ship", "starship", "rocket", "fleet", "ark")):
        return "ship"
    if any(k in t for k in ("castle", "tower", "keep", "fortress")):
        return "tower"
    if any(k in t for k in ("city", "station", "colony", "urban")):
        return "city"
    if any(k in t for k in ("forest", "tree", "woods", "jungle")):
        return "forest"
    return "figure"


def generate_art_image(width, height, seed_text="", genre="", mood="",
                       hero_x_frac=0.5):
    """Paint a layered illustration at exactly (width, height).

    Deterministic in (seed_text, genre, mood): same words, same picture.
    """
    from PIL import Image, ImageDraw, ImageFilter

    rng = _rng((seed_text or "untitled") + "|" + genre + "|" + mood)
    pal = _PALETTES.get((genre or "").lower(), _PALETTES["default"])
    sky_top, sky_mid, far, near, accent, celestial = pal
    if "dark" in (mood or "").lower() or "grim" in (mood or "").lower():
        sky_top = _lerp(sky_top, (0, 0, 0), 0.35)
        sky_mid = _lerp(sky_mid, (0, 0, 0), 0.25)

    img = _gradient(width, height, sky_top, sky_mid)
    draw = ImageDraw.Draw(img, "RGBA")

    # Stars / drifting specks in the upper sky.
    for _ in range(width * height // 9000):
        x, y = rng.randint(0, width - 1), rng.randint(0, int(height * 0.55))
        r = rng.choice((1, 1, 2))
        draw.ellipse([x - r, y - r, x + r, y + r],
                     fill=(255, 255, 255, rng.randint(50, 160)))

    # Celestial body with a soft halo.
    cx = int(width * rng.uniform(0.62, 0.82))
    cy = int(height * rng.uniform(0.14, 0.26))
    cr = int(min(width, height) * rng.uniform(0.07, 0.11))
    halo = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    hd = ImageDraw.Draw(halo)
    hd.ellipse([cx - cr * 2, cy - cr * 2, cx + cr * 2, cy + cr * 2],
               fill=celestial + (60,))
    img = Image.alpha_composite(img.convert("RGBA"),
                                halo.filter(ImageFilter.GaussianBlur(cr)))
    draw = ImageDraw.Draw(img, "RGBA")
    draw.ellipse([cx - cr, cy - cr, cx + cr, cy + cr], fill=celestial + (235,))
    draw.ellipse([cx - cr, cy - cr, cx + int(cr * 0.4), cy + cr],
                 fill=(0, 0, 0, 36))

    horizon = int(height * 0.78)
    # Far ridge, near ridge, ground.
    draw.polygon(_ridge(rng, width, int(height * 0.62), int(height * 0.05)),
                 fill=far + (255,))
    ground = _ridge(rng, width, horizon, int(height * 0.035))
    draw.polygon(ground, fill=near + (255,))
    ground_y = min(y for (_x, y) in ground[: max(1, len(ground) - 2)]) \
        if ground else horizon

    # Hero silhouette on the front-cover side of the canvas.
    hero = _pick_hero(seed_text or "")
    hx = int(width * hero_x_frac)
    scale = max(0.5, min(width, height) / 900.0)
    # find the ground height under the hero from the near ridge polygon
    gy = horizon
    _hero(draw, hero, hx, gy + int(height * 0.10), scale, near, accent, rng)

    # Sea sparkle / lantern dots on the ground plane.
    for _ in range(width // 14):
        x = rng.randint(0, width - 1)
        y = rng.randint(horizon, height - 4)
        draw.ellipse([x, y, x + 3, y + 2], fill=accent + (rng.randint(40, 110),))

    # Grain + vignette. (Seeded noise - Image.effect_noise is random
    # per call and would break the same-seed-same-picture promise.)
    nw, nh = max(1, width // 3), max(1, height // 3)
    noise = Image.frombytes("L", (nw, nh), rng.randbytes(nw * nh)) \
        .resize((width, height))
    img = Image.composite(img, Image.blend(img, Image.new("RGBA", (width, height),
                          (0, 0, 0, 255)), 0.06), noise.point(lambda v: 28 if v > 128 else 0))
    vig = Image.new("L", (width, height), 0)
    vd = ImageDraw.Draw(vig)
    vd.ellipse([-width // 3, -height // 3, width * 4 // 3, height * 4 // 3], fill=255)
    vig = vig.filter(ImageFilter.GaussianBlur(min(width, height) // 6))
    black = Image.new("RGBA", (width, height), (0, 0, 0, 255))
    img = Image.composite(img, Image.blend(img, black, 0.42), vig)
    return img.convert("RGB")


# ----------------------------------------------------------------------
# Local Stable Diffusion (AUTOMATIC1111) client
# ----------------------------------------------------------------------

def sd_available(base_url=DEFAULT_SD_URL, timeout=2):
    try:
        req = urllib.request.Request(base_url.rstrip("/") + "/sdapi/v1/sd-models")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status == 200
    except Exception:
        return False


def sd_txt2img(prompt, negative_prompt="", width=832, height=1280,
               steps=28, base_url=DEFAULT_SD_URL, timeout=600):
    """Generate one image with a local AUTOMATIC1111 server.
    Returns a PIL Image. Raises RuntimeError with a plain message."""
    payload = {
        "prompt": prompt, "negative_prompt": negative_prompt,
        "width": int(width), "height": int(height),
        "steps": int(steps), "cfg_scale": 7, "sampler_name": "Euler a",
    }
    req = urllib.request.Request(
        base_url.rstrip("/") + "/sdapi/v1/txt2img",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as e:
        raise RuntimeError(f"Stable Diffusion server did not answer: {e}")
    images = data.get("images") or []
    if not images:
        raise RuntimeError("Stable Diffusion returned no image.")
    from PIL import Image
    raw = base64.b64decode(images[0].split(",", 1)[-1])
    return Image.open(io.BytesIO(raw)).convert("RGB")


def sd_size_for(canvas_w, canvas_h, max_dim=1344):
    """An SD-friendly size with the canvas's aspect, capped so a
    12 GB card survives it. Multiples of 8."""
    scale = min(1.0, max_dim / max(canvas_w, canvas_h))
    w = max(64, int(canvas_w * scale) // 8 * 8)
    h = max(64, int(canvas_h * scale) // 8 * 8)
    return w, h
