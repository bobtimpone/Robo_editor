import os
import zipfile

def create_project_zip(zip_name="robo_editor_latest.zip"):
    # Exclude the zip file itself and hidden/cache directories
    excluded_dirs = {'__pycache__', '.git', '.vscode'}
    excluded_files = {zip_name, 'make_zip.py'}
    
    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk('.'):
            # Modify dirs in-place to skip excluded directories
            dirs[:] = [d for d in dirs if d not in excluded_dirs]
            
            for file in files:
                if file in excluded_files:
                    continue
                
                file_path = os.path.join(root, file)
                # Write file to zip, maintaining relative path structure including subdirectories
                zipf.write(file_path, arcname=os.path.relpath(file_path, '.'))
                print(f"Added: {file_path}")
                        
    print(f"\nSuccessfully packaged project and subdirectories into: {zip_name}")

if __name__ == "__main__":
    create_project_zip()