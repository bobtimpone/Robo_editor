import customtkinter as ctk
from tkinter import filedialog, messagebox
import threading
import os
import json
import urllib.request

from engine import EditorEngine
from orchestrator import AgentPipelineOrchestrator
from agents.keeper_agent import KeeperAgent

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")
CONFIG_FILE = "robo_config.json"

class RoboEditorUI(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Robo-Editor: Multi-Agent Pipeline & Co-Author")
        self.geometry("850x1000")
        self.grid_columnconfigure(0, weight=1)
        
        self.engine = EditorEngine()
        self.is_processing = False
        self.ollama_url = "http://localhost:11434"
        
        self.setup_variables()
        self.setup_ui()
        self.load_config()
        self.fetch_models()
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

    def setup_variables(self):
        self.input_var = ctk.StringVar()
        self.output_var = ctk.StringVar()
        self.model_var = ctk.StringVar()
        self.chunk_size_var = ctk.StringVar(value="1500")
        self.context_size_var = ctk.StringVar(value="4096")
        self.genre_var = ctk.StringVar(value="None")
        self.voice_var = ctk.StringVar(value="None")
        self.tempo_var = ctk.StringVar(value="None")
        self.fast_mode_var = ctk.BooleanVar(value=False)
        
        self.coauthor_role_var = ctk.StringVar(value="AI Expert")
        self.word_count_var = ctk.StringVar(value="500")
        self.prompt_topic_var = ctk.StringVar(value="")
        
        self.edit_vars = {
            "Developmental Edit": ctk.BooleanVar(value=True),
            "Line Edit": ctk.BooleanVar(value=True),
            "Copy Edit": ctk.BooleanVar(value=True),
            "Proofread": ctk.BooleanVar(value=True)
        }

    def setup_ui(self):
        file_frame = ctk.CTkFrame(self)
        file_frame.grid(row=0, column=0, padx=20, pady=(15, 10), sticky="ew")
        file_frame.grid_columnconfigure(1, weight=1)
        
        ctk.CTkLabel(file_frame, text="File Settings", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=10, sticky="w")
        ctk.CTkLabel(file_frame, text="Input (.docx):").grid(row=1, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkEntry(file_frame, textvariable=self.input_var).grid(row=1, column=1, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(file_frame, text="Browse...", width=100, command=self.browse_input).grid(row=1, column=2, padx=10, pady=5)
        
        ctk.CTkLabel(file_frame, text="Output (.docx):").grid(row=2, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkEntry(file_frame, textvariable=self.output_var).grid(row=2, column=1, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(file_frame, text="Browse...", width=100, command=self.browse_output).grid(row=2, column=2, padx=10, pady=5)

        model_frame = ctk.CTkFrame(self)
        model_frame.grid(row=1, column=0, padx=20, pady=10, sticky="ew")
        model_frame.grid_columnconfigure(1, weight=1)
        model_frame.grid_columnconfigure(3, weight=1)
        
        ctk.CTkLabel(model_frame, text="Engine & Watch Tower Settings", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=10, sticky="w")
        ctk.CTkLabel(model_frame, text="Select Model:").grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.model_dropdown = ctk.CTkOptionMenu(model_frame, variable=self.model_var, values=["Loading..."])
        self.model_dropdown.grid(row=1, column=1, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(model_frame, text="Refresh", width=80, command=self.fetch_models).grid(row=1, column=2, padx=10, pady=5)
        
        ctk.CTkLabel(model_frame, text="Max Tokens/Chunk:").grid(row=2, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(model_frame, variable=self.chunk_size_var, values=["500", "1000", "1500", "2000"]).grid(row=2, column=1, padx=10, pady=5, sticky="ew")
        ctk.CTkLabel(model_frame, text="Context Limit:").grid(row=2, column=2, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(model_frame, variable=self.context_size_var, values=["4096", "8192", "16384", "32768"]).grid(row=2, column=3, padx=10, pady=5, sticky="ew")

        coauthor_frame = ctk.CTkFrame(self)
        coauthor_frame.grid(row=2, column=0, padx=20, pady=10, sticky="ew")
        coauthor_frame.grid_columnconfigure(1, weight=1)
        coauthor_frame.grid_columnconfigure(3, weight=1)
        
        ctk.CTkLabel(coauthor_frame, text="Co-Author Generation Agent", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        ctk.CTkLabel(coauthor_frame, text="Role:").grid(row=1, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(coauthor_frame, variable=self.coauthor_role_var, values=["AI Expert", "Engineer", "Novelist", "Researcher"]).grid(row=1, column=1, padx=10, pady=5, sticky="ew")
        
        ctk.CTkLabel(coauthor_frame, text="Target Words:").grid(row=1, column=2, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(coauthor_frame, variable=self.word_count_var, values=["500", "1500", "5000", "15000", "30000", "60000", "70000", "80000", "95000"]).grid(row=1, column=3, padx=10, pady=5, sticky="ew")
        
        ctk.CTkLabel(coauthor_frame, text="Topic / Prompt:").grid(row=2, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkEntry(coauthor_frame, textvariable=self.prompt_topic_var, placeholder_text="Leave blank to read topic from input .docx file...").grid(row=2, column=1, columnspan=2, padx=10, pady=5, sticky="ew")
        ctk.CTkButton(coauthor_frame, text="Generate Section", fg_color="#e67e22", hover_color="#d35400", command=self.start_coauthor_process).grid(row=2, column=3, padx=10, pady=5, sticky="ew")

        style_frame = ctk.CTkFrame(self)
        style_frame.grid(row=3, column=0, padx=20, pady=10, sticky="ew")
        for i in range(1, 6, 2): style_frame.grid_columnconfigure(i, weight=1)
        
        ctk.CTkLabel(style_frame, text="Style Directives", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=10, sticky="w")
        ctk.CTkLabel(style_frame, text="Genre:").grid(row=1, column=0, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(style_frame, variable=self.genre_var, values=["None", "Self-Help", "Generic Fiction", "Sci-Fi", "Fantasy", "Romance", "Thriller", "Horror"]).grid(row=1, column=1, padx=(0,10), pady=5, sticky="ew")
        ctk.CTkLabel(style_frame, text="Voice:").grid(row=1, column=2, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(style_frame, variable=self.voice_var, values=["None", "Authoritative", "Conversational", "Gritty", "Humorous", "Lyrical"]).grid(row=1, column=3, padx=(0,10), pady=5, sticky="ew")
        ctk.CTkLabel(style_frame, text="Tempo:").grid(row=1, column=4, padx=10, pady=5, sticky="w")
        ctk.CTkOptionMenu(style_frame, variable=self.tempo_var, values=["None", "Fast", "Balanced", "Slow"]).grid(row=1, column=5, padx=(0,10), pady=5, sticky="ew")

        pipe_frame = ctk.CTkFrame(self)
        pipe_frame.grid(row=4, column=0, padx=20, pady=10, sticky="ew")
        ctk.CTkLabel(pipe_frame, text="Editing Pipeline Stages", font=ctk.CTkFont(weight="bold")).grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        stages_frame = ctk.CTkFrame(pipe_frame, fg_color="transparent")
        stages_frame.grid(row=1, column=0, columnspan=4, padx=10, sticky="w")
        for i, (name, var) in enumerate(self.edit_vars.items()):
            ctk.CTkCheckBox(stages_frame, text=name, variable=var).grid(row=0, column=i, padx=(0, 15), pady=5)
            
        ctk.CTkSwitch(pipe_frame, text="⚡ Fast Mode: Combine passes into a single generation", variable=self.fast_mode_var, progress_color="#d35400").grid(row=2, column=0, padx=10, pady=10, sticky="w")

        control_frame = ctk.CTkFrame(self, fg_color="transparent")
        control_frame.grid(row=5, column=0, padx=20, pady=10, sticky="ew")
        control_frame.grid_columnconfigure(0, weight=1)
        control_frame.grid_columnconfigure(1, weight=1)
        
        self.start_btn = ctk.CTkButton(control_frame, text="Run Editing Pipeline", fg_color="#2ecc71", hover_color="#27ae60", font=ctk.CTkFont(weight="bold"), command=self.start_process)
        self.start_btn.grid(row=0, column=0, padx=(0, 5), sticky="ew")
        self.stop_btn = ctk.CTkButton(control_frame, text="Stop/Cancel", fg_color="#e74c3c", hover_color="#c0392b", font=ctk.CTkFont(weight="bold"), state="disabled", command=self.stop_process)
        self.stop_btn.grid(row=0, column=1, padx=(5, 0), sticky="ew")
        
        self.progress_bar = ctk.CTkProgressBar(self)
        self.progress_bar.grid(row=6, column=0, padx=20, pady=(0, 10), sticky="ew")
        self.progress_bar.set(0)
        
        self.status_label = ctk.CTkLabel(self, text="Ready.", text_color="gray")
        self.status_label.grid(row=7, column=0, padx=20, sticky="w")
        
        self.log_area = ctk.CTkTextbox(self, height=150)
        self.log_area.grid(row=8, column=0, padx=20, pady=(0, 20), sticky="nsew")
        self.grid_rowconfigure(8, weight=1)

    def save_config(self):
        config = {
            "chunk_size": self.chunk_size_var.get(),
            "context_size": self.context_size_var.get(),
            "genre": self.genre_var.get(),
            "voice": self.voice_var.get(),
            "tempo": self.tempo_var.get(),
            "fast_mode": self.fast_mode_var.get(),
            "model": self.model_var.get(),
            "coauthor_role": self.coauthor_role_var.get(),
            "stages": {k: v.get() for k, v in self.edit_vars.items()}
        }
        try:
            with open(CONFIG_FILE, 'w') as f:
                json.dump(config, f)
        except Exception:
            pass

    def load_config(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r') as f:
                    config = json.load(f)
                self.chunk_size_var.set(config.get("chunk_size", "1500"))
                self.context_size_var.set(config.get("context_size", "4096"))
                self.genre_var.set(config.get("genre", "None"))
                self.voice_var.set(config.get("voice", "None"))
                self.tempo_var.set(config.get("tempo", "None"))
                self.fast_mode_var.set(config.get("fast_mode", False))
                self.coauthor_role_var.set(config.get("coauthor_role", "AI Expert"))
                stages = config.get("stages", {})
                for k, v in stages.items():
                    if k in self.edit_vars:
                        self.edit_vars[k].set(v)
                self.saved_model = config.get("model", "")
            except Exception:
                pass

    def on_closing(self):
        self.save_config()
        self.destroy()

    def log(self, message):
        self.log_area.insert("end", f"{message}\n")
        self.log_area.see("end")

    def set_status(self, text):
        self.status_label.configure(text=text)

    def browse_input(self):
        filename = filedialog.askopenfilename(defaultextension=".docx", filetypes=[("Word Documents", "*.docx")])
        if filename:
            self.input_var.set(filename)
            base, ext = os.path.splitext(filename)
            self.output_var.set(f"{base}_edited{ext}")

    def browse_output(self):
        filename = filedialog.asksaveasfilename(defaultextension=".docx", filetypes=[("Word Documents", "*.docx")])
        if filename:
            self.output_var.set(filename)

    def fetch_models(self):
        try:
            req = urllib.request.Request(f"{self.ollama_url}/api/tags")
            with urllib.request.urlopen(req, timeout=3) as response:
                data = json.loads(response.read().decode())
                models = [m['name'] for m in data.get('models', [])]
                if models:
                    self.model_dropdown.configure(values=models)
                    if hasattr(self, 'saved_model') and self.saved_model in models:
                        self.model_var.set(self.saved_model)
                    else:
                        self.model_var.set(models[0])
                    self.log("Models loaded from Ollama.")
                else:
                    self.model_dropdown.configure(values=["No models found"])
        except Exception:
            self.log("Could not connect to Ollama. Ensure localhost:11434 is running.")
            self.model_dropdown.configure(values=["Connection Error"])

    def stop_process(self):
        if self.is_processing:
            self.engine.cancel_requested = True
            self.stop_btn.configure(state="disabled", text="Saving partial file...")
            self.log("Cancel requested... finishing current operation and saving progress.")

    def start_coauthor_process(self):
        if self.is_processing: return
        topic = self.prompt_topic_var.get().strip()
        in_file = self.input_var.get().strip()
        
        if not topic and in_file:
            try:
                chunks = self.engine.load_and_chunk(in_file, max_tokens_per_chunk=1000)
                if chunks:
                    topic = chunks[0]
                    self.log(f"Loaded topic outline from input file: {os.path.basename(in_file)}")
            except Exception as e:
                self.log(f"Failed to load topic from input file: {e}")

        if not topic:
            messagebox.showwarning("Missing Prompt", "Please enter a topic prompt or provide a valid input .docx file.")
            return

        role = self.coauthor_role_var.get()
        word_count = int(self.word_count_var.get())
        model = self.model_var.get()
        out_file = self.output_var.get()
        
        if not out_file:
            messagebox.showwarning("Missing Output", "Please select an output file path to save the generated manuscript.")
            return

        self.is_processing = True
        self.engine.cancel_requested = False
        self.start_btn.configure(state="disabled", text="Processing...")
        self.stop_btn.configure(state="normal", text="Stop/Cancel")
        self.log_area.delete("1.0", "end")
        
        threading.Thread(target=self._run_coauthor_thread, args=(topic, role, word_count, model, out_file), daemon=True).start()

    def _run_coauthor_thread(self, topic, role, word_count, model, out_file):
        try:
            context_limit = int(self.context_size_var.get())
            orchestrator = AgentPipelineOrchestrator(self.engine, model)
            keeper = KeeperAgent(self.engine, model)
            
            generated_chunks = []
            generated_words = 0
            block_target = 1500
                
            sequence_id = 1
            max_blocks = max(1, word_count // block_target + (1 if word_count % block_target > 0 else 0))
            
            self.log(f"[Co-Author] Starting long-form generation. Target: {word_count} words across ~{max_blocks} blocks (1500 words/block).")

            while generated_words < word_count:
                if self.engine.cancel_requested:
                    self.log("\n[Co-Author] Stop requested by user. Halting generation loop...")
                    break

                remaining_words = word_count - generated_words
                current_block_target = min(block_target, remaining_words)
                
                def stream_update(text):
                    current_total = generated_words + len(text.split())
                    self.after(0, self.set_status, f"Co-Author generating block {sequence_id}/{max_blocks} (~{current_total}/{word_count} words)...")

                self.log(f"\n[Co-Author] Generating narrative block {sequence_id}/{max_blocks} (Target: {current_block_target} words)...")
                
                state_ledger = ""
                if sequence_id > 1 and generated_chunks:
                    self.log("[Keeper] Extracting active narrative state ledger...")
                    state_ledger = keeper.summarize_state(generated_chunks, context_limit=context_limit)

                directional_prompt = (
                    f"Core Premise / Starting Seed: {topic}\n"
                    f"Current Block Sequence: Part {sequence_id} of {max_blocks}.\n"
                    f"Strict Word Budget for this block: Approximately {current_block_target} words maximum.\n"
                    "INSTRUCTION: Advance the narrative forward. Introduce new plot developments, dialogue, or environmental shifts. "
                    "DO NOT repeat previous scenes or loop motifs. Drive toward a progressive narrative arc."
                )
                
                block_draft = orchestrator.generate_new_content(
                    directional_prompt, role, current_block_target, sequence_id=sequence_id, max_blocks=max_blocks,
                    context_limit=context_limit, stream_callback=stream_update, log_callback=lambda msg: self.after(0, self.log, msg),
                    state_ledger=state_ledger
                )
                
                if self.engine.cancel_requested:
                    self.log("\n[Co-Author] Stop requested during block generation. Saving progress so far...")
                    break

                block_words = len(block_draft.split())
                if generated_words + block_words > word_count:
                    allowed_words = word_count - generated_words
                    words_list = block_draft.split()[:allowed_words]
                    block_draft = " ".join(words_list)
                    block_words = len(block_draft.split())

                generated_chunks.append(block_draft)
                generated_words += block_words
                self.log(f"[Co-Author] Block {sequence_id} complete. Total manuscript words: {generated_words}/{word_count}")
                
                if generated_words >= word_count:
                    break
                    
                sequence_id += 1
            
            if generated_chunks:
                self.log(f"\nSaving generated manuscript ({generated_words} words) to document...")
                self.engine.save_document(generated_chunks, out_file)
                self.log(f"Saved to: {os.path.basename(out_file)}")
                
                if self.engine.cancel_requested:
                    self.after(0, messagebox.showinfo, "Cancelled & Saved", f"Generation stopped by user. Saved partial manuscript (~{generated_words} words) successfully!")
                else:
                    self.after(0, messagebox.showinfo, "Complete", f"Co-Author manuscript (~{generated_words} words) generated and verified successfully!")
            else:
                self.log("\nNo content was generated before cancellation.")

        except Exception as e:
            self.log(f"\nCRITICAL ERROR: {str(e)}")
            self.after(0, messagebox.showerror, "Error", str(e))
        finally:
            self.is_processing = False
            self.after(0, lambda: self.stop_btn.configure(state="disabled", text="Stop/Cancel"))
            self.after(0, self.set_status, "Ready.")

    def start_process(self):
        if self.is_processing: return
        in_file = self.input_var.get()
        out_file = self.output_var.get()
        model = self.model_var.get()
        selected_stages = [name for name, var in self.edit_vars.items() if var.get()]
        
        if not in_file or not out_file:
            messagebox.showwarning("Missing Files", "Please select input and output files.")
            return
        if not model or "Error" in model:
            messagebox.showwarning("No Model", "Please select a valid Ollama model.")
            return
        if not selected_stages:
            messagebox.showwarning("No Edits", "Please select at least one editing stage.")
            return

        self.save_config()
        self.is_processing = True
        self.engine.cancel_requested = False
        self.start_btn.configure(state="disabled", text="Processing...")
        self.stop_btn.configure(state="normal", text="Stop/Cancel")
        self.progress_bar.set(0)
        self.log_area.delete("1.0", "end")
        
        threading.Thread(target=self._run_pipeline_thread, args=(in_file, out_file, model, selected_stages), daemon=True).start()

    def _run_pipeline_thread(self, in_file, out_file, model, selected_stages):
        try:
            self.log(f"Loading document chunks: {os.path.basename(in_file)}")
            max_tokens = int(self.chunk_size_var.get())
            context_limit = int(self.context_size_var.get())
            fast_mode = self.fast_mode_var.get()
            
            style_modifiers = []
            if self.genre_var.get() != "None": style_modifiers.append(f"Target Genre: {self.genre_var.get()}")
            if self.voice_var.get() != "None": style_modifiers.append(f"Narrative Voice: {self.voice_var.get()}")
            if self.tempo_var.get() != "None": style_modifiers.append(f"Pacing: {self.tempo_var.get()}")
            
            style_prompt = ""
            if style_modifiers:
                style_prompt = "\n\nSTYLE DIRECTIVES:\n" + "\n".join(f"- {m}" for m in style_modifiers)

            chunks = self.engine.load_and_chunk(in_file, max_tokens_per_chunk=max_tokens)
            self.log(f"Document split into {len(chunks)} chunks.")
            
            orchestrator = AgentPipelineOrchestrator(self.engine, model)
            edited_chunks = []
            
            stages_to_run = ["Combined Edit"] if fast_mode else selected_stages
            total_ops = len(chunks) * len(stages_to_run)
            current_op = 0

            for i, chunk_text in enumerate(chunks):
                if self.engine.cancel_requested:
                    edited_chunks.extend(chunks[i:])
                    break
                
                self.log(f"\n--- Chunk {i+1}/{len(chunks)} ---")
                current_text = chunk_text
                
                for stage in stages_to_run:
                    if self.engine.cancel_requested: break
                    
                    def stream_update(text):
                        words = len(text.split())
                        self.after(0, self.set_status, f"Chunk {i+1} ({stage}): Generating (~{words} words...)")

                    current_text = orchestrator.process_chunk(
                        current_text, stage, style_prompt=style_prompt,
                        context_limit=context_limit, stream_callback=stream_update,
                        log_callback=lambda msg: self.after(0, self.log, msg)
                    )
                    
                    current_op += 1
                    self.after(0, self.progress_bar.set, current_op / total_ops)
                    
                edited_chunks.append(current_text)

            self.log("\nReassembling document via Markdown engine...")
            self.set_status("Saving document...")
            self.engine.save_document(edited_chunks, out_file)
            self.log(f"Saved: {os.path.basename(out_file)}")
            self.after(0, messagebox.showinfo, "Complete", "Agent pipeline finished successfully!")

        except Exception as e:
            self.log(f"\nCRITICAL ERROR: {str(e)}")
            self.after(0, messagebox.showerror, "Error", str(e))
        finally:
            self.is_processing = False
            self.after(0, lambda: self.start_btn.configure(state="normal", text="Run Editing Pipeline"))
            self.after(0, lambda: self.stop_btn.configure(state="disabled", text="Stop/Cancel"))
            self.after(0, self.set_status, "Ready.")
            self.after(0, self.progress_bar.set, 0)

if __name__ == "__main__":
    app = RoboEditorUI()
    app.mainloop()