from agents.scribe_agent import ScribeAgent
from agents.watchtower_agent import WatchTowerAgent
from agents.keeper_agent import KeeperAgent
from agents.coauthor_agent import CoAuthorAgent

class AgentPipelineOrchestrator:
    def __init__(self, engine, model):
        self.engine = engine
        self.model = model
        self.scribe = ScribeAgent(engine, model)
        self.watchtower = WatchTowerAgent(engine, model)
        self.keeper = KeeperAgent(engine, model)
        self.coauthor = CoAuthorAgent(engine, model)

    def process_chunk(self, chunk_text, stage, style_prompt="", context_limit=4096, stream_callback=None, log_callback=None):
        if log_callback: log_callback(f"[{stage}] Starting processing pass...")
        current_text = chunk_text
        max_qa_retries = 3
        attempt = 0
        
        while attempt < max_qa_retries:
            if self.engine.cancel_requested: break
            edited_text = self.scribe.edit(current_text, stage, style_prompt=style_prompt, context_limit=context_limit, stream_callback=stream_callback)
            is_approved, qa_feedback = self.watchtower.inspect_chunk(current_text, edited_text, stage, context_limit=context_limit)
            if is_approved: return edited_text
            current_text = self.scribe.correct(edited_text, qa_feedback, context_limit=context_limit)
            attempt += 1
        return current_text

    def generate_new_content(self, prompt_topic, role, target_word_count, sequence_id=1, max_blocks=1, context_limit=4096, stream_callback=None, log_callback=None, state_ledger=""):
        if log_callback: log_callback(f"[Co-Author] Generating block {sequence_id}/{max_blocks}...")
        
        full_prompt = f"{prompt_topic}\n\nESTABLISHED STATE LEDGER (DO NOT REPEAT THESE EVENTS):\n{state_ledger}" if state_ledger else prompt_topic
        
        draft = self.coauthor.write_section(full_prompt, role, target_word_count, sequence_id=sequence_id, max_blocks=max_blocks, context_limit=context_limit, stream_callback=stream_callback)
        
        is_approved, qa_feedback = self.watchtower.inspect_chunk("", draft, "Co-Author Generation", context_limit=context_limit)
        if not is_approved:
            if log_callback: log_callback(f"[Co-Author] Watch Tower flagged loop/quality violation. Running corrective pass...")
            draft = self.scribe.correct(draft, qa_feedback, context_limit=context_limit)
        return draft