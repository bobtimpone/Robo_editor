class KeeperAgent:
    def __init__(self, engine, model):
        self.engine = engine
        self.model = model

    def summarize_state(self, accumulated_chunks, context_limit=4096):
        combined_text = "\n\n".join(accumulated_chunks[-3:])
        prompt = (
            "You are the Keeper agent tracking narrative state across a manuscript.\n"
            "Analyze the following recent text and extract a concise bulleted ledger of:\n"
            "1. Events and scenes that have ALREADY occurred.\n"
            "2. Specific dialogues, images, or motifs already used (e.g., cold coffee, 3:14 a.m. essays).\n"
            "3. Active plot threads that must move FORWARD.\n\n"
            f"RECENT MANUSCRIPT TEXT:\n{combined_text}\n\n"
            "Provide a strict, compact summary ledger."
        )
        return self.engine.call_ollama(
            model=self.model,
            system_prompt=prompt,
            text="",
            context_size=context_limit,
            is_edit_pass=False
        )