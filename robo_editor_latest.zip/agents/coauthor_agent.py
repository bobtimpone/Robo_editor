class CoAuthorAgent:
    def __init__(self, engine, model):
        self.engine = engine
        self.model = model

    def write_section(self, prompt_topic, role, target_word_count, sequence_id=1, max_blocks=1, context_limit=4096, stream_callback=None):
        role_prompts = {
            "AI Expert": "You are a seasoned AI infrastructure engineer with a pragmatic, no-nonsense practitioner tone. Write with technical precision and dry wit.",
            "Engineer": "You are a software architect who builds real-world production pipelines. Focus on actual configuration workflows, SIS data maps, and LTI scopes without fluff.",
            "Novelist": "You are a gritty fiction author. Write with variable pacing, sharp dialogue fragments, and rugged descriptions grounded in sensory subtext.",
            "Researcher": "You are a rigorous field researcher. Ground your analysis in specific compliance frameworks using conversational fluency."
        }
        
        sys_prompt = role_prompts.get(role, "You are a pragmatic co-author writing with direct novelist authority.")
        
        is_scene = (sequence_id % 2 != 0)
        pacing_instruction = (
            "PACING MANDATE (SCENE): Push external conflict, technical friction, high-tempo dialogue, and forward momentum."
            if is_scene else
            "PACING MANDATE (SEQUEL): Pull back into tactical processing, internal reflection, atmospheric weight, and quieter analytical depth."
        )
        
        pov_lock = (
            "4. STRICT POV LOCK: You must write exclusively in the THIRD-PERSON LIMITED perspective "
            "following a single designated focal character. "
            "ABSOLUTELY FORBIDDEN: Do not shift into first-person ('I', 'we') or second-person ('you'). "
            "Maintain consistent narrative distance throughout the entire block."
        )
        
        novelist_directives = (
            "\n\nSTRICT NO-LOOPING & PROGRESSION MANDATES:\n"
            f"1. {pacing_instruction}\n"
            "2. ABSOLUTELY NO NARRATIVE LOOPS: Never re-enter classrooms, offices, or conversations that have already been resolved. Every block must introduce a completely new physical location, a new character interaction, or an escalating external consequence.\n"
            "3. DIALOGUE & INTERACTION SUBTEXT: Characters never say exactly what they mean. Dialogue must carry hidden weight, evasions, power shifts, or subtextual tension.\n"
            f"{pov_lock}\n"
            "5. SENSORY & TACTILE ANCHORING: Ground every single block in tangible physical reality—the scrape of a chair, the hum of server fans, the grit of dust on a screen—before moving to abstract concepts.\n"
            "6. BANNED AI MARKERS & CLICHÉS: No buzzwords ('Delve', 'Tapestry', 'Robust') or clichés ('cold coffee', 'angry wasps', '3:14 a.m.', 'stealing time', 'jared and mrs. delgado')."
        )
        
        block_target = min(target_word_count, 1500)
        
        final_prompt = (
            f"{sys_prompt}{novelist_directives}\n\n"
            f"Block Progress: Part {sequence_id} of {max_blocks} (Strict Target: Exactly ~{block_target} words maximum).\n"
            f"Directional Prompt / Continuity Ledger:\n{prompt_topic}"
        )
        
        return self.engine.call_ollama(
            model=self.model,
            system_prompt=final_prompt,
            text="",
            context_size=context_limit,
            stream_callback=stream_callback,
            is_edit_pass=False,
            target_word_limit=block_target
        )