class ScribeAgent:
    def __init__(self, engine, model):
        self.engine = engine
        self.model = model

    def _get_anti_pattern_prompt(self):
        return (
            "\n\nSTRICT PROFESSIONAL NOVELIST EDITING MANDATES:\n"
            "1. CONCRETENESS OVER ABSTRACTION: Strip out vague abstract concepts. If a sentence talks about 'efficiency', "
            "'bureaucracy', or 'complexity', rewrite it to show physical manifestation (e.g., three overlapping login screens, a blinking amber error light).\n"
            "2. SHATTER RHYTHMIC PREDICTABILITY: Vary clause counts aggressively. Follow a 3-word sentence with a 35-word sprawling compound sentence.\n"
            "3. KILL ADVERBIAL CRUTCHES: Eradicate weak modifiers ('suddenly', 'gradually', 'inevitably'). Let verbs carry the weight.\n"
            "4. NO THEMATIC SIGNPOSTS: Open scenes mid-action.\n"
            "5. BANNED AI MARKERS & CLICHÉS: Strictly forbid buzzwords ('Delve', 'Tapestry', 'Robust') and repetitive clichés ('cold coffee', 'angry wasps', '3:14 a.m.')."
        )

    def edit(self, text, stage, style_prompt="", context_limit=4096, stream_callback=None):
        prompts = {
            "Developmental Edit": "You are a pragmatic developmental editor. Rebuild text section by section with organic structures and subtextual depth.",
            "Line Edit": "You are a line editor. Strip out predictable formatting templates, thesis signposts, and robotic transition formulas.",
            "Copy Edit": "You are a copy editor. Correct syntax while injecting a rugged, direct human novelist voice.",
            "Proofread": "You are a proofreader. Catch residual errors while maintaining varied sentence lengths.",
            "Combined Edit": "Apply all editing standards simultaneously while completely shattering predictable scaffolding."
        }
        sys_prompt = prompts.get(stage, prompts["Line Edit"]) + style_prompt + self._get_anti_pattern_prompt()
        return self.engine.call_ollama(
            model=self.model, system_prompt=sys_prompt, text=text,
            context_size=context_limit, stream_callback=stream_callback, is_edit_pass=True
        )

    def correct(self, text, feedback, context_limit=4096, stream_callback=None):
        sys_prompt = (
            "You are the Scribe agent correcting text based on Watch Tower feedback.\n"
            f"Watch Tower Feedback:\n{feedback}\n\n"
            "Rewrite the offending sections to enforce concreteness, cadence shifts, and elimination of clichés."
        ) + self._get_anti_pattern_prompt()
        return self.engine.call_ollama(
            model=self.model, system_prompt=sys_prompt, text=text,
            context_size=context_limit, stream_callback=stream_callback, is_edit_pass=True
        )