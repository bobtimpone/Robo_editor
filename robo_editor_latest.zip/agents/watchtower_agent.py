import statistics

class WatchTowerAgent:
    def __init__(self, engine, model):
        self.engine = engine
        self.model = model

    def _check_duplication(self, edited_text):
        paragraphs = [p.strip() for p in edited_text.split('\n\n') if p.strip()]
        seen_snippets = set()
        
        for p in paragraphs:
            p_lower = p.lower()
            p_snippet = p_lower[:50]
            if p_snippet in seen_snippets and len(p) > 25:
                return False, f"Catastrophic loop detected: repetitive structural start ('{p[:30]}...')"
            seen_snippets.add(p_snippet)
            
            forbidden_phrases = [
                "cold coffee", "angry wasps", "3:14 a.m.", 
                "the text to edit is missing", "stealing time", "jared and mrs. delgado"
            ]
            for phrase in forbidden_phrases:
                if phrase in p_lower:
                    return False, f"Loop/Cliché violation detected: forbidden trope or error text ('{phrase}')."
                
        return True, "No duplication found."

    def _evaluate_human_score(self, text):
        paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
        if not paragraphs:
            return 0.0, "Empty text."

        para_lengths = []
        for p in paragraphs:
            sentences = [s for s in p.split('.') if s.strip()]
            if sentences:
                avg_len = sum(len(s.split()) for s in sentences) / len(sentences)
                para_lengths.append(avg_len)

        if len(para_lengths) > 2:
            variance = statistics.variance(para_lengths)
            cadence_score = min(variance / 50.0, 1.0)
        else:
            cadence_score = 0.5

        lower_text = text.lower()
        banned_openings = ["last october", "it broke on", "as an ai", "in today's world"]
        penalty = sum(0.2 for phrase in banned_openings if phrase in lower_text)

        human_score = max(0.0, min(1.0, 0.7 + (cadence_score * 0.3) - penalty))
        return human_score, f"Cadence variance score: {cadence_score:.2f}, Penalty: {penalty}"

    def inspect_chunk(self, original_text, edited_text, stage, context_limit=4096):
        is_unique, dup_feedback = self._check_duplication(edited_text)
        if not is_unique:
            return False, f"STATUS: REJECTED\nDuplication Watch Violation: {dup_feedback}"

        score, score_details = self._evaluate_human_score(edited_text)
        if score < 0.80:
            return False, f"STATUS: REJECTED\nHuman-Written Score ({score*100:.1f}%) fell below 80% threshold."

        audit_prompt = (
            f"You are a ruthless literary fiction editor auditing text for novelistic depth.\n"
            "Reject the text (start response with 'STATUS: REJECTED') if you find essay exposition, lack of grounding, repetitive loops, or clichés.\n"
            f"ORIGINAL:\n{original_text}\n\nTEXT:\n{edited_text}\n\n"
            "Start with 'STATUS: APPROVED' if stellar, otherwise 'STATUS: REJECTED'."
        )
        response = self.engine.call_ollama(model=self.model, system_prompt=audit_prompt, text="", context_size=context_limit, is_edit_pass=False)
        return "STATUS: APPROVED" in response.upper(), response