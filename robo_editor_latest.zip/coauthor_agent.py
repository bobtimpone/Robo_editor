class CoAuthorAgent:
    def __init__(self, engine, model):
        self.engine = engine
        self.model = model

    def write_section(self, prompt_topic, role, target_word_count, context_limit=4096, stream_callback=None):
        role_prompts = {
            "AI Expert": "You are an expert in artificial intelligence, machine learning systems, and prompt architectures. Write clear, technically precise, and authoritative content.",
            "Engineer": "You are a software and systems engineer. Focus on practical implementation details, system architecture, code structures, and technical workflows.",
            "Novelist": "You are a creative fiction author. Focus on vivid prose, narrative momentum, and engaging dialogue.",
            "Researcher": "You are a meticulous researcher. Focus on structured analysis, factual precision, and clear explanations."
        }
        
        sys_prompt = role_prompts.get(role, "You are a collaborative co-author assisting with manuscript drafting.")
        
        anti_pattern_directives = (
            "\n\nSTRICT NEGATIVE CONSTRAINTS & BANNED CRUTCHES:\n"
            "1. BANNED AI BUZZWORDS: Never use words like 'Delve', 'Tapestry', 'Multifaceted', 'Nuanced', "
            "'Robust', 'Leverage', 'Utilize', 'Crucial', 'Testament', or 'Underscore'.\n"
            "2. BANNED PHRASES: Never use open-ended filler phrases like 'In today’s fast-paced world...', "
            "'It’s worth noting that...', 'At its core...', 'In the realm of...', 'Seamless integration', "
            "'Furthermore / Moreover', or 'A testament to...'.\n"
            "3. NO FORMULARIC OPENINGS: Avoid repetitive thematic topic sentences or rigid structural formulas.\n"
            "4. NO CLICHÉ METAPHORS: Never compare software or abstract concepts to a 'Swiss Army knife', 'GPS', or 'personal trainer'."
        )
        
        block_target = min(target_word_count, 1500)
        
        final_prompt = (
            f"{sys_prompt}{anti_pattern_directives}\n\n"
            f"Target length for this section: Approximately {block_target} words. "
            f"Expand the topic thoroughly without padding.\n"
            f"Outline / Topic Prompt:\n{prompt_topic}"
        )
        
        return self.engine.call_ollama(
            model=self.model,
            system_prompt=final_prompt,
            text="",
            context_size=context_limit,
            stream_callback=stream_callback,
            is_edit_pass=False
        )